"""Single-threaded POSIX fork/exec primitive; no blocking exec-ack read.

Parent observes the prebound CLOEXEC status pipe in the finite selector loop.
No subprocess.Popen/communicate/reader thread, shell, descendant management or
kill fallback. Child startup is a closed bounded sequence of OS operations.
"""
import errno
import os
import signal
import struct

class Child:
    def __init__(self,pid):
        self.pid=pid
        self.returncode=None

    def poll(self):
        if self.returncode is None:
            pid,status=os.waitpid(self.pid,os.WNOHANG)
            if pid:self.returncode=os.waitstatus_to_exitcode(status)
        return self.returncode

    def terminate(self):
        os.kill(self.pid,signal.SIGTERM)


def spawn(spec,fds):
    pid=os.fork()
    if pid:return Child(pid)
    # Child: no user callback, source import, logging, traceback or finalizers.
    status_fd=fds['exec_write'];where=0
    try:
        signal.signal(signal.SIGTERM,signal.SIG_DFL)
        where=1;os.fchdir(fds['cwd_pin'])
        where=2;os.dup2(fds['stdin_read'],0,inheritable=True)
        where=3;os.dup2(fds['stdout_write'],1,inheritable=True)
        where=4;os.dup2(fds['stderr_write'],2,inheritable=True)
        # Only startup status fd3 survives until exec; CLOEXEC binds its EOF.
        where=5;os.dup2(fds['exec_write'],3,inheritable=False);status_fd=3
        where=6;os.closerange(4,spec.fd_ceiling)
        where=7;os.execve(spec.argv[0],spec.argv,dict(spec.env))
    except BaseException as e:
        # Finite binary status; no arbitrary error strings or inherited sink.
        number=e.errno if isinstance(e,OSError) and type(e.errno) is int and 0<e.errno<=65535 else errno.EFAULT
        try:os.write(status_fd,struct.pack('!BI',where,number))
        except BaseException:pass
    os._exit(127)
