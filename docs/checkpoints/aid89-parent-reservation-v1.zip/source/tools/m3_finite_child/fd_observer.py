"""Fixture-only FD generation check for historical admission close records.

A numeric fd may now be reused after an admission descriptor closed. Observe
EBADF immediately after successful close, before allocation can reuse it; a
later live fd must join a current unknown owned record by actual dev/inode.
"""
import os,errno
actual_close=os.close
actual_fstat=os.fstat
observations=[]

def close(fd):
 st=actual_fstat(fd);identity=[str(st.st_dev),str(st.st_ino)]
 actual_close(fd)
 try:actual_fstat(fd)
 except OSError as e:
  if e.errno!=errno.EBADF:raise
 else:raise AssertionError('close returned but fixture fd remained live')
 observations.append({'fd':fd,'identity':identity,'after_close_errno':errno.EBADF})

def assert_closed(case,result,record):
 try:st=actual_fstat(record['fd'])
 except OSError as e:case.assertEqual(e.errno,errno.EBADF);return
 identity=[str(st.st_dev),str(st.st_ino)]
 case.assertTrue(any(v['fd']==record['fd'] and v['identity']==record['identity'] for v in observations),'historical descriptor must have actual immediate EBADF evidence')
 case.assertTrue(any(v['fd']==record['fd'] and v['state']=='unknown' and v['identity']==identity for v in result['owned_fds'].values()),'later live descriptor must be a separately recorded unknown generation')
