"""Finite-child binding to shared Window mutation/precharge semantics.

No opaque acquiring Window helper is called. Admission's owned parent chain
stays pinned through terminal readback. Every check revalidates all named edges
against those current handles; borrowed Window anchors are never closed here.
This is internal to Controller.run, not a new callable/grant or generic writer.
"""
from reservation import ChildReservation
import os
from pathlib import Path
import stat
from ledger import Stop, CHUNK, inode


class WindowIO:
    def __init__(self, window):
        self.w=window

    def bind(self, fds, records, open_file):
        self.fds=fds;self.records=records;self.open_file=open_file
        self.parts=Path(self.w.parent).parts

    def roots(self):
        w=self.w;previous=None
        if type(w) is ChildReservation:w.validate_binding()
        # '/' is universal. Its owned admission descriptor is retired once the
        # first child is registered; every subsequent ancestor remains pinned.
        for i,part in enumerate(self.parts):
            name='admission_parent_'+str(i);rec=self.records[name]
            if i==0 and len(self.parts)>1:
                named=os.stat('/',follow_symlinks=False)
            else:
                fd=self.fds[name];actual=os.fstat(fd)
                named=os.stat(('/'+part if i else '/') if previous is None else part,dir_fd=previous,follow_symlinks=False)
                if inode(actual)!=inode(named) or not stat.S_ISDIR(actual.st_mode):raise Stop('drift')
                previous=fd
            if [str(n) for n in inode(named)]!=rec['identity'] or not stat.S_ISDIR(named.st_mode):raise Stop('drift')
        if inode(os.fstat(previous))!=w.parent_id or inode(os.stat(w.name,dir_fd=previous,follow_symlinks=False))!=w.root_id:raise Stop('drift')
        root=os.fstat(w.root_fd)
        if inode(root)!=w.root_id or not stat.S_ISDIR(root.st_mode) or stat.S_IMODE(root.st_mode)!=0o700:raise Stop('drift')

    def parent_for(self, p):
        # The closed ChildSpec permits exactly these direct controls slots.
        if p not in ('controls/stdout','controls/stderr','controls/error','controls/receipt'):raise Stop('plan')
        self.roots();w=self.w;fd=w.fds['controls']
        actual=os.fstat(fd);named=os.stat('controls',dir_fd=w.root_fd,follow_symlinks=False)
        if inode(actual)!=w.ids['controls'] or inode(named)!=w.ids['controls'] or not stat.S_ISDIR(actual.st_mode) or not stat.S_ISDIR(named.st_mode) or stat.S_IMODE(actual.st_mode)!=0o700 or stat.S_IMODE(named.st_mode)!=0o700 or 'controls' in w.sealed:raise Stop('drift')
        return fd,p.split('/')[1]

    def new_file(self, p):
        w=self.w
        with w._mutation(p):
            # Same claim ordering: validate slot, validate roots, consume the
            # complete immutable reservation, validate destination, exclusive open.
            if p not in w.plan or w.plan[p][0]!='file' or p in w.used:raise Stop('plan')
            self.roots();w._charge(p,'file')
            parent,leaf=self.parent_for(p)
            out=self.open_file(leaf,leaf,os.O_RDWR|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600,dir_fd=parent)
            if stat.S_IMODE(os.fstat(out).st_mode)!=0o600:raise Stop('metadata')
            return out

    def write(self, fd, p, data, position):
        w=self.w
        with w._mutation(p):
            if type(data) is not bytes or len(data)>CHUNK or position+len(data)>w.plan[p][1]:raise Stop('limit')
            parent,leaf=self.parent_for(p);st=os.fstat(fd);named=os.stat(leaf,dir_fd=parent,follow_symlinks=False)
            if inode(st)!=inode(named) or not stat.S_ISREG(st.st_mode) or st.st_nlink!=1 or st.st_size!=position or stat.S_IMODE(st.st_mode)!=0o600:raise Stop('drift')
            if os.write(fd,data)!=len(data):raise Stop('short_write')
            return position+len(data)
