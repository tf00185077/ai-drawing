"""Task-owned generated children only; standalone runner installs OS policy first."""
import dataclasses
import errno
import hashlib
import json
import math
import os
from pathlib import Path
import signal
import stat
import sys
import threading
import time
import unittest
from unittest.mock import patch
from ledger import Window, Stop

try:
    from contract import ChildSpec, CancelHandle, NormalStop
    import controller as module
    from controller import Controller
except ImportError:
    ChildSpec = None

ROOT = Path(sys.argv[1])
sys.argv[:] = [sys.argv[0]]

class FiniteChildTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(ChildSpec, 'new finite persistent-child component is missing')
        self.root = ROOT/self._testMethodName
        self.root.mkdir(mode=0o700)
        self.root.joinpath('temp').mkdir(mode=0o700)
        self.windows = []

    def tearDown(self):
        for w in self.windows:
            w.close()

    def prepare(self, source, out=4096, err=4096, lifetime=.8, **overrides):
        p=self.root/'child.py';p.write_text(source)
        now=time.monotonic()
        args=dict(operation_id=self._testMethodName, source_id=hashlib.sha256(p.read_bytes()).hexdigest(),
                  argv=('/usr/bin/python3','-I','-S','-B',str(p)), cwd=str(self.root),
                  env=(('PATH','/usr/bin:/bin'),('LC_ALL','C'),('TZ','UTC'),('TMPDIR',str(self.root/'temp'))),
                  source_bytes=p.stat().st_size, start_by=now+.5, run_until=now+.5+lifetime,
                  close_by=now+.5+lifetime+.6, stdout_limit=out, stderr_limit=err,
                  read_chunk=256, max_reads=5000, max_ticks=10000,
                  normal_stop=NormalStop(int(signal.SIGTERM),1,.25), fd_mode='single-process-eof-stdin',fd_ceiling=1048576)
        args.update(overrides);spec=ChildSpec(**args)
        w=Window(self.root,'capture',{'controls/stdout':('file',out),'controls/stderr':('file',err),
                 'controls/error':('file',256),'controls/receipt':('file',32768)})
        self.windows.append(w)
        return w,spec,Controller(w)

    def capture(self,source,**kw):
        w,s,c=self.prepare(source,**kw);r=c.run(s);self.save(r);return w,s,c,r

    def save(self,r,name='result.json'):
        (self.root/name).write_text(json.dumps(r,sort_keys=True,indent=2))

    def assert_file(self,w,slot,raw,r):
        p=w.root/'controls'/slot
        self.assertEqual(p.read_bytes(),raw)
        self.assertEqual(r['streams'][slot]['file_bytes'],len(raw))
        self.assertEqual(r['streams'][slot]['sha256'],hashlib.sha256(raw).hexdigest())
        self.assertTrue(r['streams'][slot]['readback_verified'])

    def assert_accounting(self,w,r):
        a=r['accounting'];self.assertEqual(a['charged']+a['reserved_remaining'],a['plan_total'])
        self.assertEqual(a['plan_total'],sum(x[1] for x in w.plan.values()))
        self.assertEqual(r['protection_verified'],False);self.assertEqual(r['source_start_allowed'],False)
        self.assertEqual(r['retry_b_allowed'],False)
        for v in r['owned_fds'].values():
            if v['state']=='closed':
                with self.assertRaises(OSError) as caught:os.fstat(v['fd'])
                self.assertEqual(caught.exception.errno,errno.EBADF)
        if r['receipt']['state']=='written_verified':
            raw=(w.root/'controls/receipt').read_bytes();saved=json.loads(raw)
            self.assertEqual(r['receipt']['stored_bytes'],len(raw))
            self.assertEqual(r['receipt']['stored_sha256'],hashlib.sha256(raw).hexdigest())
            self.assertEqual(saved['identity'],json.loads(json.dumps(r['identity'])))
            self.assertEqual(saved['receipt']['state'],'attempting')
        for p,v in a['slots'].items():
            if (w.root/p).exists():self.assertGreaterEqual(v['charged'],(w.root/p).stat().st_size)

    def test_first_byte_native_interleaved_and_stdin_eof(self):
        source="""import os,time,logging
assert os.read(0,1)==b''
os.write(1,b'FIRST');os.write(2,b'ERR')
for _ in range(20):
 os.write(1,b'o'*31);os.write(2,b'e'*29);time.sleep(.002)
logging.warning('log')
"""
        w,s,c,r=self.capture(source)
        self.assertTrue(r['capture_complete']);self.assertEqual(r['child']['exit_code'],0)
        self.assert_file(w,'stdout',b'FIRST'+b'o'*620,r)
        self.assert_file(w,'stderr',b'ERR'+b'e'*580+b'WARNING:root:log\n',r)
        self.assertTrue(r['streams']['stdout']['first_byte_at']<r['child']['exit_observed_at'])
        self.assertEqual(r['receipt']['state'],'written_verified')
        self.assertTrue(all(v['state']=='closed' for v in r['owned_fds'].values()))
        self.assert_accounting(w,r)

    def test_sustained_more_than_pipe_buffer_and_exit_before_drain(self):
        w,s,c,r=self.capture("import os\nfor _ in range(500):os.write(1,b'x'*100);os.write(2,b'y'*80)",out=50000,err=40000)
        self.assertTrue(r['capture_complete']);self.assert_file(w,'stdout',b'x'*50000,r)
        self.assert_file(w,'stderr',b'y'*40000,r);self.assert_accounting(w,r)

    def test_eof_while_child_alive_waits_for_actual_exit(self):
        w,s,c,r=self.capture("import os,time\nos.close(1);os.close(2);time.sleep(.12)")
        self.assertTrue(r['capture_complete'])
        self.assertGreater(r['child']['exit_observed_at']-r['streams']['stdout']['eof_at'],60000000)
        self.assertEqual(r['child']['state'],'exited_reaped')

    def test_silent_lifetime_single_owned_stop(self):
        w,s,c,r=self.capture('import time\ntime.sleep(10)',lifetime=.15)
        self.assertEqual(r['primary_error']['code'],'lifetime')
        self.assertEqual(r['child']['normal_stop_attempts'],1)
        self.assertEqual(r['child']['state'],'exited_reaped');self.assertFalse(r['capture_complete'])
        self.assert_accounting(w,r)

    def test_cap_plus_one_sentinel_never_persisted(self):
        w,s,c,r=self.capture("import os\nos.write(1,b'a'*257)",out=256)
        self.assertEqual(r['primary_error']['code'],'output_cap')
        self.assertEqual((w.root/'controls/stdout').read_bytes(),b'a'*256)
        self.assertEqual(r['streams']['stdout']['wire_bytes'],257)
        self.assertEqual(r['streams']['stdout']['file_bytes'],256)
        self.assertFalse(r['capture_complete']);self.assert_accounting(w,r)

    def test_cancel_owned_and_borrowed_pipe(self):
        w,s,c=self.prepare('import time\ntime.sleep(10)')
        rd,wr=os.pipe();os.set_blocking(rd,False);os.write(wr,b'c');os.close(wr)
        st=os.fstat(rd);self.save({'dev':st.st_dev,'ino':st.st_ino},'cancel-identity.json')
        r=c.run(s,CancelHandle(rd,'borrowed'));self.save(r)
        self.assertEqual(r['primary_error']['code'],'cancelled');os.fstat(rd);os.close(rd)
        self.assertEqual(r['cancel_handle']['state'],'borrowed_retained');self.assert_accounting(w,r)

    def test_no_launch_invalid_scalar_alias_stop_and_ownership(self):
        w,s,c=self.prepare("raise RuntimeError('must not launch')")
        invalid=[dataclasses.replace(s,stdout_limit=True),dataclasses.replace(s,run_until=float('nan')),
                 dataclasses.replace(s,read_chunk=0),dataclasses.replace(s,normal_stop=NormalStop(int(signal.SIGKILL),1,.1)),
                 dataclasses.replace(s,env=(('A','1'),('A','2'))),dataclasses.replace(s,fd_mode='inherited'),
                 dataclasses.replace(s,source_id='0'*64),dataclasses.replace(s,argv=('sh','-c','x'))]
        for i,bad in enumerate(invalid):
            rd,wr=os.pipe();os.close(wr)
            with patch.object(module,'spawn',side_effect=AssertionError('launch forbidden')):
                r=Controller(w).run(bad,CancelHandle(rd,'owned'))
            self.assertFalse(r['admitted']);self.assertEqual(r['cancel_handle']['state'],'closed')
            with self.assertRaises(OSError):os.fstat(rd)
            self.assertEqual(list((w.root/'controls').iterdir()),[])
            self.assertEqual(r['accounting']['charged'],0);self.save(r,'invalid-'+str(i)+'.json')
        w.stopped=True
        r=Controller(w).run(s);self.assertEqual(r['primary_error']['code'],'stopped')

    def test_nested_and_concurrent_serial_ownership(self):
        w,s,c=self.prepare("import os\nos.write(1,b'x')")
        nested=[];concurrent=[];original=w.new_file
        def opening(p):
            if not nested:
                nested.append(c.run(s))
                t=threading.Thread(target=lambda:concurrent.append(Controller(w).run(s)));t.start();t.join()
            return original(p)
        with patch.object(w,'new_file',opening):r=c.run(s)
        self.assertTrue(r['capture_complete']);self.assertEqual(nested[0]['primary_error']['code'],'busy')
        self.assertEqual(concurrent[0]['primary_error']['code'],'busy')
        second=c.run(s);self.assertEqual(second['primary_error']['code'],'spent');self.save(r)

    def test_partial_write_eio_keeps_original_charge_and_bytes(self):
        w,s,c=self.prepare("import os\nos.write(1,b'abcdef')")
        original=os.write;injected=[]
        def partial(fd,raw):
            if raw==b'abcdef' and not injected:
                injected.append(fd);return original(fd,raw[:2])
            return original(fd,raw)
        with patch('os.write',partial):r=c.run(s)
        self.assertEqual(r['primary_error']['code'],'short_write')
        self.assertEqual((w.root/'controls/stdout').read_bytes(),b'ab')
        self.assertEqual(r['streams']['stdout']['file_bytes'],2)
        self.assert_accounting(w,r);self.save(r)

    def test_enospc_and_fsync_error(self):
        w,s,c=self.prepare("import os\nos.write(1,b'abcdef')")
        original=w.write
        def full(fd,p,raw,pos):
            if p=='controls/stdout':raise OSError(errno.ENOSPC,'private message never persisted')
            return original(fd,p,raw,pos)
        with patch.object(w,'write',full):r=c.run(s)
        self.assertEqual(r['primary_error']['errno'],errno.ENOSPC)
        self.assertEqual(r['primary_error']['stage'],'capture_stdout')
        self.assertNotIn('private message',json.dumps(r));self.save(r)

    def test_real_keyboard_interrupt_preserved_and_receipt_attempted(self):
        w,s,c=self.prepare('import time\ntime.sleep(10)')
        original=module.selectors.DefaultSelector.select
        original_error=KeyboardInterrupt('private interruption')
        def interrupt(*a,**kw):raise original_error
        with patch.object(module.selectors.DefaultSelector,'select',interrupt):
            with self.assertRaises(KeyboardInterrupt) as caught:c.run(s)
        self.assertIs(caught.exception,original_error)
        r=c.last_result;self.assertEqual(r['primary_error']['class'],'KeyboardInterrupt')
        self.assertEqual(r['child']['state'],'exited_reaped')
        self.assertEqual(r['receipt']['attempts'],1);self.assert_accounting(w,r);self.save(r)

    def test_close_failure_does_not_skip_other_owned_resources(self):
        w,s,c=self.prepare("import os\nos.write(1,b'x')")
        actual_close=os.close;failed=[]
        def close(fd):
            if c.active_child is not None and fd==c.pipe_read_fds.get('stdout') and not failed:
                failed.append(fd);raise OSError(errno.EIO,'close unknown')
            return actual_close(fd)
        with patch('os.close',close):r=c.run(s)
        self.assertEqual(r['owned_fds']['stdout_read']['state'],'unknown')
        self.assertEqual(r['owned_fds']['stderr_read']['state'],'closed')
        self.assertEqual(r['child']['state'],'exited_reaped')
        actual_close(failed[0]);(self.root/'external-harness-fd-cleanup.json').write_text(json.dumps({'fd':failed[0],'component_state':'unknown','harness_close':'returned'}));self.save(r)

    def test_receipt_failure_one_attempt_and_bounded_fallback(self):
        w,s,c=self.prepare("import os\nos.write(1,b'ok')")
        original=os.write;hits=[]
        def write(fd,raw):
            if raw.startswith(b'{') and b'"capture_complete"' in raw:
                hits.append(fd);raise OSError(errno.EIO,'receipt')
            return original(fd,raw)
        with patch('os.write',write):r=c.run(s)
        self.assertEqual(len(hits),1);self.assertEqual(r['receipt']['attempts'],1)
        self.assertEqual(r['receipt']['state'],'failed');self.assertLessEqual(len(r['receipt']['fallback']),256)
        self.assertTrue(r['capture_complete']);self.assertFalse(r['component_complete']);self.save(r)

    def test_uncooperative_child_unknown_then_external_harness_cleanup(self):
        # Stop after readiness byte guarantees the generated child installed its handler.
        w,s,c=self.prepare("import os,signal,time\nsignal.signal(signal.SIGTERM,signal.SIG_IGN)\nos.write(1,b'R');time.sleep(10)",lifetime=.2)
        r=c.run(s);self.assertEqual((w.root/'controls/stdout').read_bytes(),b'R')
        self.assertEqual(r['child']['state'],'running_unverified');self.assertEqual(r['child']['normal_stop_attempts'],1)
        self.assertFalse(r['component_complete']);self.save(r)
        child=c.active_child
        # TEST HARNESS ONLY: current generated known PID, after honest component outcome.
        os.kill(child.pid,signal.SIGKILL)
        until=time.monotonic()+1;reaped=0
        while not reaped and time.monotonic()<until:
            reaped,status=os.waitpid(child.pid,os.WNOHANG)
            if not reaped:time.sleep(.005)
        self.assertEqual(reaped,child.pid);exit_code=os.waitstatus_to_exitcode(status)
        (self.root/'external-harness-cleanup.json').write_text(json.dumps({'pid':child.pid,'signal':signal.SIGKILL,'exit_code':exit_code,'component_result_unchanged':r['child']['state']}))

    def test_nested_owned_alias_cannot_close_active_capture_fd(self):
        w,s,c=self.prepare("import os\nos.write(1,b'live')")
        original=w.new_file;nested=[];fd=[]
        def opening(p):
            if p=='controls/receipt':
                nested.append(c.run(s,CancelHandle(fd[0],'owned')))
                os.fstat(fd[0])
            result=original(p)
            if p=='controls/stdout':fd.append(result)
            return result
        with patch.object(w,'new_file',opening):r=c.run(s)
        self.assertTrue(r['capture_complete']);self.assertEqual(nested[0]['cancel_handle']['state'],'alias_not_transferred')
        self.save(r)

    def test_fsync_failure_keeps_errno_and_other_cleanup(self):
        w,s,c=self.prepare("import os\nos.write(1,b'fsync')")
        original=os.fsync;hit=[]
        def fail(fd):
            if not hit:hit.append(fd);raise OSError(errno.EIO,'sync')
            return original(fd)
        with patch('os.fsync',fail):r=c.run(s)
        self.assertEqual(r['primary_error']['stage'],'readback_stdout')
        self.assertEqual(r['primary_error']['errno'],errno.EIO)
        self.assertFalse(r['component_complete']);self.assertFalse(r['streams']['stdout']['readback_verified'])
        self.assertEqual(r['owned_fds']['receipt']['state'],'closed');self.save(r)

    def test_pipe_error_nonzero_child_and_lost_start_outcome(self):
        w,s,c=self.prepare("import os\nos.write(2,b'failure');raise SystemExit(7)")
        r=c.run(s);self.assertEqual(r['child']['exit_code'],7)
        self.assertEqual(r['primary_error']['code'],'child_exit');self.assert_file(w,'stderr',b'failure',r);self.save(r)

    def test_pipe_read_eio_and_full_charge(self):
        w,s,c=self.prepare("import os\nos.write(1,b'pipe')")
        original=os.read
        def read(fd,size):
            if fd==c.pipe_read_fds.get('stdout'):raise OSError(errno.EIO,'pipe')
            return original(fd,size)
        with patch('os.read',read):r=c.run(s)
        self.assertEqual(r['primary_error']['errno'],errno.EIO)
        self.assertEqual(r['primary_error']['stage'],'capture_stdout');self.assert_accounting(w,r);self.save(r)

    def test_failed_create_keeps_unused_reservations_owned_cancel_closed(self):
        w,s,c=self.prepare("raise RuntimeError('not launched')")
        rd,wr=os.pipe();os.set_blocking(rd,False);os.close(wr)
        original=w.new_file
        def create(p):
            if p=='controls/stderr':raise OSError(errno.ENOSPC,'create')
            return original(p)
        with patch.object(w,'new_file',create),patch.object(module,'spawn',side_effect=AssertionError('no launch')):
            r=c.run(s,CancelHandle(rd,'owned'))
        self.assertEqual(r['accounting']['charged'],4096)
        self.assertEqual(r['accounting']['reserved_remaining'],37120)
        self.assertEqual(r['child']['state'],'not_started');self.assertEqual(r['cancel_handle']['state'],'closed')
        self.assertEqual(r['receipt']['attempts'],1);self.assert_accounting(w,r);self.save(r)

    def test_unknown_spawn_does_not_claim_no_child_or_retry(self):
        w,s,c=self.prepare("raise RuntimeError('not launched')")
        with patch.object(module,'spawn',side_effect=OSError(errno.EIO,'lost acknowledgement')):r=c.run(s)
        self.assertEqual(r['child']['state'],'start_outcome_unknown');self.assertEqual(r['child']['normal_stop_attempts'],0)
        self.assertFalse(r['component_complete']);self.assert_accounting(w,r);self.save(r)

    def test_extra_slot_and_alias_are_refused_without_launch(self):
        w,s,c=self.prepare("raise RuntimeError('not launched')")
        alias=c.run(s,CancelHandle(w.root_fd,'owned'))
        self.assertEqual(alias['primary_error']['code'],'alias');os.fstat(w.root_fd)
        self.assertEqual(alias['cancel_handle']['state'],'alias_not_transferred')
        from types import MappingProxyType
        old=dict(w.plan);old['controls/extra']=('file',1);w.plan=MappingProxyType(old)
        r=Controller(w).run(s);self.assertEqual(r['primary_error']['code'],'plan')
        self.assertEqual(list((w.root/'controls').iterdir()),[]);self.save(r)

    def test_explicit_environment_no_extra_inherited_fd(self):
        rd,wr=os.pipe()
        try:
            source="import os,errno\nassert os.environ.get('M3_AMBIENT_TEST') is None\ntry:os.fstat(%d)\nexcept OSError as e:assert e.errno==errno.EBADF\nelse:raise AssertionError('inherited fd')\nos.write(1,b'clean')" % wr
            w,s,c=self.prepare(source)
            os.environ['M3_AMBIENT_TEST']='synthetic-parent-only'
            try:r=c.run(s)
            finally:os.environ.pop('M3_AMBIENT_TEST')
            self.assertTrue(r['component_complete']);self.assert_file(w,'stdout',b'clean',r);self.save(r)
        finally:os.close(rd);os.close(wr)

    def test_actual_exit_before_drain_does_not_drop_tail(self):
        w,s,c=self.prepare("import os\nos.write(1,b'x'*10000)",out=10000,lifetime=1.5)
        original=w.write
        def slower(fd,p,raw,pos):time.sleep(.002);return original(fd,p,raw,pos)
        with patch.object(w,'write',slower):r=c.run(s)
        self.assertTrue(r['component_complete']);self.assert_file(w,'stdout',b'x'*10000,r)
        self.assertLess(r['child']['exit_observed_at'],r['streams']['stdout']['eof_at']);self.save(r)

    def test_receipt_partial_write_records_full_actual_partial(self):
        w,s,c=self.prepare("import os\nos.write(1,b'ok')")
        original=os.write
        def partial(fd,raw):
            if raw.startswith(b'{') and b'"capture_complete"' in raw:return original(fd,raw[:13])
            return original(fd,raw)
        with patch('os.write',partial):r=c.run(s)
        actual=(w.root/'controls/receipt').read_bytes()
        self.assertEqual(len(actual),13);self.assertEqual(r['receipt']['stored_bytes'],13)
        self.assertEqual(r['receipt']['stored_sha256'],hashlib.sha256(actual).hexdigest())
        self.assertFalse(r['component_complete']);self.assertEqual(r['receipt']['attempts'],1);self.save(r)

    def test_start_handshake_is_deadline_bound_before_exec(self):
        w,s,c=self.prepare("import os\nos.write(1,b'never')")
        s=dataclasses.replace(s,start_by=time.monotonic()+.05)
        try:
            from fork_exec import Child
        except ImportError:
            self.fail('finite pre-exec status-pipe mechanism missing')
        actual=os.execve
        def slow(*args):time.sleep(.5);return actual(*args)
        with patch('os.execve',slow):r=c.run(s)
        self.assertEqual(r['primary_error']['code'],'start_deadline')
        self.assertEqual(r['child']['state'],'exited_reaped');self.assertFalse(r['component_complete'])
        self.assertEqual((w.root/'controls/stdout').read_bytes(),b'');self.save(r)

    def test_actual_exec_error_errno_and_finite_status(self):
        w,s,c=self.prepare("raise RuntimeError('not execed')")
        def fail(*args):raise OSError(errno.EACCES,'exec private')
        with patch('os.execve',fail):r=c.run(s)
        self.assertEqual(r['primary_error']['stage'],'exec_handshake')
        self.assertEqual(r['primary_error']['errno'],errno.EACCES)
        self.assertEqual(r['child']['start_status_bytes'],5)
        self.assertEqual(r['child']['state'],'exited_reaped');self.save(r)

    def test_owned_cancel_on_success_is_closed_once(self):
        w,s,c=self.prepare("import os\nos.write(1,b'ok')")
        rd,wr=os.pipe();os.set_blocking(rd,False)
        try:r=c.run(s,CancelHandle(rd,'owned'))
        finally:os.close(wr)
        self.assertTrue(r['component_complete']);self.assertEqual(r['cancel_handle']['state'],'closed')
        self.assertEqual(r['cancel_handle']['close_attempts'],1)
        with self.assertRaises(OSError):os.fstat(rd)
        self.save(r)

    def test_main_thread_mode_and_low_fd_ceiling_refuse_prelaunch(self):
        w,s,c=self.prepare("raise RuntimeError('not execed')")
        r=c.run(dataclasses.replace(s,fd_ceiling=4))
        self.assertEqual(r['primary_error']['code'],'unsupported')
        values=[]
        t=threading.Thread(target=lambda:values.append(Controller(w).run(s)));t.start();t.join()
        self.assertEqual(values[0]['primary_error']['code'],'unsupported')
        self.assertEqual(list((w.root/'controls').iterdir()),[]);self.save(r)

    def test_real_system_exit_and_secondary_cleanup_interrupt(self):
        w,s,c=self.prepare("import os\nos.write(1,b'x')")
        primary=SystemExit(23);secondary=KeyboardInterrupt('secondary');original_write=w.write;original_close=os.close;once=[]
        def writing(*a,**kw):raise primary
        def closing(fd):
            if c.active_child is not None and fd==c.pipe_read_fds.get('stdout') and not once:
                once.append(fd);raise secondary
            return original_close(fd)
        with patch.object(w,'write',writing),patch('os.close',closing):
            with self.assertRaises(SystemExit) as caught:c.run(s)
        self.assertIs(caught.exception,primary);r=c.last_result
        self.assertEqual(r['primary_error']['class'],'SystemExit')
        self.assertTrue(any(e['class']=='KeyboardInterrupt' for e in r['secondary_errors']))
        self.assertEqual(r['owned_fds']['stderr_read']['state'],'closed')
        original_close(once[0]);(self.root/'external-harness-fd-cleanup.json').write_text(json.dumps({'fd':once[0],'component_state':'unknown','harness_close':'returned'}));self.save(r)

    def test_pre_exec_chdir_error_keeps_original_stage_errno(self):
        w,s,c=self.prepare("raise RuntimeError('not execed')")
        def fail(*args):raise OSError(errno.EACCES,'chdir private')
        with patch('os.fchdir',fail):r=c.run(s)
        self.assertEqual(r['primary_error']['stage'],'child_chdir')
        self.assertEqual(r['primary_error']['errno'],errno.EACCES)
        self.assertEqual(r['child']['state'],'exited_reaped');self.save(r)

    def test_lost_child_ownership_never_signals_unknown_pid(self):
        w,s,c=self.prepare('import time\ntime.sleep(10)')
        from fork_exec import Child
        with patch.object(Child,'poll',side_effect=OSError(errno.ECHILD,'lost child outcome')):r=c.run(s)
        self.save(r)
        try:
            self.assertEqual(r['child']['normal_stop_attempts'],0)
            self.assertEqual(r['child']['state'],'outcome_unknown');self.assertFalse(r['component_complete'])
        finally:
            os.kill(c.active_child.pid,signal.SIGKILL);until=time.monotonic()+1;reaped=0
            while not reaped and time.monotonic()<until:
                reaped,status=os.waitpid(c.active_child.pid,os.WNOHANG)
                if not reaped:time.sleep(.005)
            self.assertEqual(reaped,c.active_child.pid)
            (self.root/'external-harness-cleanup.json').write_text(json.dumps({'pid':reaped,'signal':signal.SIGKILL,'exit_code':os.waitstatus_to_exitcode(status),'component_state':'outcome_unknown'}))

if __name__=='__main__':unittest.main(verbosity=2)
