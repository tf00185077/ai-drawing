## Current candidate: aid80-helper-ownership-v1

The public `Controller.run(ChildSpec, CancelHandle|None)` and admitted child
profile are unchanged. `window_io.py` is a local integration binding, not a new
writer grant. Frozen M1/G09/M2 source and their separate verdicts stay unchanged.
The older sections below describe their own frozen revisions.

The controller now registers output acquisition intent and the returned FD BEFORE
its first fstat or mode validation. Output creation and chunk writes use
`WindowIO`, with the same Window `_mutation`, immutable plan, slot/type/used
checks and complete charge-before-exclusive-open ordering. It never calls
Window's acquiring roots/claim/parent_for/new_file/write helpers. Admission's
registered parent chain remains owned through ALL later path, output, readback
and terminal checks. The universal root descriptor is retired once its first
child is registered; the first edge is checked by an absolute no-follow stat,
all other edges by no-follow stat relative to the preceding pinned handle, each
joined to actual fstat and original dev/inode. Root/controls borrowed anchors are
revalidated and never closed by the component. This retains path replacement
checks without new directory acquisition on each output chunk/finalizer.

Parent-chain closure follows receipt readback, independently once per FD. The
persisted receipt records those pins OPEN; it cannot certify their later close
or its own future close. Returned final outcomes and original/secondary errors
record actual known closure or unknown; late close failure still stops shared
reentry and prevents component_complete. No cleanup retry/refund/deletion or
new writer follows uncertainty. Output validation interruptions preserve exact
primary objects, open_stdout/etc stage and full charges; unavailable identity
stays null. A known returned FD gets at most one further cleanup identity attempt
before its single close (readback may independently attempt an identity check).

Pipe pairs have BOTH intents before the syscall and BOTH returned numbers before
identity validation. Selector construction has a before-call unknown intent;
returned native selector FD/identity is tracked and its owning close method is
attempted once. An interrupted helper return stays fd=null/unknown; no host scan,
guessed descriptor, closure retry or signal follows. Known-new fixture resources
may be separately cleaned by the harness only after the honest component outcome.

The complete pre-effect receipt envelope now has at most110 resource names:
32 admission cwd +32 admission parent +31 pre-exec cwd +15 fixed names (the old14
plus selector). No new field shape, error count, slot, capacity or native width is
introduced. `receipt_bound.py` encodes the WHOLE envelope with exact identity/env,
all110 names and optional fields,32 secondary errors and original widths using
the unchanged bounded encoder. Error256, receipt32768 and aggregate
CAP128849018880 remain fixed. Full success and error controls independently
check the entire envelope with Python JSON encoding; observed receipt lengths
are validation, never a substitute for the pre-effect proof.

Use only NEW absolute fixture roots:

```
python3 tools/m3_finite_child/run_handoff.py NEW_ROOT_31 component
python3 tools/m3_finite_child/run_handoff.py NEW_ROOT_14 qa77
python3 tools/m3_finite_child/run_handoff.py NEW_ROOT_FOCUSED focused
python3 tools/m3_finite_child/run_handoff.py NEW_ROOT_QA79 qa79
python3 tools/m3_finite_child/run_handoff.py NEW_ROOT_HANDOFF handoff
```

Original31, original14/adapted14 and focused14 bytes remain intact. New companion
controls move only Window new_file/write hooks to the actual Controller._io
methods; the31 helper adds immediate-EBADF/current-generation observation already
used by adapted14. Their acceptance assertions stay. The qa79 first eight
criteria remain with the justified110-name envelope; test09 targets actual
parent-traversal close before helper return and test10 accepts closed+EBADF or
honest unknown current generation, without requiring a leak. Exact originals,
diffs and real fault-hit/identity/attempts are delivered separately. Original
fault-confirmation scripts still assert defects and are DATA, not GREEN criteria.

Synchronous syscall timing/unobservable return limits remain. This is finite
synthetic component evidence only; it does not change the prepared launcher,
release M1/M2/M3/A1/I1/operation gates, accept runtime/real delivery/aesthetics,
adopt source or authorize deployment.

# Finite persistent-child capture component

This is source work for W06/W16, independent of W19. It is not an operational
launcher, full native profile, endpoint, permission or release mechanism. Existing
M1, M2 and exact110 remain unchanged. No production command is accepted here.

`Controller(window).run(ChildSpec(...), CancelHandle(...) | None)` is the sole
supported mutating entry. All parameters are explicit, immutable dataclasses;
there are no real-operation defaults. `ChildSpec` binds a named single Python
source file (maximum65536bytes, SHA256 and inode/length/timestamps), exact argv,
absolute cwd/inode, complete env tuple, source/operation identity, positive output
limits, read chunk/count/tick limits, absolute monotonic start/run/close deadlines,
normal-stop count/signal/wait, FD mode and explicit FD ceiling. Command identity
also binds all four destinations, ledger root identity and cancellation role/FD
identity. The source API is cooperative: it is not protection against arbitrary
Python, a caller replacing immutable inputs, a native writer or concurrent source
mutation. Source/cwd and ledger destinations must remain exclusively controlled.

A pre-existing, independently admitted M1 `Window` is **borrowed**. Its creator's
root/stage-directory effects and eventual directory-anchor closure are outside
this callable. Read its actual `ledger.py` contract. The plan must be exactly:

| Slot | Full reservation |
|---|---|
| controls/stdout | ChildSpec.stdout_limit |
| controls/stderr | ChildSpec.stderr_limit |
| controls/error | 256 |
| controls/receipt | 32768 |

All inputs, scalar types, finite limits, aggregate cap, slots/cardinality,
destinations/absence/alias, source/cwd identity, stop and serial ownership are
validated before this callable creates a child, pipe or output. An invalid
admission creates none of those. A supplied valid owned cancellation FD transfers
at entry and receives one bounded close attempt even on rejection; a borrowed
one remains open and its flags are unchanged. Aliases to Window or active
component-owned FDs reject transfer. Error outcomes state actual retained/unknown
ownership. No caller `safe` boolean or new dynamically chosen output slot exists.

All four files are opened exclusively through M1 Window before pipe/child
creation. M1 charges each **full** slot before its first effect; every subsequent
chunk is therefore already fully charged. stdout/stderr have separate closed
slots on this **one aggregate ledger**, with no independent refill, refund,
borrowing, deletion credit or after-write accounting. Unused reservations and
actual partial lengths/hashes remain separate from charges. Structural/native
metadata and physical allocation are not estimated as zero by this payload ledger.

The component prebinds EOF stdin, blocking child stdout/stderr writers and
nonblocking parent readers. One single-threaded POSIX fork performs a closed
fchdir/dup2/close/exec sequence. fd0/1/2 are the exact bound pipes; fd3 is a fixed
five-byte CLOEXEC exec-status pipe; all fd indices4 through fd_ceiling-1 close
before exec. SC_OPEN_MAX must fit the explicit ceiling; unsupported thread/FD
modes reject before launch. The admitted profile requires no descriptors beyond
that ceiling, no descendants and exclusive ownership through this sequence;
these are supported-profile restrictions, not a grant or proof of arbitrary
caller isolation. Native syscalls, including fork/fsync/close, are synchronous;
this is a finite operation/count/deadline controller under the available local
system component, not hard real-time preemption of a stuck kernel/device. Such a
blocked/native/remote filesystem mode has no supported finite timing guarantee.

The selector handles both interleaved streams continuously during startup and
run, bounded by read_chunk, max_reads, max_ticks and absolute deadlines. Start
acknowledgement uses that finite selector loop instead of Popen's blocking
exec-error handshake. A full output slot gets a one-byte sentinel read: that
byte is observed and never persisted. EOF and actual waitpid(WNOHANG) exit/reap
are separately observed. EOF does not finish a live child; exit does not discard
undrained bytes. Kernel pipe buffers are nonzero physical demand, not retained
file payload. This component does not bound other direct/native/OS writes.

Only a declared count0 or count1 normal SIGTERM is supported; count1 applies only
to the exact owned child when still alive, with a bounded wait. There is no kill,
process-tree scan, service signal, automatic retry or fallback writer. A lost waitpid outcome prohibits further signalling of that PID. Poll,
signal, each pipe/file/cancel closure and selector closure are independently
attempted and reported, even after earlier errors or BaseException. Failure of
an OS close is unknown, never closed. A failed/missing spawn acknowledgement is
start_outcome_unknown. An uncooperative child remains running_unverified unless
its actual exit/reap is observed. Test-harness force cleanup of its own generated
fixture is separately recorded after that component result; it is not exported.

First error classification, errno and stage remain primary; later cleanup errors
are separate. Error messages/tracebacks are never persisted. Real KeyboardInterrupt
and SystemExit are re-raised as the same objects after cleanup; `last_result` and
`original_error` retain the result and original exception in memory. No resume
around unknown accounting is permitted. A failure latches Window stopped.

Readback verifies each entire bounded persisted stream, its file identity, actual
length and SHA256; partial writes are neither truncated nor refunded. The
terminal finalizer may write only the already opened/charged error/receipt files
once, including after stop. It validates path/inode/size, fsyncs and reads back;
receipt errors get a bounded sanitized return fallback, never another writer.
Actual partial receipt length/hash and failed closure remain separate.

The receipt necessarily precedes its own write/fsync/readback/close: its
`receipt.state=attempting`, open receipt FD and component_complete=false are
intentional. The returned final outcome reports those later operations; a native
outer evidence record can persist it independently under its own accounting.
Do not claim a self-certifying durable final-close receipt. `capture_complete`
requires EOF, exit0 and complete payload readbacks. `component_complete` also
requires no error, a verified receipt and actual owned-resource closure.
protection_verified/source_start_allowed/retry_b_allowed are always false.

## Isolated verification

Use available administrative Python to prepare one **new** task-owned root:

```
python3 tools/m3_finite_child/run_tests.py NEW_ABSOLUTE_TASK_SCRATCH_ROOT
```

The wrapper copies source and creates exact fixture roots/env/profile before
component import or child exec. sandbox-exec denies network, writes outside the
new root and reads of product/data/prepared/backup roots. It executes only new
generated children under /usr/bin/python3 -I -S -B, never root pytest/conftest,
Settings/app/DB/engine/Uvicorn/ASGI. It grants no production confinement. The
system interpreter may add platform keys before Python code; only the submitted
env is the callable's no-inheritance claim. This does not certify an entire
native loader environment, side effect envelope or private installed runtime.

## Future integration delta, presently unavailable

The unchanged original AID66 baseline remains cwd=R/backend:

```
[PREPARED/backend-venv/bin/python,-I,-B,-m,uvicorn,--app-dir,R/backend,
 app.main:app,--host,127.0.0.1,--port,8001]
```

R=/Users/tf00185088/Desktop/tim-project/ai-drawing;
PREPARED=/Users/tf00185088/Desktop/tim-project/.ai-drawing-prepared-environments/7796fed8-398a-4d7c-b777-6e273514a5ce.
Its six explicit env settings remain AI_DRAWING_MAINTENANCE=closed,
AI_DRAWING_MAINTENANCE_OWNER=<actualIssueId>/backend,
AI_DRAWING_MAINTENANCE_EPOCH=<savedEpoch>, COMFYUI_MODE=external, WATCH_DIRS="",
COMFYUI_RECORD_EXTERNAL=false. No actual future owner/epoch, OS/library env,
source set, sink/pool, startup/lifetime/close/capture/traffic numbers are supplied.

This component accepts only the named available fixture interpreter/file argv;
it rejects that original prepared command. Any future integration must separately
review the executable/source/native profile and explicit argv/env semantics,
replace inherited stdin/out/err with these owned pipes, bind all other FDs,
prove the supported no-descendant/FD-ceiling mode (or implement a different finite
supported mode), provide exact finite lifetime/start/close/read/output/error and
receipt bounds/actual input identities, authorize the normal-stop action and
account every wrapper/slot/temp/metadata/post-state/full later-copy destination.
No implicit flag, -S, protocol/loop or default substitution is adopted. Remaining
W01-W05/W07-W20 scope, native direct writes, D_S/M/U, M2 operational DB profile,
A1/I1 actual actors/numbers, real grant, protection/restore/caller/compute/local
closure and release remain unavailable. W19's pending proposal grants nothing.
No deployment/merge/adoption is performed; Engineering QA independently reviews
the fixed candidate and Producer decides subsequent scope.

## aid78-finite-repair-v1: four failed boundaries

The public Controller/ChildSpec/CancelHandle call shape and the four immutable
Window slots remain the same. `validate` is an internal helper and now receives
controller-owned acquisition callbacks; it is not a new callable command grant.
No G09/M1/M2, product, prepared runtime or original launcher change is included.

Admission and pre-exec path opens now have an intent before acquisition and a
registry entry before fstat/read. Every known FD records its decimal dev/inode,
close attempt and closed/unknown outcome. A true interrupted open without a
returned FD records unknown with fd=null; no FD search or guessed close follows.
Known owned FDs each receive one independent close attempt. Primary BaseException
identity survives secondary cleanup; unknown acquisition/close stops the
controller and shared Window. Refusals that acquire nothing and cleanly dispose
supplied cancel ownership remain distinct. Once admission resources were opened,
a failed admission stops reuse even if its known handles closed. Borrowed anchors
and cancel handles retain their caller ownership.

To keep this complete resource history finitely representable, this profile
supports absolute source/cwd and Window-parent paths of at most32 components
(including `/`) and1024 UTF-8 bytes; source cwd `/` is unsupported. It refuses
unsupported cardinalities before output/pipe/child creation. Closed records are
historical FD generations: a later allocation may reuse a numeric FD, so compare
actual identity and closure observations instead of interpreting every past number
as a currently allocated handle. New native file identities are decimal strings.

`receipt_bound.py` encodes an explicit upper envelope with the unchanged M1 JSON
encoder before any output/pipe/child effect. It includes the EXACT full identity
and JSON escapes, all admission/pre-exec/pipe/file FD names (at most109), primary
plus32 secondary errors (class/stage64 sanitized ASCII chars), both complete
stream records, native identity widths, child/status/stop values, four accounting
slots, error/receipt partials, fallback and final receipt fields. Native profile
widths are signed32 FD/PID, uint64 decimal identities and signed64 monotonic ns.
It covers optional returned fields after receipt persistence too. No arbitrary
slack, slot enlargement, extra reservation, truncation or new writer is used.
Known oversized ASCII/escaped identities refuse with zero output/pipe/child
creation and zero Window charge. Genuine later IO/receipt failures still retain
one attempt, bounded fallback and actual partial accounting.

Output EOF and actual child reap no longer settle a waiting exec protocol. The
same original start/run deadlines, read/tick counts and five-byte status protocol
apply independently; missing, partial and broken status remains failed/unknown.
Wrong Window types are refused before any Window attribute access, including
cancel cleanup and final snapshot. This remains an invalid-input refusal.

Verification (NEW absolute roots only; wrapper installs OS isolation first):

```
python3 tools/m3_finite_child/run_tests.py NEW_ROOT_31
python3 tools/m3_finite_child/run_repairs.py NEW_ROOT_14 independent
python3 tools/m3_finite_child/run_repairs.py NEW_ROOT_FOCUSED focused
```

`test_component.py`/`run_tests.py` retain the original31 body/wrapper bytes.
`independent_tests.py` retains the original QA14 bytes. `qa77_adapted.py` changes
only its shared historical-FD check and adds fixture close observations: actual
EBADF immediately after a successful close, and actual identity join to a
separately recorded later unknown generation when its number has been reused.
Its test bodies/acceptance assertions are retained. `fd_observer.py` is test-only.
`repair_tests.py` adds positive interruption/acquisition/stop/exec/receipt/Window
controls, separate from unchanged historical defect-confirmation scripts.
Counts are distinct scopes, never a sum of repeated runs. The native handoff and
archive retain every original RED, development/harness error and final raw log.

The finite available-system-Python cooperative profile, normal-stop count and
synchronous syscall timing limitations remain as documented above. Tests do not
prove full native confinement, complete startup effects, actual prepared-command
support, runtime adoption, service/DB/source operation permission, source-start/B
release, protection/restore, real delivery or CTY aesthetic acceptance. Independent
QA remains a separate Producer-routed frozen-candidate verdict. Deployment remains
a separately authorized Environment operation.


## Unadopted composition candidate

See [COMPOSITION.md](../../../COMPOSITION.md) for one-shot views over an operation
parent ledger, shared stop propagation and nonconsuming cancellation readiness.
The exact-four standalone boundary and original argv refusal remain.
