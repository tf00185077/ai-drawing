"""Positive repair controls. Historical QA diagnostic scripts stay unchanged."""
import qa77_adapted as iq
import unittest,os,errno,dataclasses,json,time,stat
from unittest.mock import patch
from controller import Controller
from contract import CancelHandle
import controller as mod

class RepairTests(unittest.TestCase):
 setUp=iq.IndependentQA.setUp
 tearDown=iq.IndependentQA.tearDown
 prepare=iq.IndependentQA.prepare
 save=iq.IndependentQA.save
 check=iq.IndependentQA.check
 def no_effect(self,w,r):
  self.assertFalse(r['admitted']);self.assertEqual(w.snapshot()['charged'],0);self.assertEqual(list((w.root/'controls').iterdir()),[]);self.assertEqual(r['child']['state'],'not_started')
 def test_primary_read_interrupt_and_unknown_source_stop_shared_reentry(self):
  w,s,c=self.prepare();opened=[];failed=[];op=os.open;cl=os.close;rd=os.read;primary=KeyboardInterrupt('original');caught=None
  def opening(path,flags,*a,**k):
   fd=op(path,flags,*a,**k)
   if path=='child.py':opened.append(fd)
   return fd
  def reading(fd,n):
   if fd in opened:raise primary
   return rd(fd,n)
  def closing(fd):
   if fd in opened and not failed:failed.append(fd);raise OSError(errno.EIO,'secondary')
   return cl(fd)
  try:
   with patch('os.open',opening),patch('os.read',reading),patch('os.close',closing):
    try:c.run(s)
    except BaseException as e:caught=e
   r=c.last_result;self.save('result',r);self.assertIs(caught,primary);self.assertIs(c.original_error,primary);self.no_effect(w,r)
   st=os.fstat(failed[0]);rec=next(v for v in r['owned_fds'].values() if v['fd']==failed[0]);self.assertEqual(rec['state'],'unknown');self.assertEqual(rec['identity'],[str(st.st_dev),str(st.st_ino)]);self.assertEqual(rec['close_attempts'],1)
   self.assertEqual(r['primary_error']['class'],'KeyboardInterrupt');self.assertEqual(r['secondary_errors'][0]['errno'],errno.EIO);self.assertTrue(w.stopped);self.assertTrue(c.spent);self.assertEqual(r['receipt']['attempts'],1)
   with patch.object(mod,'spawn',side_effect=AssertionError('launch forbidden')),patch('os.pipe',side_effect=AssertionError('pipe forbidden')):
    for other in [c,Controller(w)]:self.no_effect(w,other.run(s))
   with self.assertRaises(Exception):w.stream('controls/stdout',[b'forbidden'])
   self.assertEqual(w.snapshot()['charged'],0)
  finally:
   for fd in failed:cl(fd)
   self.save('external-cleanup',{'known_new_fds':failed,'harness_close':'returned'})
 def test_directory_close_interrupt_accounts_each_acquired_fd(self):
  w,s,c=self.prepare();op=os.open;cl=os.close;acquired=[];attempts=[];failed=[];primary=SystemExit(23);caught=None
  def opening(path,flags,*a,**k):
   fd=op(path,flags,*a,**k);acquired.append((fd,list(os.fstat(fd)[:2])));return fd
  def closing(fd):
   attempts.append(fd)
   if acquired and fd==acquired[0][0] and not failed:failed.append(fd);raise primary
   return cl(fd)
  try:
   with patch('os.open',opening),patch('os.close',closing):
    try:r=c.run(s)
    except BaseException as e:caught=e;r=c.last_result
   self.save('result',r);self.assertIs(caught,primary);self.assertIs(c.original_error,primary);self.no_effect(w,r);self.assertTrue(w.stopped)
   records=list(r['owned_fds'].values());self.assertEqual(len(records),len(acquired))
   for rec in records:
    self.assertEqual(rec['close_attempts'],1)
    if rec['state']=='closed':
     with self.assertRaises(OSError) as x:os.fstat(rec['fd'])
     self.assertEqual(x.exception.errno,errno.EBADF)
    else:os.fstat(rec['fd'])
  finally:
   for fd in failed:cl(fd)
   self.save('external-cleanup',{'fds':failed,'harness_close':'returned'})
 def test_open_outcome_unknown_retains_intent_and_stops_without_guessing_fd(self):
  w,s,c=self.prepare();op=os.open;cl=os.close;leaked=[];primary=KeyboardInterrupt('after acquisition');caught=None
  def opening(path,flags,*a,**k):
   fd=op(path,flags,*a,**k)
   if path=='child.py':leaked.append(fd);raise primary
   return fd
  try:
   with patch('os.open',opening):
    try:c.run(s)
    except BaseException as e:caught=e
   r=c.last_result;self.save('result',r);self.assertIs(caught,primary);self.assertIs(c.original_error,primary);self.no_effect(w,r);self.assertTrue(w.stopped);self.assertTrue(c.spent)
   st=os.fstat(leaked[0]);self.save('known-fixture-live-fd',{'fd':leaked[0],'identity':[str(st.st_dev),str(st.st_ino)]})
   rec=r['owned_fds']['admission_source'];self.assertEqual(rec['state'],'unknown');self.assertIsNone(rec['fd']);self.assertEqual(rec['close_attempts'],0);self.assertEqual(r['receipt']['attempts'],1)
   self.no_effect(w,Controller(w).run(s))
  finally:
   for fd in leaked:cl(fd)
   self.save('external-cleanup',{'fds':leaked,'harness_close':'returned'})
 def test_source_fstat_interrupt_closes_registered_acquisition(self):
  w,s,c=self.prepare();op=os.open;fs=os.fstat;fdlist=[];primary=KeyboardInterrupt('fstat');caught=None
  def opening(path,flags,*a,**k):
   fd=op(path,flags,*a,**k)
   if path=='child.py':fdlist.append(fd)
   return fd
  def fstat(fd):
   if fd in fdlist:raise primary
   return fs(fd)
  with patch('os.open',opening),patch('os.fstat',fstat):
   try:c.run(s)
   except BaseException as e:caught=e
  r=c.last_result;self.save('result',r);self.assertIs(caught,primary);self.no_effect(w,r)
  for fd in fdlist:
   with self.assertRaises(OSError) as x:fs(fd)
   self.assertEqual(x.exception.errno,errno.EBADF)
  self.assertTrue(any(v['fd'] in fdlist and v['state']=='closed' for v in r['owned_fds'].values()))
 def test_no_effect_invalid_plan_remains_reusable_but_unknown_cancel_stops(self):
  w,s,c=self.prepare();r=c.run(dataclasses.replace(s,max_reads=True));self.no_effect(w,r);self.assertFalse(w.stopped);self.assertFalse(c.spent)
  rd,wr=os.pipe();os.set_blocking(rd,False);cl=os.close
  try:
   def closing(fd):
    if fd==rd:raise OSError(errno.EIO,'owned cancel')
    return cl(fd)
   with patch('os.close',closing):r=c.run(dataclasses.replace(s,max_reads=True),CancelHandle(rd,'owned'))
   self.save('result',r);self.no_effect(w,r);self.assertTrue(w.stopped);self.assertTrue(c.spent);self.assertEqual(r['cancel_handle']['state'],'unknown');os.fstat(rd)
   self.no_effect(w,Controller(w).run(s))
  finally:cl(rd);cl(wr)
 def test_wrong_window_primary_refusal_and_secondary_cancel_close(self):
  w,s,c=self.prepare();rd,wr=os.pipe();os.set_blocking(rd,False);cl=os.close;bad=Controller(None)
  try:
   def closing(fd):
    if fd==rd:raise OSError(errno.EIO,'owned cancel')
    return cl(fd)
   with patch('os.close',closing):r=bad.run(s,CancelHandle(rd,'owned'))
   self.save('result',r);self.assertEqual(r['primary_error']['code'],'plan');self.assertEqual(r['primary_error']['stage'],'admission');self.assertEqual(r['secondary_errors'][0]['errno'],errno.EIO);self.assertIsNotNone(bad.original_error);self.assertIs(r,bad.last_result);self.assertIsNone(r['accounting']);self.assertEqual(r['cancel_handle']['state'],'unknown');self.assertTrue(bad.spent);os.fstat(rd)
  finally:cl(rd);cl(wr)
 def test_wrong_window_is_never_dereferenced_even_for_cancel_cleanup(self):
  w,s,c=self.prepare();rd,wr=os.pipe();os.set_blocking(rd,False)
  class Wrong:
   def __getattribute__(self,name):raise AssertionError('wrong Window dereferenced')
  bad=Controller(Wrong())
  try:
   r=bad.run(s,CancelHandle(rd,'owned'));self.save('result',r);self.assertEqual(r['primary_error']['code'],'plan');self.assertEqual(r['cancel_handle']['state'],'closed');self.assertIsNotNone(bad.original_error)
   with self.assertRaises(OSError) as x:os.fstat(rd)
   self.assertEqual(x.exception.errno,errno.EBADF)
  finally:
   # Only the supplied known-new fixture descriptor is eligible for cleanup.
   try:os.fstat(rd)
   except OSError:pass
   else:os.close(rd)
   os.close(wr)
 def test_known_oversize_ascii_and_json_escape_refuse_before_effects(self):
  for label,pads in [('ascii',tuple(('PAD_'+str(i),'z'*4096) for i in range(9))),('escape',(('PAD','\x01'*4096),))]:
   if label!='ascii':self.root=self.root/'second';self.root.mkdir();(self.root/'temp').mkdir()
   w,s,c=self.prepare();s=dataclasses.replace(s,env=s.env+pads)
   with patch.object(mod,'spawn',side_effect=AssertionError('forbidden launch')),patch('os.pipe',side_effect=AssertionError('forbidden pipe')):r=c.run(s)
   self.save('result',r);self.no_effect(w,r);self.assertEqual(r['primary_error']['code'],'limit')
 def test_supported_delayed_exec_after_both_eofs_within_three_batches(self):
  w,s,c=self.prepare('pass');select=mod.selectors.DefaultSelector.select;read=os.read;control={'withheld':0,'first':True,'ack_after_both_eofs':False}
  def selection(sel,*a,**k):
   if control['first']:
    import select as readiness
    control['output_ready']={}
    for name in ('stdout','stderr'):
     ready,_,_=readiness.select([c.pipe_read_fds[name]],[],[],max(0,s.start_by-time.monotonic()))
     control['output_ready'][name]=bool(ready)
    control['first']=False
   events=select(sel,*a,**k)
   if any(v[0].data=='exec' for v in events) and any(v.data in ('stdout','stderr') for v in sel.get_map().values()) and control['withheld']<3:
    control['withheld']+=1;return [v for v in events if v[0].data!='exec']
   return events
  def reading(fd,n):
   if fd==getattr(w,'_finite_child_active_fds',{}).get('exec_read'):
    control['ack_after_both_eofs']=all(c.pipe_read_fds.get(v) not in current.get_map() for v in ('stdout','stderr'))
   return read(fd,n)
  original_factory=mod.selectors.DefaultSelector;current=None
  def factory():
   nonlocal current
   current=original_factory();return current
  with patch.object(mod.selectors,'DefaultSelector',factory),patch.object(original_factory,'select',selection),patch('os.read',reading):r=c.run(s)
  self.save('result',r);self.save('scheduler',control);self.assertTrue(r['component_complete']);self.assertTrue(control['ack_after_both_eofs']);self.assertGreater(control['withheld'],0);self.assertLessEqual(control['withheld'],3);self.assertEqual(r['child']['exit_code'],0);self.check(w,r)
 def test_supported_max_path_env_cardinality_and_aggregate_budget(self):
  from ledger import CAP
  while len(self.root.parts)<32:self.root=self.root/'d';self.root.mkdir()
  (self.root/'temp').mkdir()
  w,s,c=self.prepare(out=CAP-32768-256-1,err=1,operation_id='x'*96,max_reads=100000,max_ticks=100000)
  pads=tuple(('PAD_'+str(i),'small') for i in range(28));s=dataclasses.replace(s,env=s.env+pads)
  r=c.run(s);self.save('result',r);self.assertTrue(r['component_complete']);self.assertEqual(r['accounting']['plan_total'],128849018880);self.assertEqual(r['accounting']['charged'],128849018880);self.assertEqual(r['accounting']['reserved_remaining'],0);self.assertEqual(len(r['identity']['env']),32);self.assertLessEqual(r['receipt']['stored_bytes'],r['receipt_bound']);self.assertLessEqual(r['receipt_bound'],32768);self.check(w,r)
 def exec_fault(self,mode):
  w,s,c=self.prepare('pass');sel=mod.selectors.DefaultSelector.select;read=os.read
  def selection(obj,*a,**kw):
   events=sel(obj,*a,**kw)
   if mode=='missing':time.sleep(.001);return [v for v in events if v[0].data!='exec']
   return events
  def reading(fd,n):
   if fd==getattr(w,'_finite_child_active_fds',{}).get('exec_read'):
    if mode=='partial' and not hasattr(reading,'sent'):reading.sent=True;return b'\x07'
    if mode=='broken':raise OSError(errno.EIO,'real status read failure')
   return read(fd,n)
  with patch.object(mod.selectors.DefaultSelector,'select',selection),patch('os.read',reading):r=c.run(s)
  self.save('result',r);self.assertFalse(r['component_complete']);self.assertFalse(r['capture_complete']);self.assertEqual(r['receipt']['attempts'],1);self.check(w,r);return r
 def test_real_missing_exec_status_reaches_original_start_deadline(self):
  r=self.exec_fault('missing');self.assertEqual(r['primary_error']['code'],'start_deadline');self.assertEqual(r['child']['exec_state'],'waiting');self.assertEqual(r['child']['state'],'exited_reaped');self.assertEqual(r['child']['exit_code'],0)
 def test_partial_exec_protocol_is_not_success(self):
  r=self.exec_fault('partial');self.assertEqual(r['primary_error']['code'],'protocol');self.assertEqual(r['child']['start_status_bytes'],1)
 def test_broken_exec_pipe_is_not_success(self):
  r=self.exec_fault('broken');self.assertEqual(r['primary_error']['errno'],errno.EIO);self.assertEqual(r['primary_error']['stage'],'exec_handshake')
 def test_many_cleanup_failures_fit_proven_receipt(self):
  w,s,c=self.prepare();cl=os.close;failed=[]
  def closing(fd):
   if c.active_child is not None and fd in w._finite_child_active_fds.values():failed.append(fd);raise OSError(errno.EIO,'cleanup')
   return cl(fd)
  try:
   with patch('os.close',closing):r=c.run(s)
   self.save('result',r);self.assertEqual(r['receipt']['state'],'written_verified');raw=(w.root/'controls/receipt').read_bytes();self.assertLessEqual(len(raw),32768);self.assertLessEqual(len(raw),r['receipt_bound']);self.assertGreater(len(r['secondary_errors']),5);self.assertEqual(r['accounting']['charged'],49408);self.check(w,r)
   for fd in failed:os.fstat(fd)
  finally:
   for fd in set(failed):cl(fd)
   self.save('external-cleanup',{'fds':failed,'harness_close':'returned'})

if __name__=='__main__':unittest.main(verbosity=2)
