"""NEW pre-isolated fake-child controls for the helper ownership handoff. No product imports."""
import os,pathlib,sys,shutil,subprocess,time,json,hashlib
here=pathlib.Path(__file__).resolve().parent
choices={'component':'component_handoff_tests.py','qa77':'qa77_handoff_tests.py','focused':'repair_tests.py','qa79':'qa79_handoff_tests.py','handoff':'handoff_tests.py'}
if len(sys.argv)!=3 or sys.argv[2] not in choices:raise SystemExit('NEW_ABSOLUTE_ROOT component|qa77|focused|qa79|handoff required')
root=pathlib.Path(sys.argv[1]);label=sys.argv[2]
if not root.is_absolute() or root.exists():raise SystemExit('new absolute root required')
root.mkdir(parents=True,mode=0o700);root=root.resolve();(root/'source').mkdir();(root/'temp').mkdir()
for name in ('contract.py','controller.py','fork_exec.py','receipt_bound.py','window_io.py','qa77_adapted.py','fd_observer.py'):shutil.copyfile(here/name,root/'source'/name)
for name in ('ledger.py','darwin_metadata.py'):shutil.copyfile(here.parent/'m1_bounded'/name,root/'source'/name)
body=here/choices[label];shutil.copyfile(body,root/body.name)
(root/'runner.py').write_text("import sys,runpy\nfrom pathlib import Path\nroot=Path(sys.argv[1])\nsys.path[:0]=[str(root/'source'),str(root)]\nrunpy.run_path(str(root/"+repr(body.name)+"),run_name='__main__')\n")
(root/'profile.sb').write_text('''(version 1)
(allow default)
(deny network*)
(deny file-write*)
(allow file-write* (subpath "'''+str(root)+'''"))
(deny file-read* (subpath "/Users/tf00185088/Desktop/tim-project/ai-drawing") (subpath "/Volumes/AI-Drawing-16T") (subpath "/Users/tf00185088/Desktop/tim-project/.ai-drawing-prepared-environments") (subpath "/Users/tf00185088/Desktop/tim-project/.ai-drawing-maintenance-backups"))
''')
cmd=['/usr/bin/sandbox-exec','-f',str(root/'profile.sb'),'/usr/bin/python3','-I','-S','-B',str(root/'runner.py'),str(root)];env={'PATH':'/usr/bin:/bin','LC_ALL':'C','TZ':'UTC','TMPDIR':str(root/'temp')};start=time.monotonic_ns()
with (root/'raw.stdout').open('xb') as out,(root/'raw.stderr').open('xb') as err:r=subprocess.run(cmd,cwd=root,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err,close_fds=True,timeout=40)
rec={'argv':cmd,'cwd':str(root),'submitted_env':env,'returncode':r.returncode,'elapsed_ns':time.monotonic_ns()-start,'logs':{}}
for n in ('raw.stdout','raw.stderr'):
 f=root/n;assert f.stat().st_size<=262144;b=f.read_bytes();rec['logs'][n]={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
(root/'command.json').write_text(json.dumps(rec,indent=2));print(label,'returncode',r.returncode);print('\n'.join((root/'raw.stderr').read_text().splitlines()[-8:]));print((root/'raw.stdout').read_text()[:500])
