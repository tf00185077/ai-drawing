"""AID79 independent positive criteria; source is never repaired by these tests."""
import qa77_adapted as iq
import unittest,os,errno,dataclasses,json,time,hashlib,copy,select,sys
from unittest.mock import patch
from controller import Controller
from contract import CancelHandle
from ledger import CAP,Stop
import controller as mod
import receipt_bound as rb

class Independent79(unittest.TestCase):
 setUp=iq.IndependentQA.setUp
 tearDown=iq.IndependentQA.tearDown
 prepare=iq.IndependentQA.prepare
 save=iq.IndependentQA.save
 check=iq.IndependentQA.check
 def no_effect(self,w,r):
  self.assertEqual(r['child']['state'],'not_started');self.assertEqual(w.snapshot()['charged'],0);self.assertEqual(list((w.root/'controls').iterdir()),[])
 def test_01_primary_systemexit_survives_two_admission_cleanup_interrupts(self):
  w,s,c=self.prepare();op=os.open;cl=os.close;rd=os.read;fds=[];failed=[];primary=SystemExit(71);secondary=KeyboardInterrupt('cleanup');caught=None
  def opening(p,f,*a,**kw):
   fd=op(p,f,*a,**kw);fds.append(fd);return fd
  def reading(fd,n):
   if fd==w._finite_child_active_fds.get('admission_source'):raise primary
   return rd(fd,n)
  def closing(fd):
   if fd in fds and len(failed)<2:failed.append(fd);raise secondary if len(failed)==1 else OSError(errno.EIO,'secondary')
   return cl(fd)
  try:
   with patch('os.open',opening),patch('os.read',reading),patch('os.close',closing):
    try:c.run(s)
    except BaseException as e:caught=e
   r=c.last_result;self.save('result',r);self.assertIs(caught,primary);self.assertIs(c.original_error,primary);self.assertTrue(w.stopped);self.assertTrue(c.spent);self.no_effect(w,r)
   self.assertEqual([v['class'] for v in r['secondary_errors']],['KeyboardInterrupt','OSError']);self.assertEqual(len(failed),2)
   for fd in failed:
    st=os.fstat(fd);rec=next(x for x in r['owned_fds'].values() if x['fd']==fd);self.assertEqual(rec['state'],'unknown');self.assertEqual(rec['identity'],[str(st.st_dev),str(st.st_ino)])
   self.no_effect(w,Controller(w).run(s))
  finally:
   for fd in failed:cl(fd)
   self.save('external-cleanup',{'fds':failed,'close_returned':True})
 def test_02_pure_invalid_plan_owned_cancel_closed_then_valid_callable(self):
  w,s,c=self.prepare("import os\nos.write(1,b'positive');os.write(2,b'negative')");rd,wr=os.pipe();os.set_blocking(rd,False)
  try:
   r=c.run(dataclasses.replace(s,max_ticks=False),CancelHandle(rd,'owned'));self.save('refusal',r);self.no_effect(w,r);self.assertFalse(c.spent);self.assertFalse(w.stopped);self.assertEqual(r['cancel_handle']['close_attempts'],1)
   with self.assertRaises(OSError) as x:os.fstat(rd)
   self.assertEqual(x.exception.errno,errno.EBADF)
   r=c.run(s);self.save('result',r);self.assertTrue(r['component_complete']);self.assertEqual((w.root/'controls/stdout').read_bytes(),b'positive');self.assertEqual((w.root/'controls/stderr').read_bytes(),b'negative');self.check(w,r)
   charge=w.snapshot()['charged'];r2=c.run(s);self.save('reuse',r2);self.assertEqual(r2['primary_error']['code'],'spent');self.assertEqual(w.snapshot()['charged'],charge)
  finally:os.close(wr)
 def test_03_owned_cancel_alias_rejected_without_closing_borrowed_anchor(self):
  w,s,c=self.prepare();fd=w.fds['controls'];before=os.fstat(fd);r=c.run(s,CancelHandle(fd,'owned'));self.save('result',r);self.no_effect(w,r);after=os.fstat(fd);self.assertEqual((before.st_dev,before.st_ino),(after.st_dev,after.st_ino));self.assertEqual(r['cancel_handle']['state'],'alias_not_transferred')
 def test_04_exec_ack_only_after_actual_exit_and_eofs(self):
  w,s,c=self.prepare('pass');factory=mod.selectors.DefaultSelector;real=factory.select;observed={'held':0,'exit_seen':False,'eofs_seen':False};selector=[]
  def make():obj=factory();selector.append(obj);return obj
  def schedule(obj,*a,**kw):
   # Wait for actual child closure on both owned output pipes, bounded by the
   # unchanged start deadline. This controls notification order, not syscalls.
   if observed['held']==0:
    for fd in c.pipe_read_fds.values():self.assertTrue(select.select([fd],[],[],max(0,s.start_by-time.monotonic()))[0])
   events=real(obj,*a,**kw);ack=[v for v in events if v[0].data=='exec'];others=[v for v in events if v[0].data!='exec']
   if ack and any(k.data in ('stdout','stderr') for k in obj.get_map().values()) and observed['held']<3:observed['held']+=1;return others
   if ack:
    observed['exit_seen']=c.active_child.poll() is not None;observed['eofs_seen']=not any(k.data in ('stdout','stderr') for k in obj.get_map().values())
   return events
  with patch.object(mod.selectors,'DefaultSelector',make),patch.object(factory,'select',schedule):r=c.run(s)
  self.save('result',r);self.save('scheduler',observed);self.assertTrue(r['component_complete']);self.assertTrue(observed['exit_seen']);self.assertTrue(observed['eofs_seen']);self.assertLessEqual(observed['held'],3);self.check(w,r)
 def test_05_full_cardinality_error_metadata_accounting_envelope(self):
  # Exercise maximum supported path/env cardinality with a real child, then
  # induce more than32 actual cleanup failures. Verify stored/returned values
  # against the captured before-effects representation with an independent encoder.
  while len(self.root.parts)<32:self.root=self.root/'q';self.root.mkdir()
  (self.root/'temp').mkdir();w,s,c=self.prepare(out=CAP-32768-256-1,err=1,operation_id='X'*96,max_reads=100000,max_ticks=100000)
  keys=tuple(('K'+str(i)+'X'*(63-len(str(i))),'\\"\x01😀') for i in range(28));s=dataclasses.replace(s,env=s.env+keys)
  cl=os.close;enc=rb.bounded_json;bound=[];failed=[];armed=[False];ErrorType=type('Z'*100,(OSError,),{})
  def encoding(value,limit):
   raw=enc(value,limit)
   if limit==32768:bound.append(copy.deepcopy(value))
   return raw
  def closing(fd):
   if any(name.startswith('pre_exec_cwd_') and value==fd for name,value in w._finite_child_active_fds.items()):armed[0]=True
   if armed[0] and fd in w._finite_child_active_fds.values():failed.append(fd);raise ErrorType(65535,'unpersisted message')
   return cl(fd)
  try:
   with patch.object(rb,'bounded_json',encoding),patch('os.close',closing):r=c.run(s)
   raw=(w.root/'controls/receipt').read_bytes();stored=json.loads(raw);env=bound[0];self.save('result',r);self.save('admission-envelope',env)
   self.assertTrue(r['admitted']);self.assertEqual(len(r['owned_fds']),110);self.assertEqual(len(env['owned_fds']),110);self.assertEqual(len(r['secondary_errors']),32);self.assertGreater(len(failed),32);self.assertEqual(len(r['identity']['env']),32);self.assertEqual(r['accounting']['charged'],CAP);self.assertEqual(r['accounting']['reserved_remaining'],0)
   self.assertEqual(r['receipt']['state'],'written_verified');self.assertEqual(len(json.dumps(env,ensure_ascii=True,sort_keys=True,separators=(',',':')).encode()),r['receipt_bound']);self.assertLessEqual(len(raw),r['receipt_bound']);self.assertLessEqual(r['receipt_bound'],32768)
   self.assertEqual(len(r['primary_error']['class']),64);self.assertEqual(r['primary_error']['errno'],65535);self.assertEqual(len(env['secondary_errors']),32)
   # The envelope includes optional AFTER-write fields as well as the persisted
   # attempting receipt. Every actual branch's keys and scalar byte width fit.
   def cover(actual,upper,path=''):
    if actual is None:return
    if type(actual) is dict:
     self.assertTrue(set(actual)<=set(upper),path)
     for k,v in actual.items():cover(v,upper[k],path+'/'+k)
    elif type(actual) in (tuple,list):
     self.assertLessEqual(len(actual),len(upper),path)
     for i,v in enumerate(actual):cover(v,upper[i],path+'/'+str(i))
    else:self.assertLessEqual(len(json.dumps(actual,ensure_ascii=True)),len(json.dumps(upper,ensure_ascii=True)),path)
   cover(r,env);cover(stored,env);self.save('coverage',{'owned':110,'secondary':32,'env':32,'failed_closes':len(failed),'bound':r['receipt_bound'],'stored':len(raw),'final':len(json.dumps(r,ensure_ascii=True,sort_keys=True,separators=(',',':')).encode())})
   for fd in set(failed):os.fstat(fd)
  finally:
   for fd in set(failed):cl(fd)
   self.save('external-cleanup',{'fds':sorted(set(failed)),'close_returned':True})
 def test_06_escape_expansion_refused_before_output_pipe_spawn(self):
  w,s,c=self.prepare();s=dataclasses.replace(s,env=s.env+(('PAD','\x01'*4096),));calls=[]
  def forbidden(*a,**kw):calls.append('effect');raise AssertionError('must not be called')
  with patch.object(c._io,'new_file',forbidden),patch('os.pipe',forbidden),patch.object(mod,'spawn',forbidden):r=c.run(s)
  self.save('result',r);self.no_effect(w,r);self.assertEqual(calls,[]);self.assertEqual(r['primary_error']['code'],'limit')
 def test_07_genuine_receipt_partial_failure_keeps_bound_charge_and_hash(self):
  w,s,c=self.prepare();write=os.write;count=[]
  def writing(fd,raw):
   if fd==getattr(w,'_finite_child_active_fds',{}).get('receipt'):
    count.append(len(raw));write(fd,raw[:17]);raise OSError(errno.ENOSPC,'partial receipt')
   return write(fd,raw)
  with patch('os.write',writing):r=c.run(s)
  self.save('result',r);b=(w.root/'controls/receipt').read_bytes();self.assertEqual(len(count),1);self.assertEqual(len(b),17);self.assertEqual(r['receipt']['stored_bytes'],17);self.assertEqual(r['receipt']['stored_sha256'],hashlib.sha256(b).hexdigest());self.assertEqual(r['accounting']['charged'],49408);self.assertEqual(r['receipt']['attempts'],1);self.assertLessEqual(len(r['receipt']['fallback']),256);self.check(w,r)
 def test_08_wrong_window_typed_refusal_retains_exact_original_and_cancel_interrupt(self):
  w,s,c=self.prepare();bad=Controller(None);rd,wr=os.pipe();os.set_blocking(rd,False);cl=os.close;secondary=KeyboardInterrupt('cancel');caught=None
  def closing(fd):
   if fd==rd:raise secondary
   return cl(fd)
  try:
   with patch('os.close',closing):
    try:bad.run(s,CancelHandle(rd,'owned'))
    except BaseException as e:caught=e
   r=bad.last_result;self.save('result',r);self.assertIs(caught,secondary);self.assertIs(type(bad.original_error),Stop);self.assertEqual(str(bad.original_error),'plan');self.assertEqual(r['primary_error']['code'],'plan');self.assertEqual(r['secondary_errors'][0]['class'],'KeyboardInterrupt');self.assertIsNone(r['accounting']);os.fstat(rd);self.no_effect(w,r)
  finally:cl(rd);cl(wr);self.save('external-cleanup',{'fd':rd,'close_returned':True})
 def test_09_window_traversal_cleanup_owns_unknown_generation(self):
  w,s,c=self.prepare();cl=os.close;failed=[];attempts=[]
  def closing(fd):
   if fd==getattr(w,'_finite_child_active_fds',{}).get('admission_parent_0'):
    attempts.append(fd)
    if not failed:
     st=os.fstat(fd);failed.append({'fd':fd,'identity':[str(st.st_dev),str(st.st_ino)]});raise OSError(errno.EIO,'Window traversal close')
   return cl(fd)
  try:
   with patch('os.close',closing):r=c.run(s)
   self.save('result',r);self.assertEqual(len(failed),1);self.assertEqual(attempts,[failed[0]['fd']]);st=os.fstat(failed[0]['fd']);live={'fd':failed[0]['fd'],'identity':[str(st.st_dev),str(st.st_ino)]};self.assertEqual(live,failed[0]);self.save('fault-hit-generation',{'live':live,'component_close_attempts':len(attempts),'boundary':'parent traversal root retirement before helper returns'})
   self.assertTrue(w.stopped);self.assertTrue(c.spent);self.assertEqual(r['child']['state'],'not_started');self.assertEqual(w.snapshot()['charged'],0);self.assertEqual(r['primary_error']['errno'],errno.EIO);self.assertTrue(any(v['fd']==live['fd'] and v['identity']==live['identity'] and v['state']=='unknown' and v['close_attempts']==1 for v in r['owned_fds'].values()))
  finally:
   for item in failed:
    cl(item['fd'])
    with self.assertRaises(OSError) as ex:os.fstat(item['fd'])
    self.assertEqual(ex.exception.errno,errno.EBADF)
   self.save('external-cleanup',{'known_new':failed,'harness_only':True})
 def test_10_window_output_acquisition_interrupt_has_owned_outcome(self):
  w,s,c=self.prepare();op=os.open;fs=os.fstat;cl=os.close;opened=[];attempts=[];hits=[];primary=KeyboardInterrupt('output fstat');caught=None
  def opening(path,flags,*a,**kw):
   fd=op(path,flags,*a,**kw)
   if flags & os.O_CREAT:
    st=fs(fd);opened.append({'fd':fd,'identity':[str(st.st_dev),str(st.st_ino)]})
   return fd
  def fstat(fd):
   if any(v['fd']==fd for v in opened):hits.append(fd);raise primary
   return fs(fd)
  def closing(fd):
   if any(v['fd']==fd for v in opened):attempts.append(fd)
   return cl(fd)
  try:
   with patch('os.open',opening),patch('os.fstat',fstat),patch('os.close',closing):
    try:c.run(s)
    except BaseException as e:caught=e
   r=c.last_result;self.save('result',r);self.assertEqual(len(opened),1);self.assertGreaterEqual(len(hits),1);self.assertEqual(len(hits),3);self.assertIs(caught,primary);self.assertIs(c.original_error,primary);self.assertTrue(w.stopped);self.assertTrue(c.spent);self.assertEqual(r['accounting']['charged'],8192);self.assertEqual(r['accounting']['reserved_remaining'],41216);self.assertEqual(r['child']['state'],'not_started');self.assertEqual(r['primary_error']['stage'],'open_stdout');self.assertEqual((w.root/'controls/stdout').read_bytes(),b'');rec=r['owned_fds']['stdout'];self.assertEqual(rec['fd'],opened[0]['fd']);self.assertEqual(rec['close_attempts'],1);self.assertEqual(attempts,[opened[0]['fd']])
   try:st=fs(opened[0]['fd'])
   except OSError as ex:self.assertEqual(ex.errno,errno.EBADF);self.assertEqual(rec['state'],'closed');outcome={'actual_errno':ex.errno}
   else:
    self.assertEqual(rec['state'],'unknown');self.assertEqual(opened[0]['identity'],[str(st.st_dev),str(st.st_ino)]);self.assertTrue(rec['identity'] is None or rec['identity']==opened[0]['identity']);outcome={'unknown_live_generation':opened[0]}
   self.save('fault-hit-generation',{'acquired':opened[0],'fstat_fault_hits':len(hits),'component_close_attempts':len(attempts),'outcome':outcome})
  finally:
   for item in opened:
    try:st=fs(item['fd'])
    except OSError as ex:self.assertEqual(ex.errno,errno.EBADF)
    else:
     self.assertEqual(item['identity'],[str(st.st_dev),str(st.st_ino)]);cl(item['fd']);self.save('external-cleanup',{'known_new':item,'harness_only':True})
if __name__=='__main__':unittest.main(verbosity=2)
