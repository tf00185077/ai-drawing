"""Pre-effect representation proof for the finite child's fixed 32768 slot.

No slack allocation: encode an explicit field/cardinality upper envelope with
M1's real encoder. The identity is exact (including escaped full env). Every
optional returned field is included, even fields added AFTER receipt persistence.
The supported OS profile uses signed32 FD/PID, uint64 native inode/dev and
signed64 monotonic timestamps; native identities are decimal strings.
"""
import copy
from pathlib import Path
from ledger import CAP, bounded_json, Stop


def bound_receipt(result,identity,window,spec,codes):
    # Refuse unsupported traversal cardinality before any traversal at pre-exec.
    cwd=Path(spec.cwd);parent=Path(window.parent)
    if any(len(p.parts)>32 or len(str(p).encode('utf-8'))>1024 for p in (cwd,parent)):raise Stop('unsupported')
    names=[prefix+'_'+str(i) for prefix,path in (('admission_cwd',cwd),('admission_parent',parent),('pre_exec_cwd',cwd)) for i in range(len(path.parts))]
    names.remove('pre_exec_cwd_'+str(len(cwd.parts)-1))
    names+=['admission_source','stdout','stderr','error','receipt','stdin_read','stdin_write','stdout_read','stdout_write','stderr_read','stderr_write','exec_read','exec_write','cwd_pin','selector']
    maxint=2**63-1
    native=['9'*20,'9'*20]  # uint64 decimal representation: at most20 digits.
    fd={'fd':2**31-1,'state':'not_acquired','close_attempts':1,'identity':native}
    err={'class':'X'*64,'code':max(codes,key=len),'errno':65535,'stage':'x'*64}
    # Error-slot representation itself must also fit its immutable256 reservation.
    bounded_json(err,256)
    value=copy.deepcopy(result)
    value.update(identity=identity,primary_error=err,secondary_errors=[err]*32,
                 owned_fds={n:fd for n in names},receipt_bound=32768,
                 selector_close='not_created',component_complete=False)
    value['child']={'state':'start_outcome_unknown','pid':2**31-1,'exit_code':-2147483648,
                    'exit_observed_at':maxint,'normal_stop_attempts':1,
                    'exec_state':'not_attempted','start_status_bytes':6}
    # State strings chosen by serialized length; null is shorter than these.
    for stream in value['streams'].values():
        stream.update(wire_bytes=CAP+1,file_bytes=CAP,sha256='f'*64,
                      readback_verified=False,first_byte_at=maxint,eof_at=maxint,
                      file_identity=native)
    stored={'stored_bytes':32768,'stored_sha256':'f'*64,'file_identity':native}
    value['error_slot']=stored
    value['receipt']={'attempts':1,'state':'written_verified','fallback':'x'*256,
                      'bytes':32768,'sha256':'f'*64,**stored}
    value['cancel_handle']={'state':'alias_not_transferred','close_attempts':1}
    accounting=window.snapshot()
    accounting.update(plan_total=CAP,charged=CAP,reserved_remaining=CAP,stopped=False)
    accounting['slots']={n:{'charged':CAP,'reserved':CAP} for n in window.plan}
    value['accounting']=accounting
    # JSON punctuation, keys, escapes, longest enums and all optional fields are
    # charged by the actual encoder, rather than a guessed overhead allowance.
    return len(bounded_json(value,32768))
