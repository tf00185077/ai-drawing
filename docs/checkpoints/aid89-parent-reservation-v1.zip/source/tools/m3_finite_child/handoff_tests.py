"""Actual resource observations for QA79-01; run only inside preinstalled fixture OS boundary."""
import qa77_adapted as iq
import unittest,os,errno,hashlib
from unittest.mock import patch
from controller import Controller
import controller as mod
import ledger

class HandoffTests(unittest.TestCase):
 setUp=iq.IndependentQA.setUp
 tearDown=iq.IndependentQA.tearDown
 prepare=iq.IndependentQA.prepare
 save=iq.IndependentQA.save
 check=iq.IndependentQA.check
 def stopped(self,w,s,c):
  charge=w.snapshot()['charged'];names=sorted(p.name for p in (w.root/'controls').iterdir());effects=[]
  def forbidden(*a,**kw):effects.append(True);raise AssertionError('forbidden new effect')
  with patch('os.pipe',forbidden),patch.object(mod,'spawn',forbidden):
   results=[o.run(s) for o in (c,Controller(w))]
   with self.assertRaises(ledger.Stop):w.stream('controls/stderr',[b'no'])
  self.assertEqual(effects,[]);self.assertEqual(w.snapshot()['charged'],charge);self.assertEqual(sorted(p.name for p in (w.root/'controls').iterdir()),names);self.save('reentry',results)
 def test_no_opaque_acquiring_window_helpers_in_supported_capture(self):
  w,s,c=self.prepare("import os\nos.write(1,b'normal');os.write(2,b'error')");hits=[]
  def forbidden(*a,**kw):hits.append('opaque');raise AssertionError('opaque acquiring helper')
  with patch.object(w,'new_file',forbidden),patch.object(w,'write',forbidden),patch.object(w,'parent_for',forbidden),patch.object(w,'roots',forbidden):r=c.run(s)
  self.save('result',r);self.assertTrue(r['component_complete']);self.assertEqual(hits,[]);self.assertEqual((w.root/'controls/stdout').read_bytes(),b'normal');self.assertEqual((w.root/'controls/stderr').read_bytes(),b'error');self.check(w,r)
 def output_case(self,unknown_return=False,close_error=False):
  w,s,c=self.prepare();op=os.open;fs=os.fstat;cl=os.close;opened=[];attempts=[];primary=KeyboardInterrupt('exact acquisition interruption');secondary=OSError(errno.EIO,'secondary close');caught=None;hits=[]
  def opening(p,f,*a,**kw):
   fd=op(p,f,*a,**kw)
   if f & os.O_CREAT:
    st=fs(fd);opened.append({'fd':fd,'identity':[str(st.st_dev),str(st.st_ino)]})
    if unknown_return:hits.append('open_return_lost');raise primary
   return fd
  def fstat(fd):
   if opened and fd==opened[0]['fd'] and not hits:hits.append('initial_fstat');raise primary
   return fs(fd)
  def closing(fd):
   if opened and fd==opened[0]['fd']:
    attempts.append(fd)
    if close_error:raise secondary
   return cl(fd)
  try:
   with patch('os.open',opening),patch('os.fstat',fstat),patch('os.close',closing):
    try:c.run(s)
    except BaseException as e:caught=e
   r=c.last_result;self.save('result',r);self.assertIs(caught,primary);self.assertIs(c.original_error,primary);self.assertEqual(len(opened),1);self.assertEqual(len(hits),1);self.assertEqual(r['primary_error']['stage'],'open_stdout');self.assertEqual(r['accounting']['charged'],8192);self.assertEqual(r['accounting']['reserved_remaining'],41216);self.assertEqual((w.root/'controls/stdout').read_bytes(),b'');self.assertTrue(w.stopped);self.assertTrue(c.spent);self.assertEqual(r['child']['state'],'not_started');self.assertEqual(r['receipt']['attempts'],1)
   self.assertIn('stdout',r['owned_fds'],'acquisition must be represented before initial fstat');rec=r['owned_fds']['stdout'];obs={'acquisition':opened[0],'fault_hits':hits,'component_close_attempts':len(attempts)}
   if unknown_return:
    self.assertIsNone(rec['fd']);self.assertIsNone(rec['identity']);self.assertEqual(rec['state'],'unknown');self.assertEqual(attempts,[]);st=fs(opened[0]['fd']);self.assertEqual(opened[0]['identity'],[str(st.st_dev),str(st.st_ino)])
   elif close_error:
    self.assertEqual(rec['fd'],opened[0]['fd']);self.assertEqual(rec['identity'],opened[0]['identity']);self.assertEqual(rec['state'],'unknown');self.assertEqual(len(attempts),1);self.assertTrue(any(v['errno']==errno.EIO for v in r['secondary_errors']));st=fs(opened[0]['fd']);self.assertEqual(opened[0]['identity'],[str(st.st_dev),str(st.st_ino)])
   else:
    self.assertEqual(rec['state'],'closed');self.assertEqual(rec['close_attempts'],1);self.assertEqual(len(attempts),1)
    with self.assertRaises(OSError) as ex:fs(opened[0]['fd'])
    self.assertEqual(ex.exception.errno,errno.EBADF);obs['actual_errno_after_close']=ex.exception.errno
   self.save('fault-observation',obs);self.stopped(w,s,c)
  finally:
   if opened:
    try:live=fs(opened[0]['fd'])
    except OSError as ex:
     self.assertEqual(ex.errno,errno.EBADF)
    else:
     self.assertEqual(opened[0]['identity'],[str(live.st_dev),str(live.st_ino)])
     cl(opened[0]['fd'])
     with self.assertRaises(OSError) as ex:fs(opened[0]['fd'])
     self.assertEqual(ex.exception.errno,errno.EBADF);self.save('external-cleanup',{'known_new_fd':opened[0]['fd'],'harness_only':True,'actual_errno':ex.exception.errno})
 def test_known_output_initial_fstat_interruption_closes_before_return(self):self.output_case()
 def test_known_output_primary_interruption_survives_secondary_close_eio(self):self.output_case(close_error=True)
 def test_unknown_output_open_return_stays_unknown_without_scan(self):self.output_case(unknown_return=True)
 def test_parent_traversal_close_eio_records_current_generation_once(self):
  w,s,c=self.prepare();cl=os.close;fs=os.fstat;failed=[];attempts=[]
  def closing(fd):
   if fd==getattr(w,'_finite_child_active_fds',{}).get('admission_parent_0'):
    attempts.append(fd)
    if not failed:
     st=fs(fd);failed.append({'fd':fd,'identity':[str(st.st_dev),str(st.st_ino)]});raise OSError(errno.EIO,'parent traversal close')
   return cl(fd)
  try:
   with patch('os.close',closing):r=c.run(s)
   self.save('result',r);self.assertEqual(len(failed),1);self.assertEqual(attempts,[failed[0]['fd']]);rec=r['owned_fds']['admission_parent_0'];self.assertEqual(rec['identity'],failed[0]['identity']);self.assertEqual(rec['state'],'unknown');self.assertEqual(rec['close_attempts'],1);self.assertEqual(r['accounting']['charged'],0);self.assertTrue(w.stopped);self.assertTrue(c.spent);self.assertEqual(r['child']['state'],'not_started');st=fs(failed[0]['fd']);self.assertEqual(rec['identity'],[str(st.st_dev),str(st.st_ino)]);self.save('fault-observation',{'known_new':failed[0],'close_attempts':len(attempts)});self.stopped(w,s,c)
  finally:
   for item in failed:cl(item['fd'])
   self.save('external-cleanup',{'known_new':failed,'harness_only':True})
 def test_readback_and_terminal_helpers_do_not_acquire_directories(self):
  w,s,c=self.prepare();op=os.open;hits=[]
  def opening(p,f,*a,**kw):
   if c.active_child is not None and f & os.O_DIRECTORY:hits.append(str(p));raise AssertionError('late hidden directory open')
   return op(p,f,*a,**kw)
  with patch('os.open',opening):r=c.run(s)
  self.save('result',r);self.assertTrue(r['component_complete']);self.assertEqual(hits,[]);self.check(w,r)
 def test_parent_pin_late_close_failure_is_unknown_after_receipt_and_stops_reentry(self):
  w,s,c=self.prepare();cl=os.close;failed=[]
  def closing(fd):
   if c.active_child is not None and fd==getattr(w,'_finite_child_active_fds',{}).get('admission_parent_1'):
    st=os.fstat(fd);failed.append({'fd':fd,'identity':[str(st.st_dev),str(st.st_ino)]});raise OSError(errno.EIO,'late parent close')
   return cl(fd)
  try:
   with patch('os.close',closing):r=c.run(s)
   self.save('result',r);self.assertEqual(len(failed),1);rec=r['owned_fds']['admission_parent_1'];self.assertEqual(rec['state'],'unknown');self.assertEqual(rec['identity'],failed[0]['identity']);self.assertEqual(rec['close_attempts'],1);self.assertTrue(r['capture_complete']);self.assertFalse(r['component_complete']);self.assertEqual(r['receipt']['state'],'written_verified');self.assertEqual(r['receipt']['attempts'],1);self.assertEqual(r['primary_error']['stage'],'close_admission_parent_1');self.assertEqual(r['accounting']['charged'],49408);self.stopped(w,s,c)
  finally:
   for item in failed:cl(item['fd'])
   self.save('external-cleanup',{'known_new':failed,'harness_only':True})
 def test_selector_acquisition_intent_survives_unreturned_constructor(self):
  w,s,c=self.prepare();factory=mod.selectors.DefaultSelector;known=[];primary=KeyboardInterrupt('selector return hidden');caught=None
  def acquiring():
   obj=factory();known.append(obj);raise primary
  try:
   with patch.object(mod.selectors,'DefaultSelector',acquiring):
    try:c.run(s)
    except BaseException as e:caught=e
   r=c.last_result;self.save('result',r);self.assertIs(caught,primary);self.assertIn('selector',r['owned_fds']);rec=r['owned_fds']['selector'];self.assertEqual(rec,{'fd':None,'state':'unknown','close_attempts':0,'identity':None});self.assertEqual(r['selector_close'],'unknown');self.assertEqual(r['child']['state'],'not_started');self.assertEqual(r['accounting']['charged'],49408);self.stopped(w,s,c)
  finally:
   for obj in known:obj.close()
   self.save('external-cleanup',{'known_new_selector_count':len(known),'harness_only':True})
 def test_pipe_acquisition_intents_survive_unreturned_pair(self):
  w,s,c=self.prepare();pipe=os.pipe;known=[];primary=KeyboardInterrupt('pipe return hidden');caught=None
  def acquiring():
   pair=pipe();known.extend(pair);raise primary
  try:
   with patch('os.pipe',acquiring):
    try:c.run(s)
    except BaseException as e:caught=e
   r=c.last_result;self.save('result',r);self.assertIs(caught,primary)
   for name in ('stdin_read','stdin_write'):
    self.assertIn(name,r['owned_fds']);self.assertEqual(r['owned_fds'][name],{'fd':None,'state':'unknown','close_attempts':0,'identity':None})
   self.assertEqual(r['child']['state'],'not_started');self.assertEqual(r['accounting']['charged'],49408);self.stopped(w,s,c)
  finally:
   for fd in known:os.close(fd)
   self.save('external-cleanup',{'known_new_fds':known,'harness_only':True})
 def test_returned_pipe_pair_is_owned_before_first_identity_and_secondary_close(self):
  w,s,c=self.prepare();pipe=os.pipe;fs=os.fstat;cl=os.close;pair=[];attempts=[];hits=[];primary=KeyboardInterrupt('pipe identity');caught=None
  def acquiring():
   result=pipe()
   if not pair:pair.extend(result)
   return result
  def fstat(fd):
   if pair and fd==pair[0] and not hits:hits.append(fd);raise primary
   return fs(fd)
  def closing(fd):
   if fd in pair:
    attempts.append(fd)
    if fd==pair[0]:raise OSError(errno.EIO,'pipe secondary close')
   return cl(fd)
  try:
   with patch('os.pipe',acquiring),patch('os.fstat',fstat),patch('os.close',closing):
    try:c.run(s)
    except BaseException as e:caught=e
   r=c.last_result;self.save('result',r);self.assertIs(caught,primary);self.assertIs(c.original_error,primary);self.assertEqual(len(hits),1);self.assertEqual(sorted(attempts),sorted(pair));self.assertEqual(r['child']['state'],'not_started');self.assertEqual(r['accounting']['charged'],49408)
   for name,fd in zip(('stdin_read','stdin_write'),pair):self.assertEqual(r['owned_fds'][name]['fd'],fd);self.assertEqual(r['owned_fds'][name]['close_attempts'],1)
   st=fs(pair[0]);self.assertEqual(r['owned_fds']['stdin_read']['state'],'unknown');self.assertEqual(r['owned_fds']['stdin_read']['identity'],[str(st.st_dev),str(st.st_ino)])
   with self.assertRaises(OSError) as ex:fs(pair[1])
   self.assertEqual(ex.exception.errno,errno.EBADF);self.assertEqual(r['owned_fds']['stdin_write']['state'],'closed');self.assertTrue(any(v['errno']==errno.EIO for v in r['secondary_errors']));self.save('fault-observation',{'pair':pair,'identity_fault_hits':hits,'close_attempts':attempts,'sibling_errno':ex.exception.errno});self.stopped(w,s,c)
  finally:
   if pair:cl(pair[0]);self.save('external-cleanup',{'known_new_fd':pair[0],'harness_only':True})
 def test_known_selector_identity_interruption_survives_secondary_close(self):
  w,s,c=self.prepare();factory=mod.selectors.DefaultSelector;real_close=factory.close;fs=os.fstat;known=[];attempts=[];hits=[];primary=KeyboardInterrupt('selector identity');caught=None
  def acquiring():
   obj=factory();known.append(obj);return obj
  def fstat(fd):
   if known and fd==known[0].fileno() and not hits:hits.append(fd);raise primary
   return fs(fd)
  def closing(obj):
   if known and obj is known[0]:attempts.append(obj.fileno());raise OSError(errno.EIO,'selector secondary close')
   return real_close(obj)
  try:
   with patch.object(mod.selectors,'DefaultSelector',acquiring),patch('os.fstat',fstat),patch.object(factory,'close',closing):
    try:c.run(s)
    except BaseException as e:caught=e
   r=c.last_result;self.save('result',r);self.assertIs(caught,primary);self.assertIs(c.original_error,primary);self.assertEqual(len(hits),1);self.assertEqual(attempts,hits);rec=r['owned_fds']['selector'];st=fs(known[0].fileno());self.assertEqual(rec['fd'],known[0].fileno());self.assertEqual(rec['identity'],[str(st.st_dev),str(st.st_ino)]);self.assertEqual(rec['state'],'unknown');self.assertEqual(rec['close_attempts'],1);self.assertTrue(any(v['errno']==errno.EIO for v in r['secondary_errors']));self.assertEqual(r['child']['state'],'not_started');self.save('fault-observation',{'selector_fd':rec['fd'],'identity':rec['identity'],'fault_hits':hits,'close_attempts':attempts});self.stopped(w,s,c)
  finally:
   for obj in known:real_close(obj)
   self.save('external-cleanup',{'known_new_selector_count':len(known),'harness_only':True})
 def test_controls_anchor_replacement_refuses_without_output_write(self):
  w,s,c=self.prepare("import os\nos.write(1,b'should-not-persist')");original=c._io.write;hits=[]
  def writing(fd,p,raw,position):
   if not hits:
    hits.append(p);(w.root/'controls').rename(w.root/'held-controls');(w.root/'controls').mkdir()
   return original(fd,p,raw,position)
  with patch.object(c._io,'write',writing):r=c.run(s)
  self.save('result',r);self.assertEqual(hits,['controls/stdout']);self.assertEqual(r['primary_error']['code'],'drift');self.assertEqual((w.root/'held-controls/stdout').read_bytes(),b'');self.assertEqual(r['accounting']['charged'],49408);self.assertEqual(r['receipt']['attempts'],1);self.assertLessEqual(len(r['receipt']['fallback']),256);self.assertFalse(r['component_complete']);self.assertTrue(w.stopped);self.check(w,r)
 def test_actual_fd_number_reuse_has_distinct_closed_generations(self):
  w,s,c=self.prepare();r=c.run(s);self.save('result',r);self.assertTrue(r['component_complete']);records=list(r['owned_fds'].values());pairs=[(a,b) for i,a in enumerate(records) for b in records[i+1:] if a['fd']==b['fd'] and a['identity']!=b['identity']];self.assertTrue(pairs,'real allocator must reuse a retired admission number in this isolated fixture');self.save('reused-generations',pairs);self.check(w,r)
if __name__=='__main__':unittest.main(verbosity=2)
