"""Independent QA of frozen AID76; execute only after external OS isolation."""
import dataclasses,errno,hashlib,json,os,pathlib,signal,sys,time,unittest,fcntl
from unittest.mock import patch
from ledger import Window,CAP
from contract import ChildSpec,NormalStop,CancelHandle
import fd_observer
os.close=fd_observer.close
import controller as mod
from controller import Controller
ROOT=pathlib.Path(sys.argv[1]);sys.argv[:]=[sys.argv[0]]

class IndependentQA(unittest.TestCase):
 def setUp(self):
  self.root=ROOT/self._testMethodName;self.root.mkdir();(self.root/'temp').mkdir();self.windows=[]
 def tearDown(self):
  for w in self.windows:w.close()
  self.save('fd-close-observations',fd_observer.observations)
 def prepare(self,source="import os\nos.write(1,b'ok')",out=8192,err=8192,**kw):
  p=self.root/'child.py';p.write_text(source);now=time.monotonic()
  a=dict(operation_id=self._testMethodName,source_id=hashlib.sha256(p.read_bytes()).hexdigest(),argv=('/usr/bin/python3','-I','-S','-B',str(p)),cwd=str(self.root),env=(('PATH','/usr/bin:/bin'),('LC_ALL','C'),('TZ','UTC'),('TMPDIR',str(self.root/'temp'))),source_bytes=p.stat().st_size,start_by=now+.5,run_until=now+1.5,close_by=now+2.2,stdout_limit=out,stderr_limit=err,read_chunk=251,max_reads=5000,max_ticks=10000,normal_stop=NormalStop(int(signal.SIGTERM),1,.3),fd_mode='single-process-eof-stdin',fd_ceiling=1048576)
  a.update(kw);s=ChildSpec(**a);w=Window(self.root,'capture',{'controls/stdout':('file',out),'controls/stderr':('file',err),'controls/error':('file',256),'controls/receipt':('file',32768)});self.windows.append(w);return w,s,Controller(w)
 def save(self,name,value):
  (self.root/(name+'.json')).write_text(json.dumps(value,indent=2,sort_keys=True))
 def check(self,w,r):
  a=r['accounting'];self.assertEqual(a['charged']+a['reserved_remaining'],a['plan_total']);self.assertLessEqual(a['plan_total'],CAP)
  for key in ('protection_verified','source_start_allowed','retry_b_allowed'):self.assertIs(r[key],False)
  for n,rec in r['owned_fds'].items():
   if rec['state']=='closed':
    fd_observer.assert_closed(self,r,rec)
  for n in ('stdout','stderr'):
   p=w.root/'controls'/n
   if r['streams'][n]['readback_verified']:
    raw=p.read_bytes();self.assertEqual(len(raw),r['streams'][n]['file_bytes']);self.assertEqual(hashlib.sha256(raw).hexdigest(),r['streams'][n]['sha256'])
 def test_prewrite_full_shared_charge_before_any_pipe_or_spawn(self):
  w,s,c=self.prepare();actual_pipe=os.pipe;actual_spawn=mod.spawn;seen=[]
  def bound(where):
   a=w.snapshot();seen.append({'stage':where,'snapshot':a,'actual_lengths':{p:(w.root/p).stat().st_size for p in w.plan}})
   self.assertEqual(a['charged'],a['plan_total']);self.assertEqual(a['reserved_remaining'],0)
  def pipe():bound('pipe');return actual_pipe()
  def spawn(*a):bound('spawn');return actual_spawn(*a)
  with patch('os.pipe',pipe),patch.object(mod,'spawn',spawn):r=c.run(s)
  self.save('prewrite',seen);self.save('result',r);self.assertTrue(r['component_complete']);self.check(w,r)
 def test_binary_both_exact_caps_and_undrained_tail(self):
  source="import os\na=bytes(range(256))*17;b=bytes(reversed(range(256)))*19\nfor i in range(0,max(len(a),len(b)),67):\n os.write(1,a[i:i+67]);os.write(2,b[i:i+67])"
  w,s,c=self.prepare(source,out=4352,err=4864,read_chunk=67);r=c.run(s);self.save('result',r)
  self.assertTrue(r['component_complete']);self.assertEqual((w.root/'controls/stdout').read_bytes(),bytes(range(256))*17);self.assertEqual((w.root/'controls/stderr').read_bytes(),bytes(reversed(range(256)))*19);self.check(w,r)
 def test_stderr_cap_plus_one_and_stdout_preservation(self):
  w,s,c=self.prepare("import os\nos.write(1,b'prefix');os.write(2,b'e'*514)",out=100,err=513,read_chunk=1);r=c.run(s);self.save('result',r)
  self.assertEqual(r['primary_error']['code'],'output_cap');self.assertEqual((w.root/'controls/stderr').read_bytes(),b'e'*513);self.assertEqual(r['streams']['stderr']['wire_bytes'],514);self.assertEqual((w.root/'controls/stdout').read_bytes(),b'prefix');self.check(w,r)
 def test_eof_cancel_borrowed_flags_and_owned_rejection(self):
  w,s,c=self.prepare('import time\ntime.sleep(2)');rd,wr=os.pipe();os.set_blocking(rd,False);os.close(wr);flags=fcntl.fcntl(rd,fcntl.F_GETFL)
  try:r=c.run(s,CancelHandle(rd,'borrowed'));self.save('result',r);self.assertEqual(r['primary_error']['code'],'cancelled');self.assertEqual(flags,fcntl.fcntl(rd,fcntl.F_GETFL));self.check(w,r)
  finally:os.close(rd)
 def test_no_launch_large_plan_invalid_inputs(self):
  w,s,c=self.prepare();variants=[dataclasses.replace(s,close_by=float('inf')),dataclasses.replace(s,max_reads=True),dataclasses.replace(s,normal_stop=NormalStop(int(signal.SIGTERM),2,.1)),dataclasses.replace(s,env=(('X','bad\x00value'),)),dataclasses.replace(s,source_bytes=s.source_bytes+1)]
  results=[]
  for v in variants:
   with patch.object(mod,'spawn',side_effect=AssertionError('forbidden')),patch('os.pipe',side_effect=AssertionError('forbidden')):r=Controller(w).run(v)
   results.append(r);self.assertFalse(r['admitted']);self.assertEqual(r['accounting']['charged'],0);self.assertEqual(list((w.root/'controls').iterdir()),[])
  self.save('results',results)
 def test_read_count_and_tick_count_are_separate(self):
  w,s,c=self.prepare("import os\nos.write(1,b'a'*100)",read_chunk=1,max_reads=1);r=c.run(s);self.save('read-result',r);self.assertEqual(r['primary_error']['code'],'read_count');self.check(w,r)
  # Fresh owned cwd/root/source for a separate single-use Window.
  old=self.root;self.root=old/'second';self.root.mkdir();(self.root/'temp').mkdir()
  w,s,c=self.prepare('import time\ntime.sleep(2)',max_ticks=1);r=c.run(s);self.save('tick-result',r);self.assertEqual(r['primary_error']['code'],'tick_count');self.check(w,r);self.root=old
 def test_owned_cancel_close_error_retains_unknown_and_other_fds_close(self):
  w,s,c=self.prepare();rd,wr=os.pipe();os.set_blocking(rd,False);actual=os.close;hits=[]
  def close(fd):
   if fd==rd:hits.append(fd);raise OSError(errno.EIO,'synthetic cancel close')
   return actual(fd)
  try:
   with patch('os.close',close):r=c.run(s,CancelHandle(rd,'owned'))
   self.save('result',r);self.assertEqual(hits,[rd]);self.assertEqual(r['cancel_handle']['state'],'unknown');self.assertEqual(r['primary_error']['stage'],'close_cancel');os.fstat(rd);self.assertFalse(r['component_complete']);self.check(w,r)
  finally:actual(rd);actual(wr);self.save('external-fd-cleanup',{'fd':rd,'component_state':'unknown','harness_close':'returned'})
 def test_error_slot_and_receipt_write_failure_attempted_once(self):
  w,s,c=self.prepare('raise SystemExit(9)');actual=os.write;hits=[]
  def write(fd,raw):
   if len(raw)==256 or (raw.startswith(b'{') and b'"capture_complete"' in raw):hits.append({'fd':fd,'bytes':len(raw)});raise OSError(errno.ENOSPC,'synthetic terminal')
   return actual(fd,raw)
  with patch('os.write',write):r=c.run(s)
  self.save('result',r);self.save('attempts',hits);self.assertEqual(r['primary_error']['code'],'child_exit');self.assertEqual(len(hits),2);self.assertEqual(r['receipt']['attempts'],1);self.assertEqual(r['receipt']['state'],'failed');self.assertLessEqual(len(r['receipt']['fallback']),256);self.check(w,r)
 def test_partial_eio_keeps_actual_prefix_and_original_errno(self):
  w,s,c=self.prepare("import os\nos.write(1,b'abcdefghi')");actual=os.write;original=c._io.write
  def failing(fd,p,raw,pos):
   if p=='controls/stdout':actual(fd,raw[:3]);raise OSError(errno.EIO,'synthetic after partial')
   return original(fd,p,raw,pos)
  with patch.object(c._io,'write',failing):r=c.run(s)
  self.save('result',r);self.assertEqual((w.root/'controls/stdout').read_bytes(),b'abc');self.assertEqual(r['primary_error']['errno'],errno.EIO);self.assertEqual(r['primary_error']['stage'],'capture_stdout');self.check(w,r)
 def test_genuine_keyboard_interrupt_during_receipt_close_preserved(self):
  w,s,c=self.prepare();actual=os.close;interruption=KeyboardInterrupt('synthetic close');failed=[]
  def close(fd):
   if c.active_child is not None and fd in w._finite_child_active_fds.values() and fd==w._finite_child_active_fds.get('receipt') and not failed:failed.append(fd);raise interruption
   return actual(fd)
  try:
   with patch('os.close',close):
    with self.assertRaises(KeyboardInterrupt) as caught:c.run(s)
   r=c.last_result;self.save('result',r);self.assertIs(caught.exception,interruption);self.assertEqual(r['primary_error']['stage'],'close_receipt');self.assertEqual(r['owned_fds']['receipt']['state'],'unknown');self.assertFalse(r['component_complete']);self.check(w,r)
  finally:
   for fd in failed:actual(fd)
   self.save('external-fd-cleanup',{'fds':failed,'harness_close':'returned'})
 def test_exec_ack_ready_after_output_eof_still_completes(self):
  w,s,c=self.prepare('pass');actual=mod.selectors.DefaultSelector.select;withheld=[]
  def deferred(sel,*a,**kw):
   events=actual(sel,*a,**kw);other=[v for v in events if v[0].data!='exec'];ack=[v for v in events if v[0].data=='exec']
   # Readiness order is not a child/pipe failure. Delay exec notification until
   # both output EOFs have been delivered; actual status fd remains readable.
   if ack and any(k.data in ('stdout','stderr') for k in sel.get_map().values()):
    withheld.append({'event_names':[v[0].data for v in events]});return other
   return events
  with patch.object(mod.selectors.DefaultSelector,'select',deferred):r=c.run(s)
  self.save('result',r);self.save('withheld',withheld);self.assertTrue(r['component_complete'],'exit and output EOF must not fail before reading the already ready exec acknowledgement');self.check(w,r)
 def test_admission_source_close_failure_reports_live_owned_descriptor(self):
  w,s,c=self.prepare();actual_open=os.open;actual_close=os.close;sourcefd=[];failed=[]
  def opened(path,flags,*a,**kw):
   fd=actual_open(path,flags,*a,**kw)
   if path=='child.py' and not flags & os.O_CREAT:sourcefd.append(fd)
   return fd
  def closed(fd):
   if sourcefd and fd==sourcefd[-1] and not failed:failed.append(fd);raise OSError(errno.EIO,'synthetic source close')
   return actual_close(fd)
  try:
   with patch('os.open',opened),patch('os.close',closed):r=c.run(s)
   live=os.fstat(failed[0]);self.save('result',r);self.save('live-descriptor',{'fd':failed[0],'dev':live.st_dev,'ino':live.st_ino,'bytes':live.st_size})
   self.assertFalse(r['admitted']);self.assertEqual(r['primary_error']['errno'],errno.EIO)
   self.assertTrue(any(v.get('fd')==failed[0] and v.get('state')=='unknown' for v in r['owned_fds'].values()),'failed admission-owned source fd must be retained as unknown, including its identity')
  finally:
   for fd in failed:actual_close(fd)
   self.save('external-fd-cleanup',{'fds':failed,'harness_close':'returned'})
 def test_receipt_capacity_known_before_launch(self):
  w,s,c=self.prepare();env=s.env+tuple(('QA_PAD_'+str(i),'z'*4096) for i in range(9));s=dataclasses.replace(s,env=env);r=c.run(s);self.save('result',r)
  self.assertTrue(r['component_complete'] or not r['admitted'],'an identity that cannot fit the fixed receipt must refuse before effects, or use a complete bounded representation');self.check(w,r)
 def test_wrong_window_type_refuses_and_preserves_outcome(self):
  w,s,c=self.prepare();rd,wr=os.pipe();os.set_blocking(rd,False);caught=None;bad=Controller(None)
  try:
   try:r=bad.run(s,CancelHandle(rd,'owned'))
   except BaseException as e:caught={'class':type(e).__name__,'message':str(e)};r=bad.last_result
   self.save('observation',{'caught':caught,'result':r})
   with self.assertRaises(OSError):os.fstat(rd)
   self.assertIsNone(caught,'invalid Window should produce typed no-effect admission refusal, not erase the original outcome in finally');self.assertIsNotNone(r)
  finally:os.close(wr)

if __name__=='__main__':unittest.main(verbosity=2)
