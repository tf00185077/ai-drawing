"""Finite supported-child capture on one cooperative ledger or parent-bound view.

Cooperative source API only: no production launcher, admission grant, arbitrary
external command endpoint, filesystem/native fence or hard syscall preemption.
"""
from reservation import ChildReservation
import errno
import hashlib
import os
import re
import selectors
import stat
import struct
from fork_exec import spawn
import threading
import time
from ledger import CODES as LEDGER_CODES, Stop, CHUNK, bounded_json, Window, inode
from receipt_bound import bound_receipt
from window_io import WindowIO
from contract import validate, CancelHandle, STDOUT, STDERR, ERROR, RECEIPT

CODES={'plan','deadline','unsupported','path','source','drift','collision','alias',
       'busy','spent','stopped','cancelled','lifetime','output_cap','read_count',
       'tick_count','short_write','hash','child_exit','start_deadline','close_deadline'}|LEDGER_CODES


def error_record(e,stage):
    number=getattr(e,'errno',None)
    return {'class':re.sub('[^A-Za-z0-9_.]','_',type(e).__name__)[:64],
            'code':str(e) if type(e) is Stop and str(e) in CODES else 'os_error' if isinstance(e,OSError) else 'interruption' if not isinstance(e,Exception) else 'input',
            'errno':number if type(number) is int and 0<=number<=65535 else None,'stage':re.sub('[^A-Za-z0-9_.]','_',stage)[:64]}


class Controller:
    """One use per controller AND Window; run is the sole mutating API.

    Lock ownership covers admission, output, every cleanup and the terminal
    receipt. Nested/concurrent entry refuses before effects. On any refusal a
    valid supplied owned cancel handle gets one close attempt, borrowed stays.
    Terminal writing is a narrow finalizer: preopened/precharged slots only,
    after stop, never a new writer/resume or a release of ledger accounting.
    The caller owns and separately closes Window's directory anchors.
    """
    def __init__(self,window):
        self.w=window
        self._io=WindowIO(window)
        self.lock=threading.Lock()
        self.spent=False
        self.last_result=None
        self.original_error=None
        self.active_child=None
        self.pipe_read_fds={}

    def run(self,spec,cancel=None):
        w=self.w
        r={'admitted':False,'capture_complete':False,'component_complete':False,
           'protection_verified':False,'source_start_allowed':False,'retry_b_allowed':False,
           'primary_error':None,'secondary_errors':[], 'identity':None,
           'child':{'state':'not_started','pid':None,'exit_code':None,'exit_observed_at':None,'normal_stop_attempts':0,'exec_state':'not_attempted','start_status_bytes':0},
           'streams':{k:{'wire_bytes':0,'file_bytes':0,'sha256':None,'readback_verified':False,'first_byte_at':None,'eof_at':None} for k in ('stdout','stderr')},
           'owned_fds':{},'cancel_handle':{'state':'none' if cancel is None else 'unknown'},
           'receipt':{'attempts':0,'state':'not_attempted','fallback':None},
           'receipt_bound':None,'selector_close':'not_created','ledger_anchors':'borrowed_caller_closes_separately','accounting':None}
        fds={};selector=None;child=None;held=False;running=False;poll_lost=False
        stage='admission';raised=None;error=None;lease_entered=False
        has_self=self.lock.acquire(False)

        def note(e,where):
            nonlocal error,raised
            if error is None:
                error=e;r['primary_error']=error_record(e,where)
            elif e is not error and len(r['secondary_errors'])<32:r['secondary_errors'].append(error_record(e,where))
            if not isinstance(e,Exception) and raised is None:raised=e

        def addfd(name,fd):
            fds[name]=fd;w._finite_child_active_fds[name]=fd
            rec={'fd':fd,'state':'open','close_attempts':0,'identity':None}
            r['owned_fds'][name]=rec
            # Registration precedes fstat; an interrupted identity observation still
            # owns the fd and must not skip its bounded closure.
            try:rec['identity']=[str(n) for n in inode(os.fstat(fd))]
            except BaseException as e:note(e,stage if name in ('stdout','stderr','error','receipt') else 'identity_'+name)
            return fd

        def owned_open(name,path,flags,*args,**kwargs):
            if type(w) is ChildReservation:w.check_active()
            # Intent precedes acquisition. A true interruption may hide the
            # returned descriptor: record unknown without guessing/scanning it.
            r['owned_fds'][name]={'fd':None,'state':'unknown','close_attempts':0,'identity':None}
            try:fd=os.open(path,flags,*args,**kwargs)
            except OSError:
                r['owned_fds'][name]['state']='not_acquired';raise
            except BaseException:
                self.spent=True;w.stopped=True;raise
            fd=addfd(name,fd)
            if error is not None:raise error
            return fd

        def owned_pipe(prefix):
            if type(w) is ChildReservation:w.check_active()
            names=(prefix+'_read',prefix+'_write')
            for name in names:r['owned_fds'][name]={'fd':None,'state':'unknown','close_attempts':0,'identity':None}
            try:rd,wr=os.pipe()
            except OSError:
                for name in names:r['owned_fds'][name]['state']='not_acquired'
                raise
            # Register BOTH returned numbers before validating either identity.
            for name,fd in zip(names,(rd,wr)):
                fds[name]=fd;w._finite_child_active_fds[name]=fd
                r['owned_fds'][name].update(fd=fd,state='open')
            for name,fd in zip(names,(rd,wr)):
                try:r['owned_fds'][name]['identity']=[str(n) for n in inode(os.fstat(fd))]
                except BaseException as e:note(e,'identity_'+name)
            if error is not None:raise error
            if type(w) is ChildReservation:w.check_active()
            return rd,wr

        def owned_directory(path,prefix,final=None):
            from pathlib import Path
            path=Path(path)
            if not path.is_absolute() or '..' in path.parts or len(str(path).encode('utf-8'))>1024 or len(path.parts)>32:raise Stop('unsupported')
            fd=owned_open(prefix+'_0','/',os.O_RDONLY|os.O_DIRECTORY)
            if error is not None:raise error
            for index,part in enumerate(path.parts[1:],1):
                name=final if final is not None and index==len(path.parts)-1 else prefix+'_'+str(index)
                fd=owned_open(name,part,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW,dir_fd=fd)
                if error is not None:raise error
                if prefix=='admission_parent' and index==1:
                    closefd(prefix+'_0')
                    if error is not None:raise error
            return fd

        def admission_source(name,parent):
            fd=owned_open('admission_source',name,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK,dir_fd=parent)
            if error is not None:raise error
            return fd

        def closefd(name):
            rec=r['owned_fds'][name]
            if rec['close_attempts']:return
            rec['close_attempts']=1
            if rec['identity'] is None:
                try:rec['identity']=[str(n) for n in inode(os.fstat(fds[name]))]
                except BaseException as e:note(e,'identity_cleanup_'+name)
            try:os.close(fds[name])
            except BaseException as e:
                rec['state']='unknown';note(e,'close_'+name);self.spent=True;w.stopped=True
            else:
                rec['state']='closed';w._finite_child_active_fds.pop(name,None)

        def close_cancel():
            # Never close ledger-owned handles supplied under a forged role.
            # Ownership transfer is rejected for aliases, so ownership stays caller.
            if type(cancel) is CancelHandle and type(cancel.fd) is int and cancel.fd>2 and type(cancel.ownership) is str:
                anchors=(set(w.fds.values())|{w.root_fd,w.parent_fd}|set(getattr(w,'_finite_child_active_fds',{}).values())) if type(w) in (Window,ChildReservation) else set()
                if cancel.fd in anchors:
                    r['cancel_handle']['state']='alias_not_transferred';return
                if cancel.ownership=='borrowed':r['cancel_handle']['state']='borrowed_retained';return
                if cancel.ownership=='owned':
                    r['cancel_handle']['close_attempts']=1
                    try:os.close(cancel.fd)
                    except BaseException as e:
                        note(e,'close_cancel');r['cancel_handle']['state']='unknown';self.spent=True
                        if type(w) in (Window,ChildReservation):w.stopped=True
                    else:r['cancel_handle']['state']='closed'

        def poll():
            nonlocal poll_lost
            try:code=child.poll()
            except BaseException:
                poll_lost=True;r['child']['state']='outcome_unknown';raise
            if code is not None:
                r['child'].update(state='exited_reaped',exit_code=code)
                if r['child']['exit_observed_at'] is None:r['child']['exit_observed_at']=time.monotonic_ns()
            return code

        def file_identity(name):
            fd=fds[name];p='controls/'+name;parent,leaf=self._io.parent_for(p)
            st=os.fstat(fd);named=os.stat(leaf,dir_fd=parent,follow_symlinks=False)
            if inode(st)!=inode(named) or not stat.S_ISREG(st.st_mode) or st.st_nlink!=1 or stat.S_IMODE(st.st_mode)!=0o600:raise Stop('drift')
            return st

        def terminal_write(name,raw):
            # Entire slot charged by the local WindowIO binding BEFORE any child/pipe exists.
            # This fixed-slot terminal-only finalizer is allowed after stop latch.
            if time.monotonic()>spec.close_by:raise Stop('close_deadline')
            st=file_identity(name)
            if st.st_size or len(raw)>w.plan['controls/'+name][1] or w.charged.get('controls/'+name)!=w.plan['controls/'+name][1]:raise Stop('plan')
            if os.write(fds[name],raw)!=len(raw):raise Stop('short_write')
            os.fsync(fds[name]);os.lseek(fds[name],0,0)
            actual=os.read(fds[name],len(raw)+1)
            if actual!=raw or file_identity(name).st_size!=len(raw):raise Stop('hash')
            if time.monotonic()>spec.close_by:raise Stop('close_deadline')
            return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}

        def stored_file(name):
            st=file_identity(name);limit=w.plan['controls/'+name][1]
            if not 0<=st.st_size<=limit:raise Stop('output_cap')
            os.lseek(fds[name],0,0);raw=os.read(fds[name],st.st_size+1)
            if len(raw)!=st.st_size:raise Stop('hash')
            return {'stored_bytes':st.st_size,'stored_sha256':hashlib.sha256(raw).hexdigest(),'file_identity':[str(n) for n in inode(st)]}

        try:
            if not has_self:raise Stop('busy')
            if self.spent:raise Stop('spent')
            if type(w) not in (Window,ChildReservation):raise Stop('plan')
            held=w.lock.acquire(False)
            if not held:raise Stop('busy')
            if w._running:raise Stop('busy')
            if w.stopped:raise Stop('stopped')
            if type(w) is ChildReservation:
                w.begin();lease_entered=True
            w._finite_child_active_fds={}
            self._io.bind(fds,r['owned_fds'],owned_open)
            try:identity=validate(w,spec,cancel,owned_directory,admission_source)
            except BaseException as e:note(e,'admission')
            finally:
                for name in tuple(fds):
                    if error is not None or not name.startswith('admission_parent_'):closefd(name)
            if error is not None:raise error
            # Prove the COMPLETE worst-case receipt before the first output/pipe.
            r['receipt_bound']=bound_receipt(r,identity,w,spec,CODES)
            # Validated before claiming any Window slot, pipe, child or output.
            self.spent=True;w._running=True;running=True;r['admitted']=True;r['identity']=identity
            for name in ('stdout','stderr','error','receipt'):
                stage='open_'+name;self._io.new_file('controls/'+name)
            stage='bind_pipes'
            for name in ('stdin','stdout','stderr'):
                rd,wr=owned_pipe(name)
                if name!='stdin':
                    os.set_blocking(rd,False);self.pipe_read_fds[name]=rd
            # stdin is a prebound pipe with no writer, before exec. No /dev/null.
            closefd('stdin_write')
            if error is not None:raise error
            rd,wr=owned_pipe('exec');os.set_blocking(rd,False)
            r['owned_fds']['selector']={'fd':None,'state':'unknown','close_attempts':0,'identity':None}
            r['selector_close']='unknown'
            if type(w) is ChildReservation:w.check_active()
            selector=selectors.DefaultSelector()
            selector_fd=selector.fileno()
            w._finite_child_active_fds['selector']=selector_fd
            rec=r['owned_fds']['selector'];rec.update(fd=selector_fd,state='open')
            r['selector_close']='open'
            rec['identity']=[str(n) for n in inode(os.fstat(selector_fd))]
            selector.register(rd,selectors.EVENT_READ,'exec')
            for name in ('stdout','stderr'):
                selector.register(fds[name+'_read'],selectors.EVENT_READ,name)
            if cancel is not None:selector.register(cancel.fd,selectors.EVENT_READ,'cancel')
            # Recheck pinned source/cwd immediately before exec; no lookup fallback.
            stage='pre_exec_identity'
            cwd_fd=owned_directory(spec.cwd,'pre_exec_cwd','cwd_pin')
            if inode(os.fstat(cwd_fd))!=identity['cwd_id']:raise Stop('drift')
            st=os.stat(spec.argv[-1],follow_symlinks=False)
            if (st.st_dev,st.st_ino,st.st_size,st.st_mtime_ns,st.st_ctime_ns)!=identity['source_pin']:raise Stop('drift')
            for name in tuple(fds):
                if name.startswith('pre_exec_cwd_'):closefd(name)
            if error is not None:raise error
            if time.monotonic()>=spec.start_by:raise Stop('start_deadline')
            if type(w) is ChildReservation:w.check_active()
            stage='spawn';r['child']['state']='start_outcome_unknown'
            if threading.active_count()!=1:raise Stop('unsupported')
            child=spawn(spec,fds)
            r['child']['exec_state']='waiting'
            self.active_child=child;r['child'].update(pid=child.pid,state='running_unverified')
            for name in ('stdin_read','stdout_write','stderr_write','cwd_pin','exec_write'):closefd(name)
            if error is not None:raise error
            if time.monotonic()>=spec.start_by:raise Stop('start_deadline')
            stage='capture';reads=0;ticks=0;stream_open={'stdout','stderr'};ack=bytearray()
            while True:
                if type(w) is ChildReservation:w.check_active()
                ticks+=1
                if ticks>spec.max_ticks:raise Stop('tick_count')
                now=time.monotonic()
                code=poll()
                if not stream_open and code is not None and r['child']['exec_state']=='exec_observed':break
                if r['child']['exec_state']=='waiting' and now>=spec.start_by:raise Stop('start_deadline')
                if now>=spec.run_until:raise Stop('lifetime')
                events=selector.select(min(.01,spec.run_until-now,max(0,spec.start_by-now) if r['child']['exec_state']=='waiting' else .01))
                for key,_ in events:
                    name=key.data
                    if name=='exec':
                        stage='exec_handshake'
                        raw=os.read(fds['exec_read'],6-len(ack));ack.extend(raw)
                        r['child']['start_status_bytes']=len(ack)
                        if len(ack)>5:raise Stop('protocol')
                        if len(ack)==5:
                            r['child']['exec_state']='exec_error'
                            where,number=struct.unpack('!BI',ack)
                            stage={0:'child_signal_reset',1:'child_chdir',2:'child_stdin',3:'child_stdout',4:'child_stderr',5:'child_status_fd',6:'child_close_fds',7:'exec_handshake'}.get(where,'child_unknown_stage')
                            raise OSError(number,'exec error')
                        if not raw:
                            selector.unregister(key.fileobj)
                            if ack:raise Stop('protocol')
                            r['child']['exec_state']='exec_observed'
                        continue
                    if name=='cancel':
                        stage='cancellation'
                        # A supplied closed write-end (EOF) also means cancellation.
                        raise Stop('cancelled')
                    stage='capture_'+name;stream=r['streams'][name]
                    reads+=1
                    if reads>spec.max_reads:raise Stop('read_count')
                    limit=spec.stdout_limit if name=='stdout' else spec.stderr_limit
                    remaining=limit-stream['file_bytes']
                    raw=os.read(fds[name+'_read'],min(spec.read_chunk,remaining+1))
                    stream['wire_bytes']+=len(raw)
                    if not raw:
                        stream['eof_at']=time.monotonic_ns();selector.unregister(key.fileobj);stream_open.remove(name);continue
                    if stream['first_byte_at'] is None:stream['first_byte_at']=time.monotonic_ns()
                    if len(raw)>remaining:raise Stop('output_cap')
                    stream['file_bytes']=self._io.write(fds[name],'controls/'+name,raw,stream['file_bytes'])
                stage='capture'
            if r['child']['exit_code']!=0:raise Stop('child_exit')
            r['capture_complete']=True
        except BaseException as e:note(e,stage)
        finally:
            # One normal action on this explicit known child only. No kill fallback,
            # descendants, process scan, automatic restart or signal retry.
            if child is not None:
                try:code=None if poll_lost else poll()
                except BaseException as e:note(e,'poll_before_cleanup');code=None;r['child']['state']='outcome_unknown'
                if code is None and not poll_lost:
                    if spec.normal_stop.count==1:
                        r['child']['normal_stop_attempts']=1
                        try:child.terminate()
                        except BaseException as e:note(e,'normal_stop')
                    try:
                        until=min(spec.close_by,time.monotonic()+spec.normal_stop.wait_seconds)
                        while time.monotonic()<until:
                            if poll() is not None:break
                            time.sleep(min(.005,max(0,until-time.monotonic())))
                        if r['child']['state']!='exited_reaped':poll()
                    except BaseException as e:note(e,'reap');r['child']['state']='outcome_unknown'
            # Close selector and ALL pipe/control resources despite earlier errors.
            if selector is not None:
                rec=r['owned_fds']['selector'];rec['close_attempts']=1
                if rec['fd'] is not None and rec['identity'] is None:
                    try:rec['identity']=[str(n) for n in inode(os.fstat(rec['fd']))]
                    except BaseException as e:note(e,'identity_cleanup_selector')
                try:selector.close()
                except BaseException as e:note(e,'selector_close');r['selector_close']='unknown';rec['state']='unknown'
                else:
                    r['selector_close']='closed';rec['state']='closed';w._finite_child_active_fds.pop('selector',None)
            for name in tuple(fds):
                if name not in ('stdout','stderr','error','receipt') and not name.startswith('admission_parent_'):closefd(name)
            close_cancel()
            # Preserve actual partial length/hash, even Window.write failed midway.
            for name in ('stdout','stderr'):
                if name not in fds:continue
                try:
                    stage='readback_'+name;st=file_identity(name);stream=r['streams'][name]
                    stream['file_bytes']=st.st_size;stream['file_identity']=[str(n) for n in inode(st)]
                    cap=spec.stdout_limit if name=='stdout' else spec.stderr_limit
                    if st.st_size>cap:raise Stop('output_cap')
                    os.fsync(fds[name]);os.lseek(fds[name],0,0);h=hashlib.sha256();remaining=st.st_size
                    for _ in range((remaining+CHUNK-1)//CHUNK):
                        if time.monotonic()>spec.close_by:raise Stop('close_deadline')
                        raw=os.read(fds[name],min(CHUNK,remaining))
                        if not raw:raise Stop('hash')
                        h.update(raw);remaining-=len(raw)
                    if remaining or os.read(fds[name],1) or file_identity(name).st_size!=st.st_size:raise Stop('hash')
                    stream['sha256']=h.hexdigest();stream['readback_verified']=True
                except BaseException as e:note(e,stage)
            for name in ('stdout','stderr'):
                if name in fds:closefd(name)
            r['capture_complete']=r['capture_complete'] and all(v['readback_verified'] for v in r['streams'].values())
            # Error slot is independent, sanitized fixed256; failure remains separate.
            if r['admitted'] and error is not None and 'error' in fds:
                try:
                    raw=bounded_json(r['primary_error'],256).ljust(256,b' ')
                    terminal_write('error',raw)
                except BaseException as e:note(e,'error_slot')
            if 'error' in fds:
                try:r['error_slot']=stored_file('error')
                except BaseException as e:note(e,'error_slot_readback')
                closefd('error')
            # Outcome receipt predates its own write/close. Do not claim it contains
            # its own future durability or closure; returned final outcome adds that.
            if r['admitted'] and 'receipt' in fds:
                r['receipt']['attempts']=1;r['receipt']['state']='attempting'
                r['accounting']=w.snapshot()
                try:
                    raw=bounded_json(r,32768)
                    r['receipt'].update(terminal_write('receipt',raw),state='written_verified')
                except BaseException as e:
                    note(e,'receipt');r['receipt']['state']='failed'
                    r['receipt']['fallback']='finite-child;receipt=failed;code='+r['primary_error']['code']+';stage='+r['primary_error']['stage']
                try:r['receipt'].update(stored_file('receipt'))
                except BaseException as e:note(e,'receipt_partial_readback')
                closefd('receipt')
            elif r['admitted'] or (error is not None and (r['owned_fds'] or r['cancel_handle']['state']=='unknown')):
                r['receipt'].update(attempts=1,state='unavailable',fallback='finite-child;receipt=unavailable;no-admitted-handle')
            # Parent pins are required by ALL readback/finalization helpers. Their
            # once-only closure follows the receipt's own readback, so persisted
            # receipt honestly records them open; returned outcome adds closure.
            for name in tuple(fds):
                if name.startswith('admission_parent_'):closefd(name)
            if held and error is not None and fds:
                self.spent=True;w.stopped=True
            if running:
                if error is not None:w.stopped=True
                w._running=False
            r['component_complete']=bool(r['capture_complete'] and error is None and r['receipt']['state']=='written_verified' and all(v['state']=='closed' for v in r['owned_fds'].values()) and r['child']['state']=='exited_reaped')
            if lease_entered:w.finish(r['component_complete'])
            r['accounting']=w.snapshot() if type(w) in (Window,ChildReservation) else None
            if held:w.lock.release()
            if has_self:self.lock.release()
            # Refused nested entry must not replace the active run's final outcome.
            if has_self:self.last_result=r;self.original_error=error
        if raised is not None:raise raised
        return r
