"""Immutable finite component inputs. No CLI, endpoint or production grant."""
from dataclasses import dataclass
from reservation import ChildReservation
import fcntl
import hashlib
import math
import os
from pathlib import Path
import re
import signal
import stat
import time
import threading
from ledger import Stop, Window, CAP, CHUNK, bounded_json, inode

STDOUT='controls/stdout'
STDERR='controls/stderr'
ERROR='controls/error'
RECEIPT='controls/receipt'

@dataclass(frozen=True)
class NormalStop:
    signal: int
    count: int
    wait_seconds: float

@dataclass(frozen=True)
class CancelHandle:
    fd: int
    ownership: str

@dataclass(frozen=True)
class ChildSpec:
    operation_id: str
    source_id: str
    argv: tuple
    cwd: str
    env: tuple
    source_bytes: int
    start_by: float
    run_until: float
    close_by: float
    stdout_limit: int
    stderr_limit: int
    read_chunk: int
    max_reads: int
    max_ticks: int
    normal_stop: NormalStop
    fd_mode: str
    fd_ceiling: int


def positive(n,maximum):
    if type(n) is not int or not 0<n<=maximum:raise Stop('plan')


def finite(n):
    if type(n) not in (int,float) or not math.isfinite(n) or n<=0:raise Stop('plan')


def validate(w,s,cancel,open_directory,open_source):
    """No creations here. Bound scalar/container sizes before encoding/reading.

    Only single-process Python-file children, explicit EOF stdin, ordinary local
    regular output files and the named nonblocking cancellation read pipe fit.
    Descendants, shell/PTY/socket/inherited output modes are unsupported.
    Source/cwd identity is cooperative and must stay exclusive through exec.
    """
    if type(w) not in (Window,ChildReservation) or type(s) is not ChildSpec:raise Stop('plan')
    if type(s.operation_id) is not str or not re.fullmatch(r'[A-Za-z0-9_.-]{1,96}',s.operation_id):raise Stop('plan')
    if type(s.source_id) is not str or not re.fullmatch(r'[0-9a-f]{64}',s.source_id):raise Stop('plan')
    positive(s.fd_ceiling,1048576)
    if s.fd_ceiling<4 or os.sysconf('SC_OPEN_MAX')>s.fd_ceiling or threading.active_count()!=1 or threading.current_thread() is not threading.main_thread():raise Stop('unsupported')
    positive(s.source_bytes,65536)
    positive(s.stdout_limit,CAP);positive(s.stderr_limit,CAP)
    positive(s.read_chunk,CHUNK);positive(s.max_reads,100000);positive(s.max_ticks,100000)
    for n in (s.start_by,s.run_until,s.close_by):finite(n)
    now=time.monotonic()
    if not now<s.start_by<s.run_until<s.close_by<=now+60:raise Stop('deadline')
    if type(s.normal_stop) is not NormalStop:raise Stop('plan')
    stop=s.normal_stop
    # Exactly one explicitly admitted normal SIGTERM, or no signal at all.
    if type(stop.signal) is not int or stop.signal!=signal.SIGTERM or type(stop.count) is not int or stop.count not in (0,1):raise Stop('plan')
    finite(stop.wait_seconds)
    if stop.wait_seconds>s.close_by-s.run_until:raise Stop('plan')
    if type(s.fd_mode) is not str or s.fd_mode!='single-process-eof-stdin':raise Stop('unsupported')
    if type(s.argv) is not tuple or len(s.argv)!=5:raise Stop('unsupported')
    for text in (*s.argv,s.cwd):
        if type(text) is not str or not 1<=len(text.encode('utf-8'))<=1024 or '\x00' in text:raise Stop('plan')
    if s.argv[:4]!=('/usr/bin/python3','-I','-S','-B'):raise Stop('unsupported')
    if type(s.env) is not tuple or not 1<=len(s.env)<=32:raise Stop('plan')
    keys=set()
    for pair in s.env:
        if type(pair) is not tuple or len(pair)!=2:raise Stop('plan')
        k,v=pair
        if type(k) is not str or not re.fullmatch('[A-Za-z_][A-Za-z_0-9]{0,63}',k) or k in keys:raise Stop('plan')
        if type(v) is not str or len(v.encode('utf-8'))>4096 or '\x00' in v:raise Stop('plan')
        keys.add(k)
    if type(w) is ChildReservation:w.validate_spec(s)
    expected={STDOUT:('file',s.stdout_limit),STDERR:('file',s.stderr_limit),ERROR:('file',256),RECEIPT:('file',32768)}
    if dict(w.plan)!=expected or w.used or sum(v[1] for v in w.plan.values())>CAP:raise Stop('plan')
    # No alias to a ledger-owned resource or ambient std stream is accepted.
    owned=set(w.fds.values())|{w.root_fd,w.parent_fd}|set(getattr(w,'_finite_child_active_fds',{}).values())
    if cancel is not None:
        if type(cancel) is not CancelHandle or type(cancel.fd) is not int or cancel.fd<=2 or type(cancel.ownership) is not str or cancel.ownership not in ('owned','borrowed'):raise Stop('plan')
        if cancel.fd in owned:raise Stop('alias')
        cs=os.fstat(cancel.fd);flags=fcntl.fcntl(cancel.fd,fcntl.F_GETFL)
        if not stat.S_ISFIFO(cs.st_mode) or flags & os.O_ACCMODE != os.O_RDONLY:raise Stop('unsupported')
        # Component never changes a borrowed handle's flags.
        if not flags & os.O_NONBLOCK:raise Stop('unsupported')
    cwd=Path(s.cwd);source=Path(s.argv[-1])
    if not cwd.is_absolute() or not source.is_absolute() or source.parent!=cwd or '..' in source.parts:raise Stop('path')
    # All admission opens are registered by Controller before any identity/read
    # syscall. No opaque M1 directory/roots helper can hide a traversal FD.
    if len(cwd.parts)<2:raise Stop('unsupported')
    fd=open_directory(cwd,'admission_cwd')
    cwd_id=inode(os.fstat(fd));before=os.stat(source.name,dir_fd=fd,follow_symlinks=False)
    if not stat.S_ISREG(before.st_mode) or before.st_nlink!=1 or before.st_size!=s.source_bytes:raise Stop('source')
    inp=open_source(source.name,fd)
    st=os.fstat(inp)
    if (st.st_dev,st.st_ino,st.st_size)!=(before.st_dev,before.st_ino,before.st_size):raise Stop('drift')
    raw=os.read(inp,s.source_bytes+1)
    if len(raw)!=s.source_bytes or hashlib.sha256(raw).hexdigest()!=s.source_id:raise Stop('source')
    source_pin=(st.st_dev,st.st_ino,st.st_size,st.st_mtime_ns,st.st_ctime_ns)
    parent=open_directory(w.parent,'admission_parent')
    if inode(os.fstat(parent))!=w.parent_id or inode(os.stat(w.name,dir_fd=parent,follow_symlinks=False))!=w.root_id:raise Stop('drift')
    root=os.fstat(w.root_fd);controls=os.fstat(w.fds['controls'])
    if inode(root)!=w.root_id or not stat.S_ISDIR(root.st_mode) or stat.S_IMODE(root.st_mode)!=0o700:raise Stop('drift')
    if inode(controls)!=w.ids['controls'] or inode(os.stat('controls',dir_fd=w.root_fd,follow_symlinks=False))!=w.ids['controls'] or not stat.S_ISDIR(controls.st_mode) or stat.S_IMODE(controls.st_mode)!=0o700 or 'controls' in w.sealed:raise Stop('drift')
    for path in expected:
        try:os.stat(path.split('/')[-1],dir_fd=w.fds['controls'],follow_symlinks=False)
        except FileNotFoundError:continue
        raise Stop('collision')
    value={name:getattr(s,name) for name in s.__dataclass_fields__ if name!='normal_stop'}
    value['normal_stop']={'signal':stop.signal,'count':stop.count,'wait_seconds':str(stop.wait_seconds)}
    for name in ('start_by','run_until','close_by'):value[name]=str(value[name])
    value['destinations']={p:list(v) for p,v in w.plan.items()}
    value['ledger_root_id']=list(w.root_id)
    if type(w) is ChildReservation:value['parent_binding']=w.binding_receipt()
    value['cancel']=None if cancel is None else {'fd':cancel.fd,'ownership':cancel.ownership,'identity':[str(n) for n in inode(cs)]}
    result={'command_sha256':hashlib.sha256(bounded_json(value,196608)).hexdigest(),
            'source_sha256':s.source_id,'source_pin':source_pin,'cwd_id':cwd_id,
            'argv':s.argv,'env':s.env,'cwd':s.cwd}
    if type(w) is ChildReservation:result['parent_binding']=w.binding_receipt()
    return result
