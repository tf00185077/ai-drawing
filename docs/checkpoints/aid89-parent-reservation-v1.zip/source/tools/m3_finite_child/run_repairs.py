"""Prepare a NEW isolated fixture BEFORE any component import. No root pytest.

Run with the available administrative Python: python3 run_repairs.py NEW_ROOT independent|focused|original.
No dependency installation, prepared runtime, product import or service operation.
"""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time


def main():
    if len(sys.argv)!=3 or sys.argv[2] not in ('original','independent','focused'):raise SystemExit('supply NEW_ROOT original|independent|focused')
    body={'original':'independent_tests.py','independent':'qa77_adapted.py','focused':'repair_tests.py'}[sys.argv[2]]
    root=Path(sys.argv[1])
    if not root.is_absolute() or root.exists():raise SystemExit('new absolute root required')
    root.mkdir(parents=True,mode=0o700);root=root.resolve()
    (root/'temp').mkdir();(root/'source').mkdir()
    here=Path(__file__).resolve().parent
    for folder in (here,here.parent/'m1_bounded'):
        for p in folder.glob('*.py'):shutil.copyfile(p,root/'source'/p.name)
    runner=root/'runner.py'
    runner.write_text("import sys,runpy\nfrom pathlib import Path\nroot=Path(sys.argv[1])\nsys.path.insert(0,str(root/'source'))\nrunpy.run_path(str(root/'source/"+body+"'),run_name='__main__')\n")
    profile=root/'profile.sb'
    # This applied fixture policy is separate from the component's source API.
    profile.write_text('''(version 1)
(allow default)
(deny network*)
(deny file-write*)
(allow file-write* (subpath "'''+str(root)+'''"))
(deny file-read* (subpath "/Users/tf00185088/Desktop/tim-project/ai-drawing") (subpath "/Volumes/AI-Drawing-16T") (subpath "/Users/tf00185088/Desktop/tim-project/.ai-drawing-prepared-environments") (subpath "/Users/tf00185088/Desktop/tim-project/.ai-drawing-maintenance-backups"))
''')
    cmd=['/usr/bin/sandbox-exec','-f',str(profile),'/usr/bin/python3','-I','-S','-B',str(runner),str(root)]
    env={'PATH':'/usr/bin:/bin','LC_ALL':'C','TZ':'UTC','TMPDIR':str(root/'temp')}
    started=time.monotonic_ns()
    # Fixed unittest diagnostics to distinct prebound harness files. No PIPE,
    # communicate or read-all of child output in the capture component.
    with (root/'raw.stdout').open('xb') as out,(root/'raw.stderr').open('xb') as err:
        r=subprocess.run(cmd,cwd=root,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err,close_fds=True,timeout=40)
    record={'argv':cmd,'cwd':str(root),'submitted_env':env,'returncode':r.returncode,'elapsed_ns':time.monotonic_ns()-started,'logs':{}}
    for name in ('raw.stdout','raw.stderr'):
        path=root/name;size=path.stat().st_size
        if size>262144:raise SystemExit('unexpected harness diagnostic size; retained, no truncation')
        raw=path.read_bytes();record['logs'][name]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
    (root/'command.json').write_text(json.dumps(record,sort_keys=True,indent=2))
    print(json.dumps(record,sort_keys=True));print((root/'raw.stderr').read_text())
    return r.returncode

if __name__=='__main__':raise SystemExit(main())
