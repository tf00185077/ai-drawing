"""AID87 NEW synthetic probes only; OS isolation must precede this interpreter."""
import os,sys,pathlib,json,hashlib,errno,ctypes,resource,signal,sqlite3,time
ROOT=pathlib.Path(sys.argv[1]);CASE=sys.argv[2];RUN=ROOT/'run'
sys.path[:0]=[str(ROOT/'source/m1_bounded'),str(ROOT/'source/m2_sqlite')]
import contract as m2

def report(v):
 b=json.dumps(v,sort_keys=True,separators=(',',':')).encode();assert len(b)<=65536
 os.write(1,b+b'\n')
def denied(f):
 try:f()
 except OSError as e:
  assert e.errno in (errno.EPERM,errno.EACCES);return e.errno
 raise AssertionError('unexpected permitted action')

if CASE=='seed':
 c=sqlite3.connect(str(RUN/'state.sqlite'));c.execute(m2.FIXTURE_SCHEMA)
 ids=m2.exact_ids((ROOT/'source/m2_sqlite/exact408.txt').read_bytes())
 c.executemany('INSERT INTO lora_training_jobs VALUES (?,?,?,?,?,?,?,?,?,?,?,?)',[(i,'queued','queued',None,None,None,'keep',b'\x00raw',17,3.5,'m','d') for i in ids]);c.commit();c.close();(RUN/'custody').mkdir();(RUN/'custody/pre-B-full.sqlite').write_bytes((RUN/'state.sqlite').read_bytes())
 report({'seeded_synthetic':408,'size':(RUN/'state.sqlite').stat().st_size})
elif CASE=='native':
 libc=ctypes.CDLL(None,use_errno=True);libc.open.argtypes=[ctypes.c_char_p,ctypes.c_int];libc.open.restype=ctypes.c_int;libc.write.argtypes=[ctypes.c_int,ctypes.c_void_p,ctypes.c_size_t];libc.write.restype=ctypes.c_ssize_t;libc.close.argtypes=[ctypes.c_int]
 p=RUN/'native.bin';fd=libc.open(os.fsencode(p),os.O_CREAT|os.O_EXCL|os.O_WRONLY,ctypes.c_int(0o600));assert fd>=0
 assert libc.write(fd,b'native',6)==6;assert libc.close(fd)==0
 errs={};errs['outside']=denied(lambda:(ROOT/'outside/new.bin').write_bytes(b'x'));errs['symlink']=denied(lambda:(RUN/'escape/alias.bin').write_bytes(b'x'));errs['hardlink']=denied(lambda:os.link(ROOT/'outside/canary',RUN/'hardlink'));errs['protected_read']=denied(lambda:(ROOT/'excluded/secret').read_bytes());errs['os_cache_direct']=denied(lambda:(ROOT/'os-cache/direct.bin').write_bytes(b'x'))
 # No connect/bind/listen. Creating an unconnected socket is permitted here.
 import socket
 sock=socket.socket(socket.AF_INET,socket.SOCK_STREAM);sock.close()
 errs['network_operations']='not exercised; deny network* installed before imports'
 assert p.read_bytes()==b'native'
 report({'native_positive_bytes':6,'denials':errs,'direct_os_cache_class':'DIRECT; naming does not qualify H','product_reads_attempted':False})
elif CASE=='fsize':
 signal.signal(signal.SIGXFSZ,signal.SIG_IGN)
 assert resource.getrlimit(resource.RLIMIT_FSIZE)==(4096,4096)
 files=[]
 for i in range(8):
  p=RUN/('tmp-%02d'%i);fd=os.open(p,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600)
  try:assert os.write(fd,b'x'*4096)==4096
  finally:os.close(fd)
  files.append(p)
 fd=os.open(files[0],os.O_WRONLY|os.O_APPEND)
 try:
  try:extension={'returned':os.write(fd,b'x')}
  except OSError as e:extension={'errno':e.errno}
 finally:os.close(fd)
 observed=files[0].stat().st_size
 # Counterexample, not a promise about other platforms/builds.
 assert extension=={'returned':1} and observed==4097
 p=files[0];libc=ctypes.CDLL(None,use_errno=True)
 libc.setxattr.argtypes=[ctypes.c_char_p,ctypes.c_char_p,ctypes.c_void_p,ctypes.c_size_t,ctypes.c_uint32,ctypes.c_int];libc.setxattr.restype=ctypes.c_int
 libc.getxattr.argtypes=libc.setxattr.argtypes;libc.getxattr.restype=ctypes.c_ssize_t
 assert libc.setxattr(os.fsencode(p),b'com.example.aid87',b'm'*8192,8192,0,0)==0
 metadata_len=libc.getxattr(os.fsencode(p),b'com.example.aid87',None,0,0,0);assert metadata_len==8192 and p.stat().st_size==4097
 buf=ctypes.create_string_buffer(8192);assert libc.getxattr(os.fsencode(p),b'com.example.aid87',buf,8192,0,0)==8192 and buf.raw==b'm'*8192
 (RUN/'xattr-proof-0.bin').write_bytes(buf.raw[:4096]);(RUN/'xattr-proof-1.bin').write_bytes(buf.raw[4096:])
 report({'per_file_cap':4096,'files':len(files),'retained_lengths':sum(p.stat().st_size for p in files),'extension':extension,'first_file_length':observed,'actual_limit_readback':list(resource.getrlimit(resource.RLIMIT_FSIZE)),'system_component':{'platform':sys.platform,'release':os.uname().release,'machine':os.uname().machine},'xattr_bytes_beyond_file_cap':metadata_len,'filelength_limit_is_not_total_or_metadata_limit':True})
elif CASE=='fd':
 inherited=int(sys.argv[3]);before=(ROOT/'outside/canary').read_bytes();assert before==b'base'
 err=denied(lambda:(ROOT/'outside/canary').open('ab'))
 try:n=os.write(inherited,b'via-inherited');outcome={'returned':n}
 except OSError as e:outcome={'errno':e.errno}
 report({'new_path_open_denied':err,'preopened_fd_write':outcome,'after':(ROOT/'outside/canary').read_text(),'must_close_or_bind_before_exec':True})
elif CASE in ('sqlite','sqlite-no-journal','sqlite-lost-ack','sqlite-copy-fail'):
 c=sqlite3.connect(str(RUN/'state.sqlite'),isolation_level=None);conn=id(c);ids=m2.exact_ids((ROOT/'source/m2_sqlite/exact408.txt').read_bytes());T='2026-11-03 00:00:00.000000'
 pre=m2.fixture_snapshot(c);same=m2.fixture_snapshot(c);m2.guard_preimages(pre,same,ids)
 facts={'connection_id':conn,'version':sqlite3.sqlite_version,'sourceid':c.execute('SELECT sqlite_source_id()').fetchone()[0],'journal_mode':c.execute('PRAGMA journal_mode').fetchone()[0],'page_size':c.execute('PRAGMA page_size').fetchone()[0],'max_page_count':c.execute('PRAGMA max_page_count').fetchone()[0],'getlimit_available':hasattr(c,'getlimit'),'setlimit_available':hasattr(c,'setlimit')}
 before=hashlib.sha256((RUN/'state.sqlite').read_bytes()).hexdigest();assert (RUN/'custody/pre-B-full.sqlite').read_bytes()==(RUN/'state.sqlite').read_bytes();changed=0;c.execute('BEGIN IMMEDIATE')
 if CASE=='sqlite-no-journal':
  try:c.execute(m2.UPDATE_SQL,{'T':T,'approved_job_id':ids[0]});raise AssertionError('journal denied but update succeeded')
  except sqlite3.OperationalError as e:err=type(e).__name__;sqlcode=getattr(e,'sqlite_errorcode',None)
  transaction=c.in_transaction
  if c.in_transaction:c.execute('ROLLBACK')
  c.close();assert hashlib.sha256((RUN/'state.sqlite').read_bytes()).hexdigest()==before
  report({'profile_gap':'omitting native rollback-journal denies exact first UPDATE','error_class':err,'sqlite_code':sqlcode,'in_transaction_after_error':transaction,'main_bytes_unchanged':True,'rows_changed_committed':0,'facts':facts})
 else:
  for i in ids:
   cur=c.execute(m2.UPDATE_SQL,{'T':T,'approved_job_id':i});assert cur.rowcount==1;changed+=cur.rowcount;cur.close()
  post=m2.fixture_snapshot(c);m2.guard_postimages(pre,post,ids,T);assert id(c)==conn
  during=[{'path':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in RUN.iterdir() if p.is_file()]
  for p in RUN.iterdir():
   if p.is_file():
    raw_companion=p.read_bytes();assert len(raw_companion)<=2097152
    (RUN/'custody'/('during-'+p.name)).write_bytes(raw_companion)
  c.execute('COMMIT');assert not c.in_transaction
  # No retry: injected caller acknowledgement loss is AFTER real commit.
  acknowledged=True
  if CASE=='sqlite-lost-ack':
   try:raise OSError(errno.EIO,'synthetic caller acknowledgement loss after real COMMIT')
   except OSError:acknowledged=False
  known=m2.transaction_state(True,True,acknowledged,False,c.in_transaction)
  after=m2.fixture_snapshot(c);m2.guard_postimages(pre,after,ids,T);assert id(c)==conn
  c.close()
  # Complete independent full postcommit main copy, not delta/page size estimate.
  src=RUN/'state.sqlite';dst=RUN/'postcommit-full.sqlite';raw=src.read_bytes();assert len(raw)<=2097152
  fd=os.open(dst,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600)
  copy_error=None
  try:
   if CASE=='sqlite-copy-fail':
    assert os.write(fd,raw[:17])==17
    raise OSError(errno.ENOSPC,'synthetic postcommit copy adapter failure')
   off=0
   while off<len(raw):off+=os.write(fd,raw[off:off+65536])
   os.fsync(fd)
  except OSError as e:
   assert CASE=='sqlite-copy-fail' and e.errno==errno.ENOSPC;copy_error={'errno':e.errno,'injected':True,'stage':'postcommit_copy','retry':False}
  finally:os.close(fd)
  if copy_error is None:assert dst.read_bytes()==raw
  else:assert dst.read_bytes()==raw[:17] and src.read_bytes()==raw
  report({'same_connection_id':conn,'facts':facts,'guarded_rows':changed,'five_fields_only':True,'during_transaction':during,'postcommit_main_bytes':len(raw),'full_copy_bytes':dst.stat().st_size,'copy_error':copy_error,'precopy_and_journal_retained':sorted(p.name for p in (RUN/'custody').iterdir()),'source_start_allowed':False,'copy_sha256':hashlib.sha256(raw).hexdigest(),'commit_receipt_state':known,'fresh_readback_is_fixture_only':True,'operational_native_bound':None,'production_sql_enabled':False})
else:raise AssertionError('unknown fixed case')
