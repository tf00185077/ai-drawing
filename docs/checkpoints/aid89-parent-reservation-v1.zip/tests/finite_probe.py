"""Selective accepted-component reuse plus NEW operation-specific native counterexample."""
import os,sys,pathlib,unittest,json
ROOT=pathlib.Path(sys.argv[1]);sys.argv[1]=str(ROOT/'run')
sys.path[:0]=[str(ROOT/'source/m3_finite_child'),str(ROOT/'source/m1_bounded')]
import qa77_adapted as iq
from handoff_tests import HandoffTests

class NativeBoundary(iq.IndependentQA):
 def test_full_operation_plan_cannot_be_passed_as_four_slot_window(self):
  from ledger import Window
  from controller import Controller
  original,s,c=self.prepare();slots=dict(original.plan);slots['controls/native-B']=('native',64)
  w=Window(self.root,'full-plan',slots);self.windows.append(w);r=Controller(w).run(s);self.save('full-plan-result',r)
  self.assertFalse(r['admitted']);self.assertEqual(r['accounting']['charged'],0);self.assertEqual(list((w.root/'controls').iterdir()),[]);self.assertEqual(r['child']['state'],'not_started')
 def test_new_native_write_is_outside_component_ledger(self):
  p=self.root/'os-cache-native';script="import os,ctypes\np="+repr(str(p))+"\nfd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)\nlib=ctypes.CDLL(None);lib.write.argtypes=[ctypes.c_int,ctypes.c_void_p,ctypes.c_size_t];lib.write.restype=ctypes.c_ssize_t\nassert lib.write(fd,b'n'*64,64)==64\nos.close(fd);os.write(1,b'ok')"
  w,s,c=self.prepare(script);r=c.run(s);self.save('result',r)
  self.assertTrue(r['component_complete']);self.assertEqual(p.read_bytes(),b'n'*64);self.assertNotIn(p.name,w.plan);self.assertEqual((w.root/'controls/stdout').read_bytes(),b'ok');self.check(w,r)
  self.save('native-accounting-gap',{'actual_direct_native_bytes':64,'in_component_plan':False,'component_charge':r['accounting']['charged'],'H_eligible':False,'operation_admission':False})
 def test_new_os_denied_native_write_retains_error_and_receipt(self):
  p=ROOT/'outside/component-native';script="import os\ntry:os.open("+repr(str(p))+",os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)\nexcept PermissionError:os.write(1,b'DENIED');raise SystemExit(7)\nraise AssertionError('escape')"
  w,s,c=self.prepare(script);r=c.run(s);self.save('result',r);self.assertFalse(r['component_complete']);self.assertEqual(r['primary_error']['code'],'child_exit');self.assertEqual((w.root/'controls/stdout').read_bytes(),b'DENIED');self.assertFalse(p.exists());self.assertEqual(r['receipt']['attempts'],1);self.check(w,r)

suite=unittest.TestSuite([
 NativeBoundary('test_full_operation_plan_cannot_be_passed_as_four_slot_window'),
 NativeBoundary('test_new_native_write_is_outside_component_ledger'),
 NativeBoundary('test_new_os_denied_native_write_retains_error_and_receipt'),
 iq.IndependentQA('test_eof_cancel_borrowed_flags_and_owned_rejection'),
 HandoffTests('test_parent_pin_late_close_failure_is_unknown_after_receipt_and_stops_reentry'),
])
r=unittest.TextTestRunner(verbosity=2).run(suite);raise SystemExit(0 if r.wasSuccessful() else 1)
