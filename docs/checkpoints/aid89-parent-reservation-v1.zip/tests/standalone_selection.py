"""Selective unchanged standalone safety tests; not full component/kit QA."""
import os,sys,pathlib,unittest,json
ROOT=pathlib.Path(sys.argv[1]);sys.path[:0]=[str(ROOT/'source/m1_bounded'),str(ROOT/'source/m3_finite_child')];sys.argv[1]=str(ROOT/'run')
import qa77_adapted as iq
from qa79_handoff_tests import Independent79
from handoff_tests import HandoffTests
from repair_tests import RepairTests
names=[
 (iq.IndependentQA,'test_prewrite_full_shared_charge_before_any_pipe_or_spawn'),
 (iq.IndependentQA,'test_binary_both_exact_caps_and_undrained_tail'),
 (iq.IndependentQA,'test_eof_cancel_borrowed_flags_and_owned_rejection'),
 (Independent79,'test_02_pure_invalid_plan_owned_cancel_closed_then_valid_callable'),
 (Independent79,'test_03_owned_cancel_alias_rejected_without_closing_borrowed_anchor'),
 (Independent79,'test_05_full_cardinality_error_metadata_accounting_envelope'),
 (Independent79,'test_06_escape_expansion_refused_before_output_pipe_spawn'),
 (Independent79,'test_07_genuine_receipt_partial_failure_keeps_bound_charge_and_hash'),
 (HandoffTests,'test_no_opaque_acquiring_window_helpers_in_supported_capture'),
 (HandoffTests,'test_parent_pin_late_close_failure_is_unknown_after_receipt_and_stops_reentry'),
]
suite=unittest.TestSuite(cls(name) for cls,name in names);r=unittest.TextTestRunner(verbosity=2).run(suite);raise SystemExit(0 if r.wasSuccessful() else 1)
