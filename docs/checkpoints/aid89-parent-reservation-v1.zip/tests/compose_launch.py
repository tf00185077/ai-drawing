"""Administrative fixture launcher; policy is installed before candidate imports."""
import os,sys,pathlib,shutil,json,subprocess,resource,time,hashlib
source=pathlib.Path(sys.argv[1]).resolve();root=pathlib.Path(sys.argv[2]);test=sys.argv[3] if len(sys.argv)>3 else 'composition_tests.py'
assert root.is_absolute() and not root.exists();root.mkdir(parents=True,mode=0o700);root=root.resolve();(root/'run').mkdir(mode=0o700);(root/'source').mkdir()
for name in ('m1_bounded','m3_finite_child'):shutil.copytree(source/'source/tools'/name,root/'source'/name)
shutil.copyfile(source/'tests'/test,root/'tests.py');shutil.copyfile(source/'profile/operation-profile.json',root/'operation-profile.json')
protected=['/Users/tf00185088/Desktop/tim-project/ai-drawing','/Volumes/AI-Drawing-16T','/Users/tf00185088/Desktop/tim-project/.ai-drawing-prepared-environments','/Users/tf00185088/Desktop/tim-project/.ai-drawing-maintenance-backups']
policy='(version 1)\n(allow default)\n(deny network*)\n(deny file-write*)\n(allow file-write* (subpath '+json.dumps(str(root/'run'))+'))\n(deny file-link)\n(deny file-read* '+' '.join('(subpath '+json.dumps(p)+')' for p in protected)+')\n'
(root/'policy.sb').write_text(policy)
cmd=['/usr/bin/sandbox-exec','-f',str(root/'policy.sb'),'/usr/bin/python3','-I','-S','-B',str(root/'tests.py'),str(root)]
env={'PATH':'/usr/bin:/bin','LC_ALL':'C','TZ':'UTC','TMPDIR':str(root/'run')}
def limits():
 resource.setrlimit(resource.RLIMIT_CORE,(0,0));resource.setrlimit(resource.RLIMIT_NOFILE,(128,128));resource.setrlimit(resource.RLIMIT_FSIZE,(2097152,2097152))
t=time.monotonic_ns()
with (root/'stdout').open('xb') as out,(root/'stderr').open('xb') as err:r=subprocess.run(cmd,cwd=root,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err,close_fds=True,preexec_fn=limits,timeout=45)
rec={'argv':cmd,'cwd':str(root),'submitted_env':env,'limits':{'CORE':0,'NOFILE':128,'FSIZE':2097152},'exit':r.returncode,'elapsed_ns':time.monotonic_ns()-t,'logs':{}}
for n in ('stdout','stderr'):
 b=(root/n).read_bytes();rec['logs'][n]={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()};print(b.decode(errors='replace'))
(root/'command.json').write_text(json.dumps(rec,indent=2));sys.exit(r.returncode)
