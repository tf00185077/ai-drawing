"""Bounded composition regressions. NEW regular fixtures/fake children only."""
import dataclasses,errno,fcntl,hashlib,json,os,pathlib,signal,sys,time,unittest
from unittest.mock import patch
ROOT=pathlib.Path(sys.argv[1]);sys.argv[:]=[sys.argv[0]]
sys.path[:0]=[str(ROOT/'source/m1_bounded'),str(ROOT/'source/m3_finite_child')]
import ledger,controller as mod
from ledger import Window,Stop,CAP
from controller import Controller
from contract import ChildSpec,NormalStop,CancelHandle
C={'controls/stdout':('file',8192),'controls/stderr':('file',8192),'controls/error':('file',256),'controls/receipt':('file',32768)}

class Composition(unittest.TestCase):
 def setUp(self):
  self.root=ROOT/'run'/self._testMethodName;self.root.mkdir(mode=0o700);(self.root/'temp').mkdir();self.windows=[];self.closed=[]
  self.realclose=os.close
  def close(fd):
   st=os.fstat(fd);self.realclose(fd)
   try:os.fstat(fd)
   except OSError as e:self.assertEqual(e.errno,errno.EBADF)
   else:raise AssertionError('not closed')
   self.closed.append({'fd':fd,'identity':[str(st.st_dev),str(st.st_ino)],'immediate_errno':errno.EBADF})
  self.closer=patch('os.close',close);self.closer.start()
  factory=mod.selectors.DefaultSelector;selector_close=factory.close
  def close_selector(obj):
   fd=obj.fileno();st=os.fstat(fd);selector_close(obj)
   try:os.fstat(fd)
   except OSError as e:self.assertEqual(e.errno,errno.EBADF)
   else:raise AssertionError('selector not closed')
   self.closed.append({'fd':fd,'identity':[str(st.st_dev),str(st.st_ino)],'immediate_errno':errno.EBADF,'primitive':'selector.close'})
  self.selector_closer=patch.object(factory,'close',close_selector);self.selector_closer.start()
 def tearDown(self):
  try:
   for w in self.windows:w.close()
   self.save('raw-close-observations',self.closed)
  finally:self.selector_closer.stop();self.closer.stop()
 def save(self,n,v): (self.root/(n+'.json')).write_text(json.dumps(v,sort_keys=True,indent=2))
 def spec(self,source="import os\nos.write(1,b'ok');os.write(2,b'err')"):
  f=self.root/'child.py';f.write_text(source);t=time.monotonic()
  return ChildSpec(self._testMethodName,hashlib.sha256(f.read_bytes()).hexdigest(),('/usr/bin/python3','-I','-S','-B',str(f)),str(self.root),(('PATH','/usr/bin:/bin'),('LC_ALL','C'),('TZ','UTC'),('TMPDIR',str(self.root/'temp'))),f.stat().st_size,t+2,t+3,t+4,8192,8192,256,5000,10000,NormalStop(int(signal.SIGTERM),1,.3),'single-process-eof-stdin',1048576)
 def window(self,slots,**kw):
  w=Window(self.root,'w'+str(len(self.windows)),slots,**kw);self.windows.append(w);return w
 def bound(self,source=None,slots=None):
  self.assertTrue(hasattr(ledger,'OperationBinding'),'parent-bound reservation API missing')
  s=self.spec() if source is None else self.spec(source)
  b=ledger.OperationBinding(s.operation_id,'fixture-epoch',s.source_id)
  plan=dict(C);plan.update({'pre-adoption/state':('file',10),'restore-check/state':('file',10),'temp/fixture-B':('file',8),'post-B-state/state':('file',8),'temp/fixture-S':('file',8),'post-start-state/state':('file',8),'controls/native-B':('native',64)})
  if slots is not None:plan=slots
  w=self.window(plan,binding=b,lifetimes={p:'retained-through-final-closure' for p in plan})
  return w,s,b
 def refuse(self,w,s,view):
  before=w.snapshot();r=Controller(view).run(s);self.save('refusal',r)
  self.assertFalse(r['admitted']);self.assertEqual(r['child']['state'],'not_started');self.assertEqual(w.snapshot()['charged'],before['charged']);self.assertEqual(list((w.root/'controls').iterdir()),[]);self.assertEqual(r['accounting'],view.snapshot());return r
 def stopped(self,w):
  before=w.snapshot()
  with self.assertRaises(Stop):w.stream('post-B-state/state',[b'x'])
  self.assertEqual(w.snapshot()['charged'],before['charged']);self.assertFalse((w.root/'post-B-state/state').exists());self.assertTrue(w.stopped);self.assertFalse(w.snapshot()['retry_b_allowed'])
 def test_original_full_and_preused_window_refuse(self):
  s=self.spec()
  for plan,preused in [(dict(C,**{'controls/native-B':('native',64)}),False),(dict(C),True)]:
   w=self.window(plan)
   if preused:w.stream('controls/stdout',[b'x'])
   before=w.snapshot();r=Controller(w).run(s);self.save('original-'+str(preused),r);self.assertFalse(r['admitted']);self.assertEqual(r['child']['state'],'not_started');self.assertEqual(r['accounting']['charged'],before['charged']);self.assertFalse((w.root/'controls/receipt').exists())
 def test_post_start_namespace_positive(self):
  w=self.window({'controls/error':('file',256),'post-start-state/state':('file',8)})
  w.stream('post-start-state/state',[b'post-S!!']);self.assertEqual((w.root/'post-start-state/state').read_bytes(),b'post-S!!')
 def test_positive_preused_parent_full_copies_and_closure(self):
  w,s,b=self.bound();w.stream('pre-adoption/state',[b'cold-state']);w.stream('restore-check/state',[(w.root/'pre-adoption/state').read_bytes()]);v=w.reserve_child(b);self.assertEqual(v.snapshot()['charged'],0)
  seen=[];opening=os.open;pipe=os.pipe;spawn=mod.spawn
  def op(path,flags,*a,**kw):
   if str(path) in ('stdout','stderr','error','receipt') and flags&os.O_CREAT:
    p='controls/'+str(path);self.assertEqual(w.charged[p],w.plan[p][1]);seen.append({'before_output':p,'parent':w.snapshot(),'view':v.snapshot()})
   return opening(path,flags,*a,**kw)
  def checkpoint(where):
   self.assertEqual(v.snapshot()['charged'],49408);self.assertEqual(w.snapshot()['charged'],49428);seen.append({'before':where,'parent':w.snapshot(),'view':v.snapshot()})
  def pi():checkpoint('pipe');return pipe()
  def sp(*a):checkpoint('child');return spawn(*a)
  with patch('os.open',op),patch('os.pipe',pi),patch.object(mod,'spawn',sp):r=Controller(v).run(s)
  self.save('result',r);self.save('before-effects',seen);self.assertTrue(r['component_complete']);self.assertEqual((w.root/'controls/stdout').read_bytes(),b'ok');self.assertEqual((w.root/'controls/stderr').read_bytes(),b'err');self.assertFalse(w.stopped)
  for n,raw,original,copy in [('B',b'post-B!!','temp/fixture-B','post-B-state/state'),('S',b'post-S!!','temp/fixture-S','post-start-state/state')]:
   w.stream(original,[raw]);w.stream(copy,[(w.root/original).read_bytes()]);self.assertEqual((w.root/copy).read_bytes(),raw)
  self.assertEqual(w.snapshot()['plan_total'],49524);self.assertEqual(w.snapshot()['charged'],49460);self.assertEqual(w.snapshot()['reserved_remaining'],64)
  self.assertEqual(v.snapshot()['charged'],49408);self.assertEqual(r['accounting'],v.snapshot());self.assertEqual(r['identity']['parent_binding']['source_id'],s.source_id)
  stored=json.loads((w.root/'controls/receipt').read_bytes());self.assertEqual(stored['receipt']['state'],'attempting');self.assertFalse(stored['component_complete']);self.assertTrue(any(n.startswith('admission_parent_') and x['state']=='open' for n,x in stored['owned_fds'].items()))
  self.assertTrue(all(x['state']=='closed' for x in r['owned_fds'].values()));self.assertLessEqual(len((w.root/'controls/receipt').read_bytes()),r['receipt_bound']);self.assertLessEqual(r['receipt_bound'],32768)
  self.save('both-snapshots',{'parent':w.snapshot(),'view':v.snapshot(),'fake_state_not_database':True});self.save('parent-anchor-identities',{str(fd):[str(n) for n in ledger.inode(os.fstat(fd))] for fd in [*w.fds.values(),w.root_fd,w.parent_fd]});w.close();self.assertTrue(w.stopped);self.assertEqual(w.snapshot()['closure_state'],'closed');self.save('final-parent-closure',w.snapshot())
 def test_missing_lifetime_and_overcap_refuse_before_root(self):
  self.assertTrue(hasattr(ledger,'OperationBinding'),'parent-bound reservation API missing');s=self.spec();b=ledger.OperationBinding(s.operation_id,'epoch',s.source_id)
  for name,slots,life in [('life',dict(C),{}),('cap',dict(C,**{'controls/big':('native',CAP)}),None)]:
   with self.assertRaises(Stop):Window(self.root,name,slots,binding=b,lifetimes=life if life is not None else {p:'retained' for p in slots})
   self.assertFalse((self.root/name).exists())
 def test_missing_slot_and_used_capture_refuse(self):
  for used in (False,True):
   plan=dict(C)
   if not used:del plan['controls/stderr']
   w,s,b=self.bound(slots=plan)
   if used:w.stream('controls/stdout',[b'x'])
   before=w.snapshot()
   with self.assertRaises(Stop):w.reserve_child(b)
   self.assertEqual(w.snapshot(),before)
 def test_overlap_and_parent_cannot_borrow_reserved_slot(self):
  w,s,b=self.bound();v=w.reserve_child(b);before=w.snapshot()
  with self.assertRaises(Stop):w.reserve_child(b)
  with self.assertRaises(Stop):w.stream('controls/stdout',[b'x'])
  with self.assertRaises(Stop):v._charge('post-B-state/state','file')
  self.assertEqual(w.snapshot()['charged'],before['charged']);self.assertFalse((w.root/'controls/stdout').exists())
 def test_wrong_operation_epoch_source_bindings_refuse(self):
  w,s,b=self.bound()
  for bad in [dataclasses.replace(b,operation_id='other'),dataclasses.replace(b,epoch='stale'),dataclasses.replace(b,source_id='0'*64)]:
   with self.assertRaises(Stop):w.reserve_child(bad)
  self.assertEqual(w.snapshot()['charged'],0)
 def test_wrong_child_source_refuses_before_source_open(self):
  w,s,b=self.bound();v=w.reserve_child(b);bad=dataclasses.replace(s,source_id='0'*64)
  with patch('os.open',side_effect=AssertionError('must not open')):r=self.refuse(w,bad,v)
  self.assertEqual(r['primary_error']['code'],'source');self.stopped(w)
 def test_stale_lease_and_wrong_parent_refuse(self):
  w,s,b=self.bound();v=w.reserve_child(b);r=Controller(v).run(s);self.assertTrue(r['component_complete']);before=w.snapshot()
  r=Controller(v).run(s);self.save('stale',r);self.assertFalse(r['admitted']);self.assertEqual(w.snapshot()['charged'],before['charged'])
  # A lease cannot be transplanted to a second, even equal, parent ledger.
  other=self.window(dict(w.plan),binding=b,lifetimes=dict(w.lifetimes));v._parent=other
  r=Controller(v).run(s);self.save('wrong-parent',r);self.assertFalse(r['admitted']);self.assertEqual(other.snapshot()['charged'],0);self.assertEqual(list((other.root/'controls').iterdir()),[])
 def test_parent_stop_and_commit_unknown_refuse(self):
  for why in ('stop','unknown'):
   w,s,b=self.bound();v=w.reserve_child(b)
   if why=='stop':w.stopped=True
   else:w.commit='unknown'
   self.refuse(w,s,v);self.stopped(w)
   with self.assertRaises(Stop):w.stopped=False
   if why=='unknown':
    with self.assertRaises(Stop):w.commit='not_attempted'
 def test_busy_parent_and_nested_entry_do_not_damage_active_run(self):
  w,s,b=self.bound();v=w.reserve_child(b);real=mod.spawn;observed=[]
  def spawn(*a):
   observed.append(Controller(v).run(s))
   with self.assertRaisesRegex(Stop,'busy'):w.stream('post-B-state/state',[b'x'])
   with self.assertRaisesRegex(Stop,'busy'):w.run('copy',lambda:None)
   with self.assertRaisesRegex(Stop,'busy'):w.close()
   return real(*a)
  with patch.object(mod,'spawn',spawn):r=Controller(v).run(s)
  self.assertTrue(r['component_complete']);self.assertEqual(observed[0]['primary_error']['code'],'busy');self.assertFalse(w.stopped);self.save('nested',observed)
 def test_borrowed_cancel_consumes_no_byte_and_preserves_flags(self):
  w,s,b=self.bound('import time\ntime.sleep(.3)');v=w.reserve_child(b);rd,wr=os.pipe();os.set_blocking(rd,False);os.write(wr,b'C');flags=fcntl.fcntl(rd,fcntl.F_GETFL)
  try:
   r=Controller(v).run(s,CancelHandle(rd,'borrowed'));self.save('result',r);self.assertEqual(r['primary_error']['code'],'cancelled');self.assertEqual(os.read(rd,1),b'C');self.assertEqual(flags,fcntl.fcntl(rd,fcntl.F_GETFL));self.stopped(w)
  finally:os.close(rd);os.close(wr)
 def test_child_error_and_capture_error_stop_parent(self):
  for source in ['raise SystemExit(7)',"import os\nos.write(1,b'x'*8193)"]:
   w,s,b=self.bound(source);v=w.reserve_child(b);r=Controller(v).run(s);self.save('result-'+str(len(self.windows)),r);self.assertFalse(r['component_complete']);self.assertIn(r['primary_error']['code'],('child_exit','output_cap'));self.stopped(w)
 def test_interruption_before_pipe_return_stops_parent(self):
  w,s,b=self.bound();v=w.reserve_child(b);c=Controller(v);err=KeyboardInterrupt('fixture')
  with patch('os.pipe',side_effect=err):
   with self.assertRaises(KeyboardInterrupt):c.run(s)
  self.save('result',c.last_result);self.assertIs(c.original_error,err);self.assertEqual(c.last_result['child']['state'],'not_started');self.stopped(w)
 def test_receipt_insufficient_before_outputs_or_child(self):
  w,s,b=self.bound();v=w.reserve_child(b);large=tuple(('K'+str(i),'\u0001'*100) for i in range(32));s=dataclasses.replace(s,env=large)
  with patch('os.pipe',side_effect=AssertionError('no pipe')),patch.object(mod,'spawn',side_effect=AssertionError('no child')):r=self.refuse(w,s,v)
  self.assertEqual(r['primary_error']['code'],'limit');self.stopped(w)
 def test_late_parent_pin_close_unknown_propagates(self):
  w,s,b=self.bound();v=w.reserve_child(b);c=Controller(v);close=os.close;failed=[]
  def cl(fd):
   if c.active_child is not None and fd==getattr(w,'_finite_child_active_fds',{}).get('admission_parent_1'):
    failed.append(fd);raise OSError(errno.EIO,'fixture late close')
   close(fd)
  try:
   with patch('os.close',cl):r=c.run(s)
   self.save('result',r);self.assertTrue(r['capture_complete']);self.assertFalse(r['component_complete']);self.assertEqual(r['receipt']['state'],'written_verified');self.assertEqual(r['owned_fds']['admission_parent_1']['state'],'unknown');self.assertEqual(len(failed),1);self.stopped(w)
  finally:
   for fd in failed:close(fd)
   self.save('harness-known-only-cleanup',failed)
 def test_receipt_write_failure_keeps_parent_stopped(self):
  w,s,b=self.bound();v=w.reserve_child(b);c=Controller(v);write=os.write
  def wr(fd,raw):
   if fd==getattr(w,'_finite_child_active_fds',{}).get('receipt'):raise OSError(errno.ENOSPC,'injected receipt failure')
   return write(fd,raw)
  with patch('os.write',wr):r=c.run(s)
  self.save('result',r);self.assertEqual(r['receipt']['state'],'failed');self.assertFalse(r['component_complete']);self.stopped(w)
 def test_undeclared_destination_stops_before_file(self):
  w,s,b=self.bound()
  with self.assertRaises(Stop):w.stream('post-start-state/undeclared',[b'x'])
  self.assertFalse((w.root/'post-start-state/undeclared').exists());self.assertEqual(w.snapshot()['charged'],0);self.stopped(w)
 def test_original_argv_unsupported_before_source_open(self):
  w,s,b=self.bound();v=w.reserve_child(b)
  baseline=json.loads((ROOT/'operation-profile.json').read_text())['original_baseline']['argv'];s=dataclasses.replace(s,argv=tuple(baseline))
  with patch('os.open',side_effect=AssertionError('no source open')),patch('os.pipe',side_effect=AssertionError('no pipe')):r=self.refuse(w,s,v)
  self.assertEqual(r['primary_error']['code'],'unsupported');self.stopped(w)

 def test_plan_cannot_be_reassigned_after_admission(self):
  w,s,b=self.bound();before=w.snapshot()
  with self.assertRaises(AttributeError):w.plan=dict(C)
  with self.assertRaises(TypeError):w.plan['controls/new']=('file',1)
  with self.assertRaises(TypeError):w.lifetimes['controls/stdout']='changed'
  with self.assertRaises(dataclasses.FrozenInstanceError):b.epoch='other'
  self.assertEqual(w.snapshot(),before)
 def test_reservation_cannot_enter_from_parent_stream_callback(self):
  w,s,b=self.bound();v=w.reserve_child(b);seen=[]
  def chunks():
   seen.append(Controller(v).run(s))
   with self.assertRaisesRegex(Stop,'busy'):w.reserve_child(b)
   yield b'cold-state'
  w.stream('pre-adoption/state',chunks());self.save('nested-stream',seen)
  self.assertEqual(seen[0]['primary_error']['code'],'busy');self.assertFalse(seen[0]['admitted']);self.assertEqual(w.snapshot()['charged'],10);self.assertFalse((w.root/'controls/stdout').exists());self.assertFalse(w.stopped)
 def test_parent_stop_after_first_pipe_prevents_launch(self):
  w,s,b=self.bound();v=w.reserve_child(b);pipe=os.pipe;seen=[]
  def pi():
   pair=pipe();seen.append(pair);w.stopped=True;return pair
  with patch('os.pipe',pi),patch.object(mod,'spawn',side_effect=AssertionError('must not spawn after stop')):r=Controller(v).run(s)
  self.save('result',r);self.assertEqual(r['primary_error']['code'],'stopped');self.assertEqual(r['child']['state'],'not_started');self.assertEqual(len(seen),1);self.stopped(w)
 def test_outer_anchor_failure_remains_unknown_and_charged(self):
  w,s,b=self.bound();v=w.reserve_child(b);r=Controller(v).run(s);self.assertTrue(r['component_complete']);before=w.snapshot()['charged'];target=w.root_fd;close=os.close;held=[]
  def cl(fd):
   if fd==target:held.append(fd);raise OSError(errno.EIO,'outer anchor')
   close(fd)
  try:
   with patch('os.close',cl):
    with self.assertRaises(OSError):w.close()
   self.assertEqual(w.snapshot()['closure_state'],'unknown');w.close();self.assertEqual(w.snapshot()['closure_state'],'unknown');self.assertEqual(w.snapshot()['charged'],before);self.stopped(w);self.save('parent-unknown',w.snapshot())
  finally:
   for fd in held:close(fd)
   self.save('harness-known-only-cleanup',held)
 def test_commit_terminal_state_cannot_be_relabelled(self):
  w,s,b=self.bound();w.commit='known_committed'
  with self.assertRaises(Stop):w.commit='not_attempted'
  self.assertEqual(w.commit,'known_committed')
 def test_capture_symlink_alias_refuses_before_output_charge(self):
  w,s,b=self.bound();v=w.reserve_child(b);target=self.root/'existing';target.write_bytes(b'keep');os.symlink(target,w.root/'controls/stdout')
  r=Controller(v).run(s);self.save('result',r);self.assertEqual(r['primary_error']['code'],'collision');self.assertEqual(w.snapshot()['charged'],0);self.assertEqual(target.read_bytes(),b'keep');self.stopped(w)
 def test_large_parent_projection_does_not_duplicate_or_encode_full_parent(self):
  plan=dict(C);plan.update({'controls/slot'+str(i):('native',1) for i in range(1000)})
  w,s,b=self.bound(slots=plan);v=w.reserve_child(b);r=Controller(v).run(s);self.save('result',r)
  self.assertTrue(r['component_complete']);self.assertEqual(w.snapshot()['plan_total'],50408);self.assertEqual(w.snapshot()['charged'],49408);self.assertEqual(w.snapshot()['reserved_remaining'],1000);self.assertEqual(len(r['accounting']['slots']),4);self.assertEqual(len(r['identity']['parent_binding']['parent_plan_sha256']),64)

 def test_unknown_binding_refuses_before_root_creation(self):
  self.assertTrue(hasattr(ledger,'OperationBinding'));s=self.spec();b=ledger.OperationBinding(s.operation_id,'epoch',s.source_id)
  with self.assertRaises(Stop):Window(self.root,'unknown',dict(C),commit='unknown',binding=b,lifetimes={p:'retained' for p in C})
  self.assertFalse((self.root/'unknown').exists())
 def test_parent_stream_exception_stops_child_and_preserves_partial(self):
  w,s,b=self.bound();v=w.reserve_child(b)
  def chunks():
   yield b'cold-state'
   raise RuntimeError('fixture finalizer')
  with self.assertRaisesRegex(RuntimeError,'fixture finalizer'):w.stream('pre-adoption/state',chunks())
  self.assertEqual((w.root/'pre-adoption/state').read_bytes(),b'cold-state');self.assertEqual(w.snapshot()['charged'],10);self.refuse(w,s,v);self.stopped(w)
 def test_view_full_receipt_envelope_includes_exact_binding(self):
  import receipt_bound as rb,copy
  while len(self.root.parts)<32:self.root=self.root/'q';self.root.mkdir()
  (self.root/'temp').mkdir();s=self.spec("import os\nos.write(1,b'ok')");s=dataclasses.replace(s,operation_id='X'*96,stdout_limit=CAP-33025,stderr_limit=1,env=s.env+tuple(('K'+str(i),'tiny') for i in range(28)))
  b=ledger.OperationBinding(s.operation_id,'E'*96,s.source_id);plan={'controls/stdout':('file',CAP-33025),'controls/stderr':('file',1),'controls/error':('file',256),'controls/receipt':('file',32768)}
  w=self.window(plan,binding=b,lifetimes={p:'retained' for p in plan});v=w.reserve_child(b);enc=rb.bounded_json;upper=[]
  def encode(value,limit):
   raw=enc(value,limit)
   if limit==32768:upper.append(copy.deepcopy(value))
   return raw
  with patch.object(rb,'bounded_json',encode):r=Controller(v).run(s)
  self.save('result',r);self.assertTrue(r['component_complete']);self.assertEqual(w.snapshot()['charged'],CAP);env=upper[0];self.save('admission-envelope',env)
  self.assertEqual(len(json.dumps(env,ensure_ascii=True,sort_keys=True,separators=(',',':')).encode()),r['receipt_bound']);self.assertEqual(r['identity']['parent_binding'],env['identity']['parent_binding']);self.assertLessEqual(r['receipt_bound'],32768)
  def cover(actual,maximum):
   if actual is None:return
   if type(actual) is dict:
    self.assertTrue(set(actual)<=set(maximum))
    for key,value in actual.items():cover(value,maximum[key])
   elif type(actual) in (list,tuple):
    self.assertLessEqual(len(actual),len(maximum))
    for i,value in enumerate(actual):cover(value,maximum[i])
   else:self.assertLessEqual(len(json.dumps(actual,ensure_ascii=True)),len(json.dumps(maximum,ensure_ascii=True)))
  cover(r,env);cover(json.loads((w.root/'controls/receipt').read_bytes()),env)

unittest.main(verbosity=2)
