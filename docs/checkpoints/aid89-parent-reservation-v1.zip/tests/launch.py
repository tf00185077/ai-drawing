"""Administrative launcher: fixed synthetic cases; never imports product/prepared/SQLite here."""
import os,sys,pathlib,subprocess,shutil,time,json,hashlib,resource
SOURCE=pathlib.Path(__file__).resolve().parent.parent
parent=pathlib.Path(sys.argv[1]);case=sys.argv[2];assert case in ('native','fsize','fd','sqlite','sqlite-no-journal','sqlite-lost-ack','sqlite-copy-fail','finite')
assert parent.is_absolute() and not parent.exists();parent.mkdir(parents=True,mode=0o700);root=parent.resolve()
for name in ('run','temp','outside','excluded','os-cache'): (root/name).mkdir(mode=0o700)
(root/'outside/canary').write_bytes(b'base');(root/'excluded/secret').write_bytes(b'fixture-only');os.symlink(root/'outside',root/'run/escape')
(root/'source').mkdir()
for name in ('m1_bounded','m2_sqlite','m3_finite_child'):
 shutil.copytree(SOURCE/'source/tools'/name,root/'source'/name)
shutil.copyfile(SOURCE/'tests/probe.py',root/'probe.py')
shutil.copyfile(SOURCE/'tests/finite_probe.py',root/'finite_probe.py')
protected=['/Users/tf00185088/Desktop/tim-project/ai-drawing','/Volumes/AI-Drawing-16T','/Users/tf00185088/Desktop/tim-project/.ai-drawing-prepared-environments','/Users/tf00185088/Desktop/tim-project/.ai-drawing-maintenance-backups']
def policy(restricted=False):
 base='(version 1)\n(allow default)\n(deny network*)\n(deny file-write*)\n'
 if restricted:base+='(allow file-write* (literal '+json.dumps(str(root/'run/state.sqlite'))+'))\n'
 else:base+='(allow file-write* (subpath '+json.dumps(str(root/'run'))+'))\n'
 # Reading only the fixed available system components is not a claim about full host reads.
 base+='(deny file-read* '+ ' '.join('(subpath '+json.dumps(p)+')' for p in protected+[str(root/'excluded')])+')\n'
 base+='(deny file-link)\n'
 return base
(root/'profile.sb').write_text(policy(case=='sqlite-no-journal'));(root/'seed.sb').write_text(policy())
env={'PATH':'/usr/bin:/bin','LC_ALL':'C','TZ':'UTC','TMPDIR':str(root/'temp')}
def limits():
 resource.setrlimit(resource.RLIMIT_CORE,(0,0));resource.setrlimit(resource.RLIMIT_FSIZE,(4096,4096) if case=='fsize' else (2097152,2097152));resource.setrlimit(resource.RLIMIT_NOFILE,(128,128))
def invoke(phase,profile,fd=None):
 cmd=['/usr/bin/sandbox-exec','-f',str(profile),'/usr/bin/python3','-I','-S','-B',str(root/('finite_probe.py' if phase=='finite' else 'probe.py')),str(root),phase]+([] if fd is None else [str(fd)])
 start=time.monotonic_ns()
 with (root/(phase+'.stdout')).open('xb') as out,(root/(phase+'.stderr')).open('xb') as err:
  p=subprocess.run(cmd,cwd=root,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err,close_fds=True,pass_fds=(() if fd is None else (fd,)),preexec_fn=limits,timeout=20)
 rec={'argv':cmd,'cwd':str(root),'submitted_env':env,'preexec_limits':{'CORE':0,'FSIZE':4096 if case=='fsize' else 2097152,'NOFILE':128},'returncode':p.returncode,'elapsed_ns':time.monotonic_ns()-start,'logs':{}}
 for suffix in ('stdout','stderr'):
  b=(root/(phase+'.'+suffix)).read_bytes();rec['logs'][suffix]={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()};print(phase,suffix,b.decode(errors='replace'))
 (root/(phase+'.command.json')).write_text(json.dumps(rec,indent=2));return p.returncode
if case.startswith('sqlite'):assert invoke('seed',root/'seed.sb')==0
fd=os.open(root/'outside/canary',os.O_WRONLY|os.O_APPEND) if case=='fd' else None
try:rc=invoke(case,root/'profile.sb',fd)
finally:
 if fd is not None:os.close(fd)
print('inner_returncode',rc)
sys.exit(rc)
