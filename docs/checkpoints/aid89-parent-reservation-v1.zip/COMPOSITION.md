# aid89-parent-reservation-v1

Bounded cooperative source composition, not an adopted product/runtime profile.
The retained `profile/*` files are immutable AID-87 comparison evidence; their
original unavailable-operation conclusions remain. This document describes the
new source delta. Existing M1/M3 READMEs retain their historical accepted scope.

## API and invariant

`OperationBinding(operation_id, epoch, source_id)` is frozen. IDs/epoch are
1..96 ASCII identifier characters; source_id is the exact child SHA256. Supply
`Window(parent, name, complete_slots, binding=binding, lifetimes=all_lifetimes)`.
Each unique destination has its own kind, complete byte ceiling and lifetime
label before root creation. Lifetime labels name retention obligations; they
are not OS deletion/physical allocation limits. Unknown commit refuses before
root creation. The immutable plan/lifetimes and a SHA256 of sorted bounded
`[path,kind,amount,lifetime]` JSON records (each followed by LF) bind the whole
parent plan, including unused noncapture obligations. The complete logical cap
remains 128849018880. Structural directories have zero logical payload and no
claimed finite physical allocation proof.

`view = parent.reserve_child(binding)` leases exactly controls/stdout, stderr,
error (256) and receipt (32768), from the parent's existing unused file slots.
Earlier noncapture slots may already be fully charged. The method creates no
new root, descriptor, cap or counter. The lease is nontransferable and issued
once; overlap/used/missing/mismatched binding/active or stopped parent refuses.
There is no release, refund, clone or reset operation. The parent cannot borrow
leased slots. The view's charge-once writes enter the SAME parent mutation and
charge dictionaries. Its snapshot is a projection: never add its totals to the
parent totals. Caller-owned Window anchors remain borrowed to the child.

`Controller(view).run(child_spec, cancel)` consumes one entered attempt. Exact
parent object/binding/root IDs/plan digest, child source, operation ID, original
source/cwd pins and shared serial lock are checked. Reentry from a parent
mutation is busy. The full existing receipt encoder uses the four-slot view
plus exact bounded parent identity, BEFORE output/pipe/spawn. It does not encode
the potentially large parent snapshot. Direct/native/other slots remain in the
parent and are never H or implicit spare capture capacity.

On pre-effect refusal after entering the lease, child/output/capture/receipt/
finalizer/cancellation uncertainty, the bound parent stays stopped. Child
acquisition checkpoints also check parent stop before new handles and launch.
Returned accounting is sampled AFTER the lease latches final stop. Commit
terminal states and bound stop cannot be relabeled/reset. An already-issued
lease can never be reused after terminal success or failure. Cancellation
readiness/EOF is observed without reading a byte or changing caller flags.
Owned-vs-borrowed cancellation closure and original one-normal-stop rules remain.

Persisted receipt precedes its own close and admission-parent-pin closes; final
returned component status includes these later outcomes. It still does not
certify borrowed outer Window closure. Caller must close that parent separately
and inspect its result: bound parent snapshot `closure_state` is open/closed/
unknown. An uncertain close remains unknown across repeated close calls, with
no retry of the uncertain FD and no new effects or reclaimed charges.

`post-start-state/...` is a distinct, explicit namespace. It is created only
when that namespace is in the plan, so an original exact-four standalone Window
retains its existing stage-directory set. Post-B slots are not overwritten or
reused as post-start copies. Duplicate file destinations remain exclusive,
no-follow, inode-checked, non-hardlinked regular-file writes.

## Reproduce

From an extracted package (Darwin system Python3.9.6 and sandbox-exec as tested):

```text
/usr/bin/python3 source/tests/compose_launch.py source NEW_ABSOLUTE_ROOT
/usr/bin/python3 source/tests/compose_launch.py source ANOTHER_NEW_ABSOLUTE_ROOT standalone_selection.py
```

Administrative launcher refuses existing roots, copies only this frozen source,
and installs pathname isolation BEFORE candidate imports. It denies network,
product R/V/prepared/backup reads, and writes outside the fresh fixture run
subtree. CORE0, NOFILE128, FSIZE2097152 are component settings, not complete native
confinement claims. No product app/root conftest/Settings is imported. Submitted
env is PATH=/usr/bin:/bin, LC_ALL=C, TZ=UTC, TMPDIR=new run; host-added variables
are not asserted absent before interpreter initialization. No listener is made.

The 29 composition controls and 10 selected unchanged standalone controls are
separate scopes. Earlier RED/intermediate GREEN scopes overlap and are not
added as independent totals. Their exact source copies, raw stderr/stdout,
commands, final fixture files, snapshots and close observations are retained.
The source-only package does not run SQLite, original prepared argv, a real B,
copy/restore/start a product, or establish Windows/GPU/QA acceptance.

The positive fixture uses a 10-byte ordinary cold seed, two independent 10-byte
cold copies, four precharged capture files, then an 8-byte ordinary fake-B
original and full copy, and a separate 8-byte fake-start original and full copy.
No fixture is labeled a database commit, actual isolated restore or startup.
Remaining native-B64 is declaration-only and unused; it proves no native bound.
Before every control file creation its full parent slot is charged. All four
capture slots are charged before every pipe and child spawn. Parent and view
snapshots and raw close errno evidence are reconciled in `evidence/validation`.

## Unchanged operation boundaries

No arbitrary native writer is confined by this cooperative interface. Original
prepared Python/Uvicorn argv still refuses before source open/output/pipe/child.
Native bytes/FDs/metadata/cardinality/TEMP/cache and complete M1/M2/M3/A1/I1 remain
unresolved; the original operation remains VERIFIED UNAVAILABLE. No launch
architecture, production reader/executor, fixed110, exact408/five-field intent,
product source, settings, grant or policy is expanded.

`2P+D_B+D_S+M <= 128849018880`, direct-original and each independent full-copy
obligations, per-shared-pool `F >= (6*A_remaining+4)//5`, F once and V credit0
remain. Qualified indirect H only remains unknown/excluded_by_policy after every
predicate, never0; native/task-owned/copy/output/metadata writes are direct.
Actual production numerical inputs remain unknown. No free-space or product
state was queried, no physical reserve/operation completion is promised, and no
privacy/data/caller/manual/compute/cold-copy/restore/legacy no-resend/forward-
recovery condition is relaxed. Original partials and no-third-attempt survive.
