# Independent offline method QA — aid56-offline-method-v1

**Review complete / CONDITIONAL.** The method is useful as a manually reviewed offline input/proof contract. The documented partial-overflow classification fails two independent controls (one low-severity finding, QA57-01). The actual full capacity and legacy runtime/client binding proofs remain **UNAVAILABLE**, exactly as the engineering handoff states. No runtime acceptance, production deployment or aesthetic verdict follows. This review issue can close done with the finding outstanding; Producer owns any successor work.

## Frozen candidate and authority

- Own review [AID-57](/AID/issues/AID-57), reviewing [AID-56 source-method-handoff](/AID/issues/AID-56#document-source-method-handoff), revision `f81ce581-7498-4e01-83fa-4ef4acc100d5`. Engineering issue was actually done and the native blocker resolved before review.
- Candidate `aid56-offline-method-v1`, Git `200345773e20e60cd0fc455bb09f0f4a45708b32`, tree `19a4f967323e2e2c319b27692abe6f076d1f1d1f`. Parent `9b96655ea4994932854ea6028f25a58fe4a6302e`, tree `c85ed83a1ca941b964f3ecc04a81de41f8ff4cbc`. `method.py` SHA256 `db58e415f2b367ea75dbfb09273464a63ef162eff6c3b63c183e683cd6d6228c`.
- Actual downloaded [engineering bundle](/api/attachments/390e453d-308f-447c-85e9-7872cb45c450/content?download=1): 480239 bytes, SHA256 `4b6490ce395b1e468afa0f34940f7346a3b7c65e2b05883d7ad9a95895764c3b`. CRC, 45 unique safe regular members, all 44 payload byte counts/SHA256/numeric archive modes verified. Manifest SHA256 `2a847519b441e7f625f569042310c904ba1c5806143d658915dc555c5438f018`.
- 41 committed files (including manifest) match Git objects exactly. Four development logs are archive-only, all manifest-bound. All Git changes are additions under `engineering/aid56-method/`; no product changes. The 15 accepted-source copies match the approved parent Git objects. Twelve authority copies match their recorded input fingerprints; these are historical read-only overlays, not current runtime inputs or a restoration kit. Original numeric authority modes are separately recorded in the input manifest; copied reference files use archive modes.
- Retained second evidence remains 368512 bytes / SHA256 `3a04b1a0f9e97b2cd813af47732cafa27a18fbc4940b336bb72f010b5601bf4b`; CRC, 15 safe members and all 14 manifested payloads reverified. Retained live-observation scripts were read as source only. Final second report revision `cd98be7e-78fe-4d5d-a1e7-d6baa769b022` / SHA256 `32a4d28a19b0cbee6ed17a2498db506e14ad545e2b81e60bded2ed2d9c9b1cb8` is assignment data; ZIP report is earlier `e0edde37` snapshot, not that final revision.
- Physically read canonical AGENTS, Goal, Progress, INDEX, own role, shared boundaries, channel and MEMORY plus all four Producer-mandated refs. No missing ref identified; shared memory was not edited. Current native task scope overrides historical operational instructions in retained files. The fixed kit `aid52-source-kit-v1` / controls `143e04fcd1c53a28ed9807cd1c512dd00f59a36634c96e3713a8750fdd1ba049` and earlier source/kit QA are reused by identity, not rerun.

## Finding QA57-01 — low — partial known overflow becomes unknown

Location: candidate `engineering/aid56-method/method.py:125`, `:136`, `:151–152`; frozen `REPORT.md:25` promises an already-proved overflow can still return `exceeds` when a term is missing.

1. Logical case: certified synthetic P=100, D_B=null, D_S=7, M=5, cap=199; physical rows all zero with F=0. Even `2P=200` alone exceeds 199 (known full lower subtotal=212). Actual result: `state=unknown`, `logical_bytes=null`, `missing=[D_B]`.
2. Physical case: certified synthetic B=100, H=null, U=0, F=119; logical total=69 and cap=69. The known physical minimum already needs `ceil(6*100/5)=120`. Actual result: `state=unknown`, allocation/threshold/fit=null, `missing=[one:H]`.

Root cause: the implementation discards the entire sum when any term is unknown and checks overflow only on complete totals. A working complete-total comparison and an overflow in a separate fully known pool still return `exceeds`; the loss is within the incomplete sum. Both counterexamples reproduced unchanged in the final isolated run. This is a diagnostic/document-contract defect, **not false permission or a false fit**: runtime_acceptance remains false. Producer should route it to Platform Engineer to retain a justified nonnegative lower bound for classification, or explicitly narrow the advertised behavior. Any changed candidate requires independent retest. QA did not change the candidate or acceptance criteria.

## Actual checks and results

Environment: existing macOS Python **3.9.6**, `python3 -I -S`, stdlib only. All fixtures are synthetic values/strings; no Settings/app/DB imports or product conftest. Run-owned Paperclip scratch held the extraction and reports.

| Check | Actual result | Meaning / limit |
|---|---|---|
| Candidate/parent/manifest/source identity | PASS, verifier exit0 | Counts and hashes above; no installed adoption inferred |
| Engineer `run_controls.py` replay | PASS, exit0: 24 tests, 3 mutations killed, 4 guard denials, 14 retained payloads | Reproduction of engineer controls, not independent new tests |
| Independent `independent_checks.py` | exit1: **28 tests, 26 PASS / 2 FAIL / 0 errors** | Two failed controls are the single QA57-01 finding |
| Rational arithmetic oracle | PASS inside one test: 403 allocation values / 805 boundary outcomes | Exact Fraction-based ceil at threshold and one byte below, including integers above 2^53 and 2^64 |
| Pre-import safety probes | PASS: 7 synthetic audit denials before candidate load | Excluded read/write, app/sqlite3 imports, socket, subprocess and mutation events rejected; no actual product access attempted |
| Named payload arithmetic | PASS: regular37500797650 + link literals1100 =37500798750; twice=75001597500 | Named-only, not effective P; no fresh metadata scan |
| Discovery 0/1/2/3/signal/timeout, malformed/duplicate/non-ASCII PID output | PASS | Empty exit2 is error with cause unknown; no-match is one query, never global absence/disconnection |
| Shared pool and symlink coverage | PASS | F counted once per supplied pool; distinct pools cannot borrow; overlap dedup, distinct regular names full-cost, missing/cyclic links unavailable |
| Error privacy / binding negatives | PASS | Only safe error-presence metadata retained; default/current-file/cwd/argv/FD facts, changed host/start/epoch, conflicts and missing companions cannot satisfy loaded contract |
| Complete synthetic loaded contract | CONDITIONAL_COMPLETE, runtime_acceptance=false | Equality/coverage only; producer authentication, supported collection, truth, host/PID/start identity and custody are explicit external review obligations |
| SQLite full post-copy formula | PASS conditionally | Independent8192×12+900=99204; current size, guessed cap or missing companions cannot certify D_B. This verifies arithmetic under the stated effective-cap premise, not SQLite build behavior or a deployed cap |
| Serialized control cap | PASS per payload; aggregate unavailable | Exact cap accepts, cap+1 rejects; two calls do not share a ledger, as documented |
| Leading-dot companion naming | PASS source/string counterexample | Accepted `_atomic` name `.ledger.json.<uuid>.tmp` fails retained `startswith(base.name)` predicate; not proof any live temp exists or old Bot loaded this source |

Actual commands are retained verbatim with cwd, exit code and full logs in `evidence/commands.json`. Portable equivalents after extracting the evidence package and its included candidate ZIP:

```sh
python3 -I -S verify_candidate.py candidate/aid56-offline-method-v1 /Users/tf00185088/Desktop/tim-project/ai-drawing evidence/identity.json
python3 -I -S candidate/aid56-offline-method-v1/run_controls.py
python3 -I -S independent_checks.py candidate/aid56-offline-method-v1
```

The verifier's first run failed because QA initially assumed every archive payload was committed. Read-only Git comparison established four archive-only log files, so QA corrected its own assertion to the exact 41-file Git/45-file archive relation and reran successfully. Initial log is preserved; this is not a candidate repair or defect. The independent harness was also adjusted to permit reading its own source for traceback formatting; product exclusions were retained and seven denial probes repeated. Candidate bytes remained unchanged.

Historical RED evidence was read, not executed: first stub run=4 assertion failures/16 unimplemented-shape errors, later bound run=4 assertion failures. They are not 20 meaningful regression failures. Current replay independently killed the three interpretation mutations. The retained `_bootlocale` guard failure is a development diagnostic, not a product/runtime failure.

## Method usefulness and exact unavailable inputs

- **P**: named regular/link accounting is reproducible. Complete effective roots, real target-tree coverage and loaded companions are missing. Backend defaults/FDs and a Bot lacking a ledger FD cannot supply them. The prototype's link-to-regular abstraction does not certify symlinked directories; an authorized complete target-tree manifest is needed.
- **D_B**: the page-cap expression can bound a full later DB only when the actual build/connection/file-length/page inputs, enforced cap on all writers, no escaping page-size/VACUUM/ATTACH/extension writes, complete post companions and exact SQL/schema/index/trigger closure are independently established. Those real inputs/cap are unavailable; 35713024 current bytes is not substituted for a later full copy. Transient U remains separate.
- **D_S**: static accepted `main.py:6–8` selects closed bootstrap before product Settings/DB/writers; `maintenance.py` reads source and emits `legacy_process_certified=False`. Product-state zero is only a conditional inference for an exact future closed import/launch with old writers closed, bytecode/cache/launcher/log effects controlled and Bot not started. It cannot certify an existing process or normal startup. No source code was imported to obtain this conclusion.
- **M**: a single-payload cap primitive is useful but cannot enforce aggregate serialized controls/logs/recovery reservation. Actual64MiB remains a proposal.
- **Physical B/H/U/F**: no reliable complete physical/copy/metadata/transient bound, fresh F or authenticated shared-allocation-pool mapping is available. `st_dev` alone is not accepted as shared-pool proof. Page-rounded named files and arbitrary256MiB reservations remain estimates. The prototype trusts the supplied pool/bound evidence; it does not authenticate it or ensure payload coverage. No certificate or shortage is inferred.
- **Legacy bindings and locator**: accepted source does not provide the complete old loaded Settings/ledger/client snapshot contract. The nonsecret opaque-ID contract identifies required domains and consistent consumer/window; no collector, authenticated producer or legacy capability is installed. Existing supported launch provenance/safe projection, if present, would need narrowly authorized Environment assessment. Otherwise Producer must define a separately reviewed transition/protection approach; a new startup receipt cannot answer for an old process. MCP exit2 cause stays unknown; the other grep fixture is not its reproduction. No live locator retry or exhaustive session search is required by this review.

The remedy is therefore useful for framing exact next inputs, not sufficient to authorize another operation. Producer can decide a bounded authoring fix or an exact future authority proposal. Environment would own separately authorized runtime/schema/copy evidence; no authority is supplied here and QA does not ask the owner for a new operation prematurely.

## Containment, exclusions and disposition

Only retained public source/Git objects, frozen evidence and canonical task authorities were read. The independent guard was active before candidate evaluation, rejects product imports/network/process/mutations and permits only frozen-bundle and harness-source reads. This audit hook is a harness safety control, **not an OS sandbox for arbitrary malicious Python**; default permissions do not prove confinement. No broad workspace build/pytest, product/private config/environment, DB open, process query, product HTTP/MCP, service signal/start, backup/schema/source adoption, downloads/install/spend/remote/Windows, generation or training occurred. Paperclip control-plane GET/comment/document/upload operations are separate authorized task work.

QA wrote only run-owned scratch and its own native issue. Frozen engineering source and all prior evidence were preserved. No whole canonical-tree preservation claim is made: engineering's recorded public diff drift remains uninvestigated, and QA did not scan/reset dirty work to manufacture invariance. No independent source/kit PASS count was rebuilt.

**Final QA disposition: done / CONDITIONAL offline utility, QA57-01 open through Producer; real full capacity and legacy binding unavailable.** Producer receives this own-ticket review through the native dependency event and owns any follow-up to Platform Engineer. There is no remaining execution step on this review, no new monitor/dispatcher/task tree and no parent write requirement.

**Memory candidates:** accepted `discord-bot/bot/attempt_store.py:36` constructs leading-dot UUID temp files, which retained prefix-only sibling observation does not cover. Evidence: exact accepted-source SHA256 `c0976ede532f2ba22bb1d7dac5567fe6b5edc98d70bd70af76ce0592b3552fc5`, retained archive/script hashes and independent identity/string check. Reuse when defining complete companion naming/temporary coverage; not evidence of a live file or loaded old implementation. Producer alone decides memory curation.
