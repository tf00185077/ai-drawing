"""Validate downloaded immutable public candidate against manifests and Git objects."""
import sys,pathlib,json,hashlib,zipfile,io,stat,subprocess
bundle=pathlib.Path(sys.argv[1]).resolve(); repo=sys.argv[2];output=pathlib.Path(sys.argv[3])
def git(*args):return subprocess.check_output(['git','-C',repo,*args])
def sha(b):return hashlib.sha256(b).hexdigest()
manifest=json.loads((bundle/'artifact-manifest.json').read_bytes()); records=manifest['files']
actual={p.relative_to(bundle).as_posix() for p in bundle.rglob('*') if p.is_file()}
assert actual == set(records)|{'artifact-manifest.json'}
for name,rec in records.items():
 p=bundle/name;b=p.read_bytes();assert len(b)==rec['bytes'] and sha(b)==rec['sha256']
 assert f'{stat.S_IMODE(p.stat().st_mode):04o}'==rec['numeric_mode']
inputs=json.loads((bundle/'inputs/input-manifest.json').read_bytes()); accepted=inputs['product'];candidate='200345773e20e60cd0fc455bb09f0f4a45708b32'
assert git('rev-parse',accepted+'^{tree}').decode().strip()==inputs['product_tree']=='c85ed83a1ca941b964f3ecc04a81de41f8ff4cbc'
assert git('rev-parse',candidate+'^{tree}').decode().strip()=='19a4f967323e2e2c319b27692abe6f076d1f1d1f'
assert git('rev-parse',candidate+'^').decode().strip()==accepted
changed=git('diff-tree','--no-commit-id','--name-status','-r',candidate).decode().splitlines()
archive_only_logs={'evidence/green.log','evidence/red.log','evidence/post-bound-red.log','evidence/guard-lazy-import-red.log'}
committed={line.split('\t')[-1].removeprefix('engineering/aid56-method/') for line in changed}
assert committed == (set(records)-archive_only_logs)|{'artifact-manifest.json'}
assert all(l.startswith('A\tengineering/aid56-method/') for l in changed)
for name in committed:assert git('show',candidate+':engineering/aid56-method/'+name)==(bundle/name).read_bytes()
source_count=0;authority_count=0
for row in inputs['files']:
 accepted_source=row['domain']=='accepted_product_source';root='accepted-source' if accepted_source else 'current-authority'
 b=(bundle/'inputs'/root/row['path']).read_bytes();assert len(b)==row['bytes'] and sha(b)==row['sha256']
 if accepted_source:
  assert git('show',accepted+':'+row['path'])==b;source_count+=1
 else:authority_count+=1
with zipfile.ZipFile(io.BytesIO((bundle/'inputs/retained-second.zip').read_bytes())) as z:
 assert z.testzip() is None
 assert len(z.namelist())==15 and len(set(z.namelist()))==15
 for i in z.infolist():
  p=pathlib.PurePosixPath(i.filename);assert not p.is_absolute() and '..' not in p.parts and stat.S_ISREG(i.external_attr>>16)
 retained_manifest=json.loads(z.read('evidence-manifest.json'))
 assert len(retained_manifest)==14
 for name,rec in retained_manifest.items():
  b=z.read(name);assert len(b)==rec['bytes'] and sha(b)==rec['sha256']
 capacity=json.loads(z.read('capacity-supplement.json'));meta=json.loads(z.read('metadata-fingerprints.json'))
 regular=sum(row['logical'] for row in capacity['groups'].values());links=sum(row.get('link_literal_bytes',0) for row in meta)
 assert regular==37500797650 and links==1100
 s=z.read('supplement-capacity.py').decode();assert 'startswith(base.name)' in s
 named='ledger.json';temporary='.'+named+'.'+'a'*32+'.tmp';assert not temporary.startswith(named)
 ast_source=(bundle/'inputs/accepted-source/discord-bot/bot/attempt_store.py').read_text()
 assert "'.'+path.name+'.'+uuid.uuid4().hex+'.tmp'" in ast_source
summary=dict(artifact_manifest_payloads=len(records),candidate_git_files=len(committed),archive_only_logs=sorted(archive_only_logs),accepted_source_files=source_count,authority_snapshots=authority_count,retained_payloads=len(retained_manifest),retained_regular_bytes=regular,symlink_literal_bytes=links,named_one_payload=regular+links,named_two_payload=2*(regular+links),leading_dot_counterexample=True,git_parent=accepted,git_candidate=candidate,manifest_sha256=sha((bundle/'artifact-manifest.json').read_bytes()))
output.write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
