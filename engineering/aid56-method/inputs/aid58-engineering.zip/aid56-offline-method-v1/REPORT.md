# 離線容量與 runtime-binding 方法 — aid56-offline-method-v1

交付結論：**可重建的離線方法；實際容量／舊程序 binding 仍為 conditional / unavailable。** 本單工程交付完成後交獨立 [AID-57](/AID/issues/AID-57)；不自批技術接受。這不是第三輪 preflight，也沒有維護、部署或操作權限。Producer 在 QA 後決定下一項工程或精確的未來操作提案。

## 固定輸入與變更

- 產品 input commit `9b96655ea4994932854ea6028f25a58fe4a6302e`，tree `c85ed83a1ca941b964f3ecc04a81de41f8ff4cbc`；kit `aid52-source-kit-v1` / controls `143e04fcd1c53a28ed9807cd1c512dd00f59a36634c96e3713a8750fdd1ba049`。
- [第二輪報告](/AID/issues/AID-55#document-operation-report-2) revision `cd98be7e-78fe-4d5d-a1e7-d6baa769b022` / body SHA256 `32a4d28a19b0cbee6ed17a2498db506e14ad545e2b81e60bded2ed2d9c9b1cb8` 由 creation-time plan 提供全文。本文不假稱重新取得該 native revision。其 ZIP 內報告是較早 snapshot `e0edde37` / SHA256 `26e544e018bc56c857f36f438073f062c2ec8513e7019e772f89f14b7518b72a`，兩者不可混用。
- `inputs/retained-second.zip` 是實際 GET 取得的第二證據：368512 bytes / SHA256 `3a04b1a0f9e97b2cd813af47732cafa27a18fbc4940b336bb72f010b5601bf4b`。CRC、15 safe unique regular members、全部14 payload bytes/hashes 均驗證。舊觀測 scripts 只讀原文，未執行。
- 新 Git worktree `ai-drawing-worktrees/aid-56-offline-method` 從上述產品 commit 建立。所有新增物限 `engineering/aid56-method/`；產品程式碼零變更。canonical HEAD `da78a449d0aca575f8707f834774b9d1ec8a95f1` 與 dirty source 未搬入。Git administrative worktree/ref 登錄是隔離建置的一部分，不是 source adoption。
- `inputs/input-manifest.json` 分別列 accepted source 及12份 current authority 的 SHA/bytes/原 numeric modes。current authority 是唯讀 overlay 副本，未覆寫 frozen source。正式本單 scope 優先於舊 snapshot 的歷史指令。未編輯 shared memory。

## 一個可檢查的方法

`method.py` 沒有 imports、I/O 或 collector。它只處理由具權限的證據作者提供的資料。`basis`/`evidence` 是待 QA 驗證的 proof obligations，**字串本身不認證證據、完整性、程序身份或操作許可**。呼叫者可撒謊，純算術函式不能阻止；所以所有可算結果都只叫 `conditional_fit`，`runtime_acceptance` 永遠 false。

`Bound`：`{bytes: 非負整數或 null, basis, evidence: 非空證據 locator}`。只有 `complete_manifest`、`enforced_limit`、`derived` 可進入條件計算；`named_only`、`estimate`、`page_rounded`、缺證據與 null 保留 unknown。負數、bool、浮點／字串不是 bytes。`sqlite_post_bound` 的 `page_limit` 明確使用 `pages`，其餘使用 bytes。

1. **P** 是完整有效保護集合的一份完整副本：每個需保護的 regular destination payload、symlink literal bytes，以及 link 指向的實際需保護內容。目錄、ACL、xattr、ownership、link/directory allocation 另算 H。`protection()` 以 reviewer 已解別名的 destination ID 去除重疊 root 的重複列；相異 regular path 仍算兩份，不用 inode/hardlink/clone/compression/sparse 折扣。symlink 本身及其最終 regular target 各列一次，函式不遍歷 link；target 不在集合、未解 link chain／循環或 effective roots 不完整則 unavailable。實際符號連結至目錄時，應先由具權限作者提供該 target tree 的去重 regular payload 清單；本 prototype 的單一 link-target 介面不足以認證目錄樹，不能硬塞成檔案。
2. **D_B** 是 B 交易後另外保存的**完整 DB 及所需 companions**，不是 SQL delta。可用有限式 `D_B <= page_size * enforced_max_pages + complete_post_companion_bound`。前提是同一實際 SQLite build/connection、實際 page size、目前 page count 與可執行上限回讀；每一相關 writer 都受限，沒有 page-size/VACUUM/ATTACH/extension 外寫逃逸，companion coverage 完整。此式涵蓋任意頁增長但不保證交易會成功；太小的 cap 可能令交易失敗，不能當作成功策略。schema/index/trigger/UDF/virtual-table 與 exact408 SQL/參數仍須審核，以證明這些前提及 transient U。retained 六欄／trigger count／目前 size 不提供這些輸入。
   main-file 公式另要求已驗有效檔案的完整 logical length 等於 current_pages×page_size，沒有未解的尾端資料；此處沒有讀 DB 來建立該前提。
3. **D_S** 是 startup 後新增保存的完整可變檔案集合，逐一列出 full file bound。accepted `backend/app/main.py:6–8` 的 closed 分支先於 Settings/DB/writers；`app/maintenance.py` 只建 closed app、讀 source hash。對未來 fresh closed Backend，在確認 exact entry/import closure、無其他 writer、禁止 bytecode/cache 寫入且所有 launcher/log 輸出納入 M/U 的條件下，product-state `D_S=0` 有可審核的 source 推論。這不是對舊程序、normal startup 或 OS/libraries 所有寫入的證明。normal 分支會 init_db/create_all/ALTER 與啟動 workers，不能套零。Bot 保持不啟動時不產生 Bot startup copy；任何未來 Bot startup 要另列 owner/checkpoint/temp 等檔案。
4. **M** 是所有控制／manifest／script／log 的**總序列化上限**。`bounded_control()` 先對 bytes 檢查 cap 才交回 payload；等於 cap 接受，超出拒絕。它不寫檔、不限制 serializer 記憶體，不提供 aggregate ledger、log limiter 或 disk reservation。未來 writer 必須在每次寫之前扣同一總額、包含 errors/temporary/final copies，輸出滿額即停止且保留 recovery 空間。retained 64MiB 是尚未整合執行的提案，因此實際 M 仍 unknown，不能因本函式存在就補成已證。

邏輯式為 `L_plan = 2P + D_B + D_S + M <= 128849018880`。函式用完整整數計算，無浮點／四捨五入。missing term 不補零。已知 term 已確定超出仍可回 `exceeds`，但不等於現場容量短缺。

每個實際共享 allocation pool 分別計 `A_remaining = B + H + U`，比較 `F >= ceil(6*A_remaining/5)`。B 是尚未分配的所有完整 destination/source positive-growth payload 之**物理**上限；H 是 metadata/link/directory/保留屬性與 copy 工法 allocation；U 是同時存活的 DB journal/WAL/statement/TEMP、copy/rename temp、log 及其他 transient peak。三者排他覆蓋，不能把 temporary 同時計入 H/U，或漏掉 M 的實際物理配置。保守相加跨階段 peak 可以，但若想扣掉不能同時存活的項，須提供經驗證的 phase/lifetime 排程。

`capacity()` 按同 pool 累加所有 allocation rows，只取該 pool 一份 F。不同 pool 不互借。呼叫者須由真實 filesystem/container/quota/reservation 關係建立 pool ID；`st_dev` 不足以證明 APFS volumes 沒有共享 container free space。不得把 R/C 各取一次 F 或把 V 當容量信用。已配置且不可釋放的空間不再算 remaining；release credit 僅在確實完成且證據有效後重算，不能預支刪除／cleanup。

**H/U 現況 unavailable。** page-rounded file subtotal 不涵蓋 copy API／APFS metadata、xattrs、directories、COW/rename/journal 及同 pool 其他配置者；xattr value bytes 是內容量，不是配置上限。SQLite `journal_size_limit` 約束 commit/reset 後的殘留量，不能限制交易中 peak；`max_page_count` 只管 main DB pages，不能拿來包 WAL/TEMP。參考 [SQLite PRAGMA](https://www.sqlite.org/pragma.html#pragma_max_page_count)、[journal size](https://www.sqlite.org/pragma.html#pragma_journal_size_limit)、[temporary files](https://www.sqlite.org/tempfiles.html)。本方法不以測到的 peak、任意256MiB或 quota 代替可成功完成所需的上限證明。

## 由 retained inputs 真正導出的量

全部14 payload hash 驗證後可重算：regular named bytes `37500797650`；metadata manifest 的10個 link literal 共 `1100` bytes。因此按本方法的 payload 定義，**named-only** 一份是 `37500798750`，兩份是 `75001597500`。這個2200-byte雙份差額只是明確計入 links，並未解決 effective P。未改寫舊報告的 regular-only subtotal。

舊 `75068704164` subtotal 及 `53780314716` headroom 含未落實的 M，且不含本定義的 link literal；只能作舊假設算術。舊 `F=236750987264`、`C_cap` 與 DB size 都是 dated retained evidence，非本次 fresh observation。`run_controls.py` 對真 retained 數值回 `unknown`，logical/physical threshold 都為 null；沒有 demonstrated shortage，也沒有 full-cap PASS。

此外，accepted `discord-bot/bot/attempt_store.py:36` 的 temporary construction 是 `'.'+path.name+'.'+uuid+'.tmp'`，另有 `.owner`、`.checkpoint`。retained `supplement-capacity.py` 只接受 `startswith(base.name)` 的 siblings；因此不涵蓋此 leading-dot temporary 名稱。`evidence/companion-counterexample.json` 是純字串反例。它只證明這個 source naming pattern 與掃描規則的 coverage 差異，**不證明當時或現在有 temp、不證明舊 Bot 載入 accepted source，也不把它指定為 preflight 的根因**。未來 companion contract 必須依實際 loaded implementation 列完整命名／temporary 規則；正好沒有 FD 或 prefix match 不能取代它。

## Locator 與 loaded binding contract

`discovery()` 是 exact adapter 的結果解譯，沒有執行 pgrep：exit0 + 非空且全為獨立正整數 PIDs → matched；exit1 + empty → 本次查詢 no_match；exit2/3/其他或 signal → error；timeout → timeout；exit0 empty／非數字／重複 PID 或 exit1 搭配輸出 → invalid_output。保留 code、timeout、safe stderr-present 三態；不外送 stderr 原文／argv secrets。沒有經 allowlist 的安全 diagnostic code 時 `cause=unknown`。

本機安裝的 `/usr/share/man/man1/pgrep.1` 已作靜態輸入保存，列0匹配、1無匹配、2命令列選項錯誤、3內部錯誤。這支援 error/absence 分流；不證明當時 binary/version 的精確錯誤路徑。retained exit2 仍為 error，舊 stdout parse count0 作 absence 的推論無效。不同 grep fixture 不是 pgrep reproduction；本次也沒有 tool-equivalent hermetic process-table executor，**原失敗原因仍未重現／不明**。未來只有在新精確權限下才可對同工具／等價隔離 inputs 查證，不得 live retry 來替這份離線交付補 PASS。no_match 從不代表 caller/transport 已不存在或 disconnected。

`binding(required, facts, process, epoch)` 只檢查提議的受支援 in-process snapshot contract 是否填滿：每個 required field 都須具相同 host+PID+start identity、epoch、complete coverage、單一一致值與證據 locator。PID 本身可能重用。source defaults、current file、cwd、argv 或單一 FD 一律不是完整 loaded Settings；不同 epoch／矛盾值／missing companions 保留 unknown。opaque path/endpoint IDs 可在私有側對映；不輸出 token、query credentials、設定／env dumps。此介面不提供 signature/身份驗證；稱 `loaded_snapshot` 並不建立可信 producer，QA 必須另驗支援性與 custody。

最小 required domains：Backend 的 loaded source/dependency identity、effective DB及實際 companions、output/gallery/prompt/cache/training/model/link roots與閉檔 writer coverage；Bot 的 effective config load-chain provenance、ledger root/file/owner/checkpoint/temp 與 writer identity；具名 MCP client 的 owner/session/start、Backend/ComfyUI/Bot operator endpoints 與 caller holds。各值要來自真正消費者，同一窗口；不是預設值或新啟動程序對舊程序的代答。

accepted Backend closed status 明載 `legacy_process_certified=False`，不輸出上述舊 Settings。Bot `ledger_binding()` 的 `source_version()` 是對目前磁碟 source 的 hash，不能回推所有已載入 bytecode；其 config hash 也只涵蓋選定 public fields。MCP `get_mcp_settings()` cache 與三條不同 client routes 亦沒有本單可用的 full loaded export。這不證明所有 OS 方法都不可能；只表示現有 retained/public supported contract 沒有這些值。

## 精確 unavailable-input / actor / future control

| 缺項 | 必要輸入與可驗條件 | 下一個 owner／最小未來途徑 |
|---|---|---|
| effective P、舊 loaded roots/callers | 同 consumer/epoch 的完整 loaded 值、companions 及 caller 控制，或已有可信且足以排除後續變更的 launch provenance | Producer 請 Environment 評估是否**已有** supported launch record／安全投影可供精確授權讀取；不存在時保持 unavailable。不得要求掃盡所有未知 sessions、讀 env/private files 或注入 process memory。新 startup receipt 只能服務未來程序。 |
| D_B | actual build/page size/pages、回讀且所有 writer 落實的 page cap、完整 post companions、exact SQL/schema/index/trigger/extension closure | Producer 選擇是否提出一次受限的私有 consistent snapshot/schema-input 工作及 isolated replay，或受控 cap 的工程提案；需另授權，snapshot/replay本身不是 peak 上限。若 cap 未部署就不可拿 synthetic cap 代答。 |
| D_S | exact closed entry/import/write-set、launcher/cache/log 控制、舊 writer closure；Bot仍不啟動 | Environment 在另授權採用時證明這些 preconditions；本次只有 source inference，不能啟動服務來驗。 |
| H/U與fresh F | exact filesystem/copy API 的可靠 physical-allocation/metadata/temp 上限；所有 writer/companion/phase coverage、shared-pool mapping與其他配置者控制 | Environment 提出平台支援的計量／reservation/preservation contract供 QA驗證。若平台沒有足以支持的上限，Producer 將**此一不可滿足的證明條件與替代風險控制**交 Hermes作精確決策；不能自行把 gate降成256MiB或改host/volume。 |
| M | 有上限的實際序列化輸出、aggregate ledger及bounded logs、失敗／recovery預留 | Platform 可在後續精確 assignment 整合既有工具；本單只交單payload cap primitive，不宣稱已約束現場 writer。 |
| locator error cause | 同工具身分／等價隔離輸入、安全錯誤分類 | 保留 unknown；Producer若需要再界定最小新觀測授權，而非第三次 preflight。 |

若沒有舊 binding record 或 supported export，不能靠部署新 receipt 解開既有保護前置條件。Producer 需提出另行審查的 transition/protection 方案及明示剩餘風險，才能改變該前提。本單沒有建立任何這類權限，也沒有預先發送操作問卷／approval。

## 實際 checks、可重建與限制

在抽出的 method 目錄執行：`python3 -I -S run_controls.py`（已驗 Python 3.9.6；不依賴產品 venv）。完整24個 method controls PASS，三個危險 mutation 均被 assertion 抓到：exit2誤當absence、共享free雙倍信用、defaults誤當loaded。4個 guard denial controls證明本 runner 在 import method 前拒絕 excluded read/write／app／sqlite3；14個 retained payload再驗。沒有 product Settings、DB或app import，也沒有 normal product startup。此 audit guard 是這個 harness 的檢查邊界，不是任意惡意 Python 的 OS sandbox。

`evidence/red.log` 記錄最早20-test stub run：4 assertion failures、16 unimplemented-shape errors，不能說20個都為有意義 regression RED。`controls/red_method.py.txt` 與 `red_checks.py.txt` 保留該輸入。`post-bound-red.log` 有後續4個純 assertion RED；`green.log` 為最終完整24-test run及mutation結果。另保留 runner 的 lazy `_bootlocale` import 被嚴格 guard 拒絕的失敗診斷；改用已讀 bytes 的明確UTF-8解碼解決，未擴大讀取權限。這些是本 prototype 的開發證據，不把 stub/mutation failures冒稱 live defect reproduction。

完整 source subset、authority/input manifests、retained ZIP、報告、controls及原始logs全部隨可下載 frozen artifact交付。QA可在 extracted目錄獨立跑同一命令並自行加反例。重建需要已安裝 Python3.9+；無需下載、安裝、DB或網路。本單不跑 repository-wide pytest/build，因產品 source未改且其 conftest/import/runtime範圍不在授權內；不以重新跑舊status/source controls增加PASS數。artifact hash與Git commit/tree由 native freeze receipt提供，避免自雜湊循環。

實際本單產品操作／private config／live process／DB opens／service signal/start／generation/training／model downloads／source adoption均0。Paperclip task evidence GET/PUT、artifact upload和本單Git隔離交付另計，不是產品HTTP許可。未刪除／覆寫既有 candidates、models、datasets、outputs或dirty work。

保全檢查限制：canonical HEAD、porcelain status及12份authority bytes與開始時一致；但整體 tracked public diff digest 在本次檢查有變，原因未查證。未執行 canonical source writes，也沒有 reset／清理／回填來消除差異；因此不宣稱整個dirty checkout byte-for-byte未變。兩個digest與檢查scope保存在 `evidence/canonical-preservation.json`。固定accepted source inputs已逐檔對Git object驗證，不受這項canonical差異影響。

下一步：獨立 QA 在其自己單 [AID-57](/AID/issues/AID-57) 對固定 candidate 回 usable / conditional / unavailable 及技術 verdict 並done；Producer從 [AID-4](/AID/issues/AID-4) 綜合判斷。Deployment仍由Environment另授權執行，本單沒有部署／rollback操作；移除此未採用方法也不會回復任何產品資料。

**Memory candidates:** accepted `attempt_store.py:36` 使用leading-dot UUID temporary，既有prefix-only sibling觀測不涵蓋；`evidence/companion-counterexample.json`與exact source/retained script hashes可證。未來重新制定companion coverage時可重用；不代表live檔存在或舊Bot載入此source。其餘容量／error／binding區分已在既有memory，本單不另寫shared memory。
