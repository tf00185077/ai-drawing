# Finite supplement — second operation report

**Disposition: done / exact partial before signal.** The one authorized supplement completed useful capacity accounting and corrected the training-status observation. Full loaded runtime/client binding and reliable full post-state/physical bounds remain unproved. No real window was opened and no service/data/source stage was crossed. The first report and its artifact remain unchanged. There is no third attempt or replenished read allowance under this grant.

## Admission, versions and current authority

Own issue [AID-55](/AID/issues/AID-55); Environment run `31d1c5cc-0033-41ee-8216-f5e640d6aca8`. Harness checkout was GET-read bound to this run; no duplicate checkout. Evidence epoch: `407a9c72-75a2-40f4-8904-f3f53b94e0d2/31d1c5cc-0033-41ee-8216-f5e640d6aca8/supplement-20261029T044130Z`. This labels observations, not an opened maintenance window.

The [exact supplement](/AID/issues/AID-4#document-new110-preflight-supplement-request) was read in full: revision `6b14fff2-ac8f-4aaf-a570-fc49a4b69b85`, SHA256 `5f057c1905024070c6da756db5847dbd2c39fc495a91bfe81c380ec94fbe439c`. Native confirmation `bbb14995-6994-49e4-9c9d-ae47242e045a` was independently read from the parent interaction list, accepted at `2026-10-29T04:31:08.479Z`, exact document/revision target, actual resolver `local-board`, substantive author Hermes under CTY human/Board delegation. The [authenticated resume comment](/AID/issues/AID-55#comment-69978ba4-49f6-4603-8d44-03e05d83ce23) was fetched directly; author Producer agent `26a4b374-3863-4acc-a573-59800c29e4d3`, source run `11c1cbc1-c7bb-46e5-9d9c-c99cc2a89432`.

Original v2 confirmation `ddbb19a7-31dd-4a72-adb4-8eb342754287`, request revision `9f097a5f-e798-40fa-9ce1-3b90d567a57d` / SHA256 `166aeadaed0716963d615f150d4be02c2198de0e87ab41528d39a1f3a8a3ce14`, and creation-time plan revision `8ad11b7c-c397-42c2-ab7c-1de5d0ba807d` remain the original stage authority. Fixed product `9b96655ea4994932854ea6028f25a58fe4a6302e`, kit `aid52-source-kit-v1`, controls `143e04fcd1c53a28ed9807cd1c512dd00f59a36634c96e3713a8750fdd1ba049`, exact408 set SHA256 `2a87d402ef171ba200b68b6db79c4656cfefb12449141742b891e7a429bec9a4`, and all original exclusions are carried forward; no source QA or B/read/operation intent was reapproved or rerun.

Canonical AGENTS, MEMORY index, Goal/Progress/INDEX, role/shared boundaries/channel and all six originally mandated refs were physically reread. Current [patrol retirement](/AID/issues/AID-4#document-handoff-patrol-retirement), revision `7c0189dc-7804-42d1-ad8a-8747925fd1bf`, SHA256 `40f00feb545fe555280b95d39c6cc8a06c35aa369377c6f57fc6239972285b94`, was read in full. Its withdrawal of watchdog/monitor/timer/poller authority supersedes frozen historical clauses. No missing memory ref was observed; no shared memory was edited.

## Preservation of the first result

[First operation report](/AID/issues/AID-55#document-operation-report) remains revision `d1916700-8410-4566-8031-c2371988396c`, body SHA256 `cb17ccf5caeb38379b5a12dc91918dd08fec3053612085b08093a79a414732fb`. [First evidence ZIP](/api/attachments/a2e2a07b-cb33-403f-9498-211bc70ccd2e/content?download=1) was retrieved and verified at48138 bytes / SHA256 `9d690ee89812cf0d19a0c9847897558c7dd47541e909e5caade57f464d59761a`; CRC passed. Its selected retained receipts were reused. This second report does not relabel its omitted training status as idle. Its408 queued/queued guard result,68 preimages/42 absences and source QA remain dated evidence, not freshly repeated DB/source acceptance in this run.

## Actual allowance ledger and stage counters

| Supplement allowance | Used | Result |
|---|---:|---|
| One named-root metadata pass,100000 entries/35sec |1|6007 entries,0.234sec, no traversal errors; no symlink following.|
| One named Backend/Bot/MCP projection batch |1|Backend/Bot projections returned; MCP locator failed with exit2; binding unknown. No retry.|
| One correction8001 training-status GET |1|HTTP200,66 bytes; correctly typed idle/null/0.|
| Conditional four-route real-window safety batch |0|Prerequisite full feasibility/bindings/actual window controls not met.|
| Conditional selected consistent408 DB guard read |0|Same condition not met; no DB open/read in this supplement.|
| Normal Bot/Backend signal |0 each|No closure attempted or claimed.|
| Checkpoint / isolated restore / B UPDATE / B COMMIT |0 each|C remains absent; no private copy or transaction.|
| Source apply / numeric writes / Backend launch / Bot launch |0 each|Unused original stages remain unexecuted.|

One correction read is the only product HTTP call in this supplement. No other live GET, reconcile/job-status route, product MCP tool, Bot operator call, resource operation or retry was made. No process environment/private configuration dump, process-memory inspection, normal Settings/app import or new observation tooling was installed. Scratch scripts orchestrated existing local tools only. No monitor, liaison, child readiness tree or recurring work was created.

## Capacity accounting performed

A single bounded metadata pass covered only the original named state roots, recognized companion names, the fixed extra Lightx2v target,68 source preimages and exact existing Git HEAD/index/refs/packed-refs protection. It used lstat/scandir without following symlinks, then `/bin/ls -ldAe@` in fixed128-entry batches on the same manifest, including root directories. Asset/private filenames and metadata values were not exported. No new root/volume was selected and no content was copied.

| Included group | Regular files | Logical bytes for one full copy | Sum of per-file ceil(size/4096)*4096 |
|---|---:|---:|---:|
| Named state/config-size/extra target |5743|37499509248|37511925760|
|68 source preimages |68|1123054|1265664|
|Exact existing Git protection |27|165348|274432|
|Total named set |5838|**37500797650**|**37513465856**|

The actual named DB/ledger sibling-name projection found no recognized or unrecognized prefix companions at that observation; it does not certify an undiscovered effective ledger path. Ten symlink entries were preserved as links and not followed; the extra fixed target was counted once and nine already-covered target copies were not added. Fresh target equivalence was not independently certified by the aggregate supplement receipt; original mapping evidence remains dated. No copy may proceed on that basis.

Native metadata including the root directories observed601 xattr entries /6718 value bytes, largest72 bytes, and0 ACL entries in those listings. This corrects the first pass's incomplete directory-root coverage. It remains measurement, not demonstrated copy/restore preservation or an APFS allocation upper-bound certificate.

For the **complete enumerated named set**, `2P_named=75001595300` logical bytes. P for the **complete effective live protection set** remains conditional on unresolved runtime bindings; an unobserved effective root/companion cannot be silently omitted. C (`.../.ai-drawing-maintenance-backups/aid4-new110-v1-8eaf5820`) remains absent.

A finite proposed control envelope was made explicit: `M=67108864` (64MiB). The capacity receipt allocates finite manifest/control/script/log caps; before any actual C write those limits must be enforced against the actual serialized content. The named-copy-plus-M subtotal is `75068704164`; logical headroom for the remaining D_B/D_S under `C_cap=128849018880` is `53780314716` bytes. This is accounting, not a full-cap PASS.

The same-device R/C calculation uses only one free-space balance: device16777232, fresh block4096, `F=236750987264` at `2026-10-29T04:41:30Z`. Per-file rounded copies plus M and proposed `H=268435456`, `U=268435456` total `75630911488` bytes; its20% threshold would be `90757093786`. **H and U are candidate envelopes, not reliable certified upper bounds**, so comparison of this subtotal with F is not the required full physical PASS. V stays a source, never an alternate capacity credit.

Precise remaining capacity gaps:

- Current DB full-file size is35713024; that is a complete current copy size, **not D_B**. A bound for the full post-transaction DB and actual companions must account for the actual schema/index/page growth and journal behaviour under the exact408 five-field transaction. The retained hash/trigger-count/six-column read does not provide all those numeric inputs; this run did not expand the conditional DB allowance to obtain them before real window controls.
- **D_S is unresolved**, including which full files can change and need an additional post-start copy. Fixed closed source is designed to avoid Settings/DB/workers, but old-process loaded writers and effective companions are not certified. No current-size substitution, fractional SQL delta or zero default is used.
- H needs defensible full metadata/link/directory/copy-temp allocation and preservation coverage; U needs a reliable full DB journal/WAL, source temporary/positive-growth and bounded closed-control/log allocation bound. Proposed256MiB envelopes are explicitly not proof and cannot authorize a write.

Consequently the complete `L_plan=2P+D_B+D_S+M` and `F_f>=ceil(1.20*A_remaining)` gates remain **unknown**. There is no demonstrated capacity shortage. No assets were deleted, no clone/hardlink/compression/sparse credit was used and no alternative volume/spend was proposed. These are the exact uncompleted capacity derivations, rather than an all-ready claim.

## Corrected training observation

Before the GET, AST/source inspection confirmed `TrainStatusResponse.status: str`, `current_job: TrainJobInfo | None`, `queue: list[TrainJobInfo]`, and the handler's `status=st["status"]`. The trainer source names idle/running/queued. The standalone projection accepted one positive fixture and rejected four malformed/missing/wrong-type fixtures. It imported no product modules. Schema/API hashes and verification time are in `observer-schema-receipt.json`.

The single correction GET used directIPv4 `127.0.0.1:8001/api/lora-train/status`,4-second timeout,2MiB cap, no proxy/redirect/fallback/retry. At `2026-10-29T04:42:32.947344Z`: HTTP200 /66 bytes, **status=idle, current_job_present=false, queue_count=0**. Raw body/last_result/job payloads were discarded. This corrects only the previously missing observer evidence; it does not prove complete compute safety, durable guards, caller holds or cold closure.

## Runtime projection, actual failure and stop

Existing `tmux -L ai-drawing list-panes`, selected `ps`, owned `lsof` and bounded `pgrep` were used once for the named services/client. Backend PID38433 and Bot PID1882 remained uid501, original local start/cwd/pane bindings. Backend had R/auto_draw.db open and an FD under the named V/training/lora root; Bot had no open named ledger at that instant. Direct-child counts were0. This does not show every worker/thread inactive or enumerate closed-file paths.

The old Backend/Bot do not expose all effective loaded root/config/ledger/companion values through the selected argv/cwd/open-FD projection. No socket result, default path, current file content or absent ledger FD was promoted to loaded-settings proof. No private-file/env search or process-memory introspection was attempted to fill the gap.

The exact MCP entry argv locator returned **pgrep exit2**. The script parsed zero PIDs from its empty output and initially labelled it not-found; **that derived interpretation is invalid and superseded by runtime-assessment.json**. Actual MCP process/caller ownership and endpoint overrides remain **unknown**, not absent/disconnected. Stderr was discarded, so the precise failure cause was not retained. A pure non-live `grep -E` fixture accepted the same locator text, which did not reproduce the pgrep failure. The earlier commentary attribution to regex syntax was too strong; only the failed locator result is established. No live locator retry, wider process/session scan or access workaround was performed.

The binding step therefore did not pass. Remaining real gaps are loaded Backend asset/settings coverage, Bot effective ledger/load-chain/companions and named MCP client/endpoint/caller binding, plus the exact failed locator observation. This is not a demonstrated product defect or a conclusion that all supported OS observation methods are incapable; it is the actual unresolved result within the one allowed batch.

## Actual holds, recovery and next owner

Producer's current authenticated resume comment establishes its **own** source/live-data/product-call/dispatch hold from `2026-10-29T04:38:00.152Z` until explicit ordinary Producer release, mapped to this issue/run epoch. Nonwrite authority/memory/Progress synchronization remains permitted. It is not Hermes/CTY/other callers' hold, a global writer freeze or a real-window behaviour acknowledgement.

Full feasibility/budgets/binding were not established, so the supplement's condition for requesting real-window coordination was not met. No CTY acknowledgement or caller hold was fabricated or solicited prematurely. Current Hermes no-invoke/no-replay and CTY manual no-submit receipts remain absent for a real window. The conditional four-route batch and one DB guard allowance were **not activated** and are not banked for automatic reuse or a third attempt.

MCP transport may remain connected; direct8188 is not network-fenced. The accepted limited caller-hold plus graceful8001/8765 closure alternative was not activated. Remote legacy delivery outcomes remain unknown/held; no replay, delivery, ledger reset, provisioning or old restore occurred. No new outage was introduced. No B/newstate exists from this run; there is no rollback/recovery to perform. Future newstate still requires data-preserving forward recovery, never old DB/ledger overwrite or blind inverse.

Next owner [Producer](/AID/issues/AID-4) reviews this exact second partial via the existing native completion/dependency path, communicates the actual result, and controls its own explicit hold release. Preserve both reports and the actual remaining capability/budget gaps; this grant provides **no third attempt**. No new readiness tree, task, monitor, repeated source QA or reapproval request is created here. Runtime adoption, real ComfyUI/LoRA/UI journeys and CTY aesthetics remain unaccepted.

**Memory candidates: None.** Existing memory covers stage gates, bounded observation errors and runtime uncertainty. Volatile measurements and the failed locator remain task evidence; Environment did not edit shared memory.
