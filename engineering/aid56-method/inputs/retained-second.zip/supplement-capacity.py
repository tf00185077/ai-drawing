import os,pathlib,json,stat,hashlib,time,subprocess,collections,datetime
S=pathlib.Path(os.environ['PAPERCLIP_RUN_SCRATCH_DIR']).resolve();R=pathlib.Path('/Users/tf00185088/Desktop/tim-project/ai-drawing');V=pathlib.Path('/Volumes/AI-Drawing-16T/ai-drawing');C=R.parent/'.ai-drawing-maintenance-backups/aid4-new110-v1-8eaf5820'
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(n,j):p=S/n;p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n');p.chmod(0o600)
old=json.loads((S/'inherited-preflight.json').read_text());source=json.loads((S/'inherited-source-preconditions.json').read_text());root_paths=[pathlib.Path(x['root']) for x in old['roots']];extra=pathlib.Path(old['extra_target']['path']);root_paths.append(extra)
root_paths.extend(R/x['path'] for x in source if x['kind']=='replacement')
# Git protection is the exact HEAD/index/refs set, plus packed refs when present; no .git object/history walk.
git=R/'.git';assert git.is_dir() and not git.is_symlink();root_paths.extend([git/'HEAD',git/'index',git/'refs']);
if (git/'packed-refs').exists():root_paths.append(git/'packed-refs')
# Only known companions and sibling names for the approved DB/ledger; no private contents.
companion=[]
for base in [R/'auto_draw.db',R/'discord-bot/.state/result-deliveries.json']:
 names=[x.name for x in os.scandir(base.parent) if x.name.startswith(base.name) and x.name!=base.name]
 for n in names:
  if n.startswith(base.name) and n[len(base.name):] in ['-wal','-shm','-journal','.checkpoint','.owner','.tmp']:
   p=base.parent/n;root_paths.append(p);companion.append({'parent':str(base.parent),'suffix':n[len(base.name):],'kind':'recognized companion'})
  else:companion.append({'parent':str(base.parent),'kind':'unrecognized prefix companion; no contents read'})
# One bounded metadata manifest pass over approved roots; no contents copied and no link traversal.
start=time.monotonic();count=0;files={};seen=set();entries=[];roots=[];errors=[];knownlinks=0
for root in root_paths:
 group='source68' if any(root==R/x['path'] for x in source if x['kind']=='replacement') else 'git' if root==git or git in root.parents else 'state'
 rec={'root':str(root),'group':group,'files':0,'dirs':0,'links':0,'logical':0,'destination_rounded':0};stack=[root]
 if not os.path.lexists(root):errors.append({'root':str(root),'error':'absent named root'});roots.append(rec);continue
 while stack:
  if count>=100000 or time.monotonic()-start>35:errors.append({'error':'finite metadata bound reached'});stack=[];break
  p=stack.pop()
  if str(p) in seen:continue
  seen.add(str(p));count+=1;st=p.lstat();entry={'path':p,'size':st.st_size,'mode':stat.S_IMODE(st.st_mode),'uid':st.st_uid,'gid':st.st_gid,'dev':st.st_dev,'inode':st.st_ino,'mtime_ns':st.st_mtime_ns};entries.append(entry)
  if stat.S_ISLNK(st.st_mode):
   rec['links']+=1;literal=os.readlink(p);resolved=str(p.resolve());entry['link_literal_bytes']=len(os.fsencode(literal));entry['link_target']=resolved
   if p.parent==V/'models/loras':knownlinks+=1
   else:errors.append({'root':str(root),'error':'unexpected symlink; not traversed'})
   continue
  if stat.S_ISDIR(st.st_mode):
   rec['dirs']+=1
   with os.scandir(p) as it:stack.extend(pathlib.Path(x.path) for x in it)
  elif stat.S_ISREG(st.st_mode):
   rec['files']+=1;rec['logical']+=st.st_size;rounded=((st.st_size+4095)//4096)*4096;rec['destination_rounded']+=rounded;files[str(p)]={'size':st.st_size,'rounded':rounded,'group':group}
  else:errors.append({'root':str(root),'error':'special file'})
 roots.append(rec)
# Native per-entry metadata in fixed batches, as part of the same pass (no recursive second walk).
xattrs=acl=xb=ab=0;maxx=0
for offset in range(0,len(entries),128):
 remaining=35-(time.monotonic()-start)
 if remaining<=0:errors.append({'error':'native metadata deadline'});break
 batch=entries[offset:offset+128]
 try:
  p=subprocess.run(['/bin/ls','-ldAe@']+[str(e['path']) for e in batch],stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=remaining,env={'PATH':'/usr/bin:/bin','LC_ALL':'C'})
  if p.returncode:errors.append({'error':'native metadata command failed','exit':p.returncode});break
  import re
  for line in p.stdout.decode(errors='replace').splitlines():
   m=re.match(r'^\s+\S+\s+(\d+)\s*$',line)
   if m:n=int(m[1]);xattrs+=1;xb+=n;maxx=max(maxx,n)
   if re.match(r'^\s*\d+:\s',line):acl+=1;ab+=len(line.encode())
 except subprocess.TimeoutExpired:errors.append({'error':'native metadata timeout'});break
end=time.monotonic();p=sum(x['size'] for x in files.values());a=sum(x['rounded'] for x in files.values());db=files.get(str(R/'auto_draw.db'),{}).get('size')
summary={g:{'files':sum(x['group']==g for x in files.values()),'logical':sum(x['size'] for x in files.values() if x['group']==g),'destination_rounded':sum(x['rounded'] for x in files.values() if x['group']==g)} for g in ['state','source68','git']}
# Controls have an explicit finite writing envelope; this is not a bound on unknown loaded state.
M=64*2**20;hf=256*2**20;uf=256*2**20
report={'observedAt':now(),'pass_count':1,'bound':{'entries':100000,'seconds':35},'elapsed_seconds':round(end-start,4),'entries':count,'groups':summary,'roots':roots,'recognized_companions':companion,'metadata':{'xattr_entries':xattrs,'xattr_value_bytes':xb,'max_xattr_value':maxx,'acl_entries':acl,'acl_text_bytes':ab,'root_directory_metadata_included':True,'raw_metadata_exported':False},'literal_link_count':sum('link_target' in x for x in entries),'C_absent':not os.path.lexists(C),'P_named_complete':p,'P_definition':'all existing named state, known companions, extra target,68 source preimages, exact existing HEAD/index/refs/packed-refs; does not certify loaded effective roots/companions','P_rounded_to_C_block4096':a,'two_full_named_copies':2*p,'C_cap':120*2**30,'numeric_control_envelope':{'M':M,'basis':'at most two 16MiB manifests (<=100000 entries capped per-stage before write),16MiB preservation/control receipts,8MiB operational scripts and8MiB bounded log/literal metadata; no manifests generated in C','H_R_C_candidate':hf,'H_basis':'proposed256MiB metadata/link/directory/copy overhead envelope; native sizes measured but APFS/copy preservation upper-bound certification remains unresolved','U_R_C_candidate':uf,'U_basis':'proposed256MiB DB journal/source temporary/closed control envelope; not a certified bound on unknown post-state'} ,'post_state':{'DB_current_full_file_copy':db,'D_B':None,'D_S':None,'reason':'no fresh full schema/index/page/companion budget binding; effective loaded writers/root closure unknown; current bytes cannot be a post-change upper bound'},'measured_full_copy_subtotal':2*p+M,'remaining_for_D_B_D_S':120*2**30-2*p-M,'measured_physical_copy_plus_candidate_envelopes':2*a+M+hf+uf,'full_plan_certified':False,'errors':errors}
fs=os.statvfs(R);report['physical']={'R_C_same_device':R.stat().st_dev==C.parent.parent.stat().st_dev,'R_device':R.stat().st_dev,'block_size':fs.f_frsize,'F':fs.f_bavail*fs.f_frsize,'20pct_threshold_for_measured_subtotal_only':(6*report['measured_physical_copy_plus_candidate_envelopes']+4)//5,'full_formula_pass':None}
# A digest preserves the selected metadata manifest without exporting asset/private filenames.
serial=[{**{k:v for k,v in x.items() if k not in ['path','link_target']},'path_sha256':hashlib.sha256(os.fsencode(x['path'])).hexdigest()} for x in entries];save('metadata-fingerprints.json',serial);save('capacity-supplement.json',report)
print(json.dumps({k:v for k,v in report.items() if k!='roots'},ensure_ascii=False,indent=2))
