import os,pathlib,json,subprocess,datetime,re,http.client,hashlib,ast
S=pathlib.Path(os.environ['PAPERCLIP_RUN_SCRATCH_DIR']).resolve();R=pathlib.Path('/Users/tf00185088/Desktop/tim-project/ai-drawing');V=pathlib.Path('/Volumes/AI-Drawing-16T/ai-drawing')
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(n,j):p=S/n;p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n');p.chmod(0o600)
def run(a):
 p=subprocess.run(a,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=6,env={'PATH':'/usr/bin:/bin:/opt/homebrew/bin','LC_ALL':'C'});return p.returncode,p.stdout.decode(errors='replace'),bool(p.stderr)
# One named service/client projection, no private-file/environment dumps, no process-memory access.
rep={'observedAt':now(),'projection_batches':1,'method':'existing tmux/ps/lsof/pgrep local tools only; no private config or process environment reads','services':[],'errors':[]}
rc,out,err=run(['/opt/homebrew/bin/tmux','-L','ai-drawing','list-panes','-a','-F','#{session_name}|#{window_index}.#{pane_index}|#{pane_pid}|#{pane_current_path}']);panes={}
for l in out.splitlines():
 parts=l.split('|')
 if len(parts)==4 and parts[0] in ['ai-drawing-backend','ai-drawing-discord-bot']:panes[parts[0]]=parts
for name,port in [('ai-drawing-backend',8001),('ai-drawing-discord-bot',8765)]:
 if name not in panes:rep['errors'].append({'service':name,'error':'named pane absent'});continue
 row=panes[name];pid=int(row[2]);rec={'name':name,'pid':pid,'pane':row[1],'tmux_cwd':row[3]}
 rc,ps,err=run(['/bin/ps','-p',str(pid),'-o','pid=,ppid=,uid=,lstart=,comm=']);rec['ps']={'exit':rc,'projection':ps.strip()}
 rc,raw,err=run(['/bin/ps','-p',str(pid),'-o','command=']);rec['argv_projection']={'exit':rc,'uvicorn':bool(re.search(r'(?:^|\s)uvicorn(?:\s|$)',raw)),'app_main':'app.main:app' in raw,'bot_main':bool(re.search(r'(?:^|\s)bot.main(?:\s|$)',raw)),'reloader':'--reload' in raw,'loaded_paths_or_endpoints_in_argv':False};del raw
 rc,raw,err=run(['/usr/sbin/lsof','-a','-p',str(pid),'-Fftn']);names=[x[1:] for x in raw.splitlines() if x.startswith('n')];rec['open_handles']={'exit':rc,'db_open':str(R/'auto_draw.db') in names,'ledger_open':str(R/'discord-bot/.state/result-deliveries.json') in names,'named_state_handles':sorted(set(n for n in names if n in [str(R/'auto_draw.db'),str(R/'discord-bot/.state/result-deliveries.json')] or n.startswith(str(R/'auto_draw.db')+'-'))),'listener_or_connection_endpoints':sorted(set(n for n in names if re.fullmatch(r'127\.0\.0\.1:(?:8001|8765|8188)(?:->127\.0\.0\.1:\d+)?',n))),'root_descriptors':[label for label,p in [('output',V/'backend-outputs'),('gallery',V/'gallery'),('training',V/'training/lora'),('models',V/'models/loras'),('prompt',R/'prompt_library')] if any(n==str(p) or n.startswith(str(p)+'/') for n in names)]};del raw,names
 rc,raw,err=run(['/usr/bin/pgrep','-P',str(pid)]);rec['direct_child_count']=len(raw.split()) if rc in [0,1] else None
 rec['loaded_settings_certified']=False;rec['loaded_binding_gap']='argv/cwd/open descriptors do not expose all loaded Settings roots, effective Bot ledger/config and closed file companions';rep['services'].append(rec)
# Match only the two already-named aliases of the exact installed MCP entry.
pattern=r'/Users/tf00185088/Desktop/(tim-project/)?ai-drawing/mcp-server/\.venv/bin/ai-drawing-mcp(?:\s|$)';rc,raw,err=run(['/usr/bin/pgrep','-f',pattern]);pids=[int(x) for x in raw.split() if x.isdigit()];m={'entry_pattern':pattern,'exit':rc,'matching_named_entry_count':len(pids),'transport_disconnected':False,'loaded_endpoint_projection':'unavailable: no supported client settings projection exposed in permitted observation methods'}
if len(pids)==1:
 pid=pids[0];rc,out,err=run(['/bin/ps','-p',str(pid),'-o','pid=,ppid=,uid=,lstart=,comm=']);m.update({'pid':pid,'ps_exit':rc,'ps_projection':out.strip()});rc,out,err=run(['/usr/sbin/lsof','-a','-p',str(pid),'-d','cwd','-Fn']);m['cwd_projection']=out.strip()
elif len(pids)>1:m['stop_reason']='multiple matching entries; no context/caller ownership attribution, no wider enumeration'
else:m['stop_reason']='named entry not found by exact argv locator; no broadened search or assumption that transport is disconnected'
rep['MCP']=m;rep['binding_gate_pass']=False;save('runtime-supplement.json',rep)
# Static source/schema proof precedes this sole independent correction read.
schema=R/'backend/app/schemas/lora_train.py';api=R/'backend/app/api/lora_train.py';tree=ast.parse(schema.read_text());node=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='TrainStatusResponse');fields={n.target.id:ast.unparse(n.annotation) for n in node.body if isinstance(n,ast.AnnAssign)}
assert fields['status']=='str' and fields['current_job']=='TrainJobInfo | None' and fields['queue']=='list[TrainJobInfo]';assert 'status=st["status"]' in api.read_text()
def project(j):
 if type(j)!=dict or type(j.get('status'))!=str or j['status'] not in ['idle','running','queued']:raise ValueError('status shape')
 if 'current_job' not in j or (j['current_job'] is not None and type(j['current_job'])!=dict):raise ValueError('current_job shape')
 if type(j.get('queue'))!=list or any(type(x)!=dict for x in j['queue']):raise ValueError('queue shape')
 return {'status':j['status'],'current_job_present':j['current_job'] is not None,'queue_count':len(j['queue'])}
valid=project({'status':'idle','current_job':None,'queue':[]})=={'status':'idle','current_job_present':False,'queue_count':0};assert valid
negative=[{'is_training':False,'current_job':None,'queue':[]},{'status':False,'current_job':None,'queue':[]},{'status':'idle','queue':[]},{'status':'idle','current_job':None,'queue':{}}]
for bad in negative:
 try:project(bad)
 except ValueError:pass
 else:raise AssertionError('invalid observer fixture accepted')
save('observer-schema-receipt.json',{'verifiedAt':now(),'schema_sha256':hashlib.sha256(schema.read_bytes()).hexdigest(),'api_sha256':hashlib.sha256(api.read_bytes()).hexdigest(),'field_annotations':fields,'positive_fixture':1,'negative_fixtures_rejected':len(negative),'normal_product_imports':0})
allowance={'correction_GET_attempts':1,'conditional_four_route_GETs':0,'conditional_DB_guard_reads':0,'metadata_passes':1,'runtime_projection_batches':1,'read_allowances_replenished':False};save('allowance-counters.json',allowance)
r={'observedAt':now(),'phase':'approved one correction read','method':'GET','endpoint':'http://127.0.0.1:8001/api/lora-train/status','attempts':1,'timeout_seconds':4,'byte_cap':2097152,'proxy':False,'redirect':False,'fallback':False,'result':'unknown'};conn=http.client.HTTPConnection('127.0.0.1',8001,timeout=4)
try:
 conn.request('GET','/api/lora-train/status');res=conn.getresponse();data=res.read(2097153);r.update({'http_status':res.status,'response_bytes':len(data)})
 if res.status!=200 or len(data)>2097152:raise ValueError('status/cap')
 r['projection']=project(json.loads(data));r['result']='typed observation';del data
except Exception as e:r['reason']=type(e).__name__+': '+str(e)
finally:conn.close()
save('correction-GET.json',r);print(json.dumps({'runtime':rep,'observer':fields,'correction':r,'allowance':allowance},ensure_ascii=False,indent=2))
